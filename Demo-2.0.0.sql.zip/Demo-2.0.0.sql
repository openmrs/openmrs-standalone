-- MySQL dump 10.13  Distrib 9.2.0, for macos15.2 (arm64)
--
-- Host: localhost    Database: openmrs
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `allergy`
--

DROP TABLE IF EXISTS `allergy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `allergy` (
  `allergy_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NOT NULL,
  `severity_concept_id` int DEFAULT NULL,
  `coded_allergen` int NOT NULL,
  `non_coded_allergen` varchar(255) DEFAULT NULL,
  `allergen_type` varchar(50) NOT NULL,
  `comments` varchar(1024) DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '1',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) DEFAULT NULL,
  `form_namespace_and_path` varchar(255) DEFAULT NULL,
  `encounter_id` int DEFAULT NULL,
  PRIMARY KEY (`allergy_id`),
  KEY `allergy_changed_by_fk` (`changed_by`),
  KEY `allergy_coded_allergen_fk` (`coded_allergen`),
  KEY `allergy_creator_fk` (`creator`),
  KEY `allergy_encounter_id_fk` (`encounter_id`),
  KEY `allergy_patient_id_fk` (`patient_id`),
  KEY `allergy_severity_concept_id_fk` (`severity_concept_id`),
  KEY `allergy_voided_by_fk` (`voided_by`),
  CONSTRAINT `allergy_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `allergy_coded_allergen_fk` FOREIGN KEY (`coded_allergen`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `allergy_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `allergy_encounter_id_fk` FOREIGN KEY (`encounter_id`) REFERENCES `encounter` (`encounter_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `allergy_patient_id_fk` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `allergy_severity_concept_id_fk` FOREIGN KEY (`severity_concept_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `allergy_voided_by_fk` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `allergy`
--

LOCK TABLES `allergy` WRITE;
/*!40000 ALTER TABLE `allergy` DISABLE KEYS */;
/*!40000 ALTER TABLE `allergy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `allergy_reaction`
--

DROP TABLE IF EXISTS `allergy_reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `allergy_reaction` (
  `allergy_reaction_id` int NOT NULL AUTO_INCREMENT,
  `allergy_id` int NOT NULL,
  `reaction_concept_id` int NOT NULL,
  `reaction_non_coded` varchar(255) DEFAULT NULL,
  `uuid` char(38) DEFAULT NULL,
  PRIMARY KEY (`allergy_reaction_id`),
  KEY `allergy_reaction_allergy_id_fk` (`allergy_id`),
  KEY `allergy_reaction_reaction_concept_id_fk` (`reaction_concept_id`),
  CONSTRAINT `allergy_reaction_allergy_id_fk` FOREIGN KEY (`allergy_id`) REFERENCES `allergy` (`allergy_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `allergy_reaction_reaction_concept_id_fk` FOREIGN KEY (`reaction_concept_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `allergy_reaction`
--

LOCK TABLES `allergy_reaction` WRITE;
/*!40000 ALTER TABLE `allergy_reaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `allergy_reaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `care_setting`
--

DROP TABLE IF EXISTS `care_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `care_setting` (
  `care_setting_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `care_setting_type` varchar(50) NOT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`care_setting_id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `care_setting_changed_by` (`changed_by`),
  KEY `care_setting_creator` (`creator`),
  KEY `care_setting_retired_by` (`retired_by`),
  CONSTRAINT `care_setting_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `care_setting_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `care_setting_retired_by` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `care_setting`
--

LOCK TABLES `care_setting` WRITE;
/*!40000 ALTER TABLE `care_setting` DISABLE KEYS */;
INSERT INTO `care_setting` VALUES (1,'Outpatient','Out-patient care setting','OUTPATIENT',1,'2013-12-27 00:00:00',0,NULL,NULL,NULL,NULL,NULL,'6f0c9a92-6f24-11e3-af88-005056821db0'),(2,'Inpatient','In-patient care setting','INPATIENT',1,'2013-12-27 00:00:00',0,NULL,NULL,NULL,NULL,NULL,'c365e560-c3ec-11e3-9c1a-0800200c9a66');
/*!40000 ALTER TABLE `care_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clob_datatype_storage`
--

DROP TABLE IF EXISTS `clob_datatype_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clob_datatype_storage` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uuid` char(38) NOT NULL,
  `value` longtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clob_datatype_storage`
--

LOCK TABLES `clob_datatype_storage` WRITE;
/*!40000 ALTER TABLE `clob_datatype_storage` DISABLE KEYS */;
/*!40000 ALTER TABLE `clob_datatype_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cohort`
--

DROP TABLE IF EXISTS `cohort`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cohort` (
  `cohort_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`cohort_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `cohort_creator` (`creator`),
  KEY `user_who_changed_cohort` (`changed_by`),
  KEY `user_who_voided_cohort` (`voided_by`),
  CONSTRAINT `cohort_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_changed_cohort` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_voided_cohort` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cohort`
--

LOCK TABLES `cohort` WRITE;
/*!40000 ALTER TABLE `cohort` DISABLE KEYS */;
/*!40000 ALTER TABLE `cohort` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cohort_member`
--

DROP TABLE IF EXISTS `cohort_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cohort_member` (
  `cohort_id` int NOT NULL,
  `patient_id` int NOT NULL,
  `cohort_member_id` int NOT NULL AUTO_INCREMENT,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`cohort_member_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `cohort_member_creator` (`creator`),
  KEY `member_patient` (`patient_id`),
  KEY `parent_cohort` (`cohort_id`),
  CONSTRAINT `cohort_member_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `member_patient` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `parent_cohort` FOREIGN KEY (`cohort_id`) REFERENCES `cohort` (`cohort_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cohort_member`
--

LOCK TABLES `cohort_member` WRITE;
/*!40000 ALTER TABLE `cohort_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `cohort_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept`
--

DROP TABLE IF EXISTS `concept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept` (
  `concept_id` int NOT NULL AUTO_INCREMENT,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `short_name` varchar(255) DEFAULT NULL,
  `description` text,
  `form_text` text,
  `datatype_id` int NOT NULL DEFAULT '0',
  `class_id` int NOT NULL DEFAULT '0',
  `is_set` tinyint(1) NOT NULL DEFAULT '0',
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `version` varchar(50) DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`concept_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `concept_classes` (`class_id`),
  KEY `concept_creator` (`creator`),
  KEY `concept_datatypes` (`datatype_id`),
  KEY `user_who_changed_concept` (`changed_by`),
  KEY `user_who_retired_concept` (`retired_by`),
  CONSTRAINT `concept_classes` FOREIGN KEY (`class_id`) REFERENCES `concept_class` (`concept_class_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `concept_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `concept_datatypes` FOREIGN KEY (`datatype_id`) REFERENCES `concept_datatype` (`concept_datatype_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_changed_concept` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_retired_concept` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept`
--

LOCK TABLES `concept` WRITE;
/*!40000 ALTER TABLE `concept` DISABLE KEYS */;
INSERT INTO `concept` VALUES (1,0,'','',NULL,4,11,0,1,'2018-06-04 18:29:58',NULL,NULL,NULL,NULL,NULL,NULL,'cf82933b-3f3f-45e7-a5ab-5d31aaee3da3'),(2,0,'','',NULL,4,11,0,1,'2018-06-04 18:29:58',NULL,NULL,NULL,NULL,NULL,NULL,'488b58ff-64f5-4f8a-8979-fa79940b1594');
/*!40000 ALTER TABLE `concept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_answer`
--

DROP TABLE IF EXISTS `concept_answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_answer` (
  `concept_answer_id` int NOT NULL AUTO_INCREMENT,
  `concept_id` int NOT NULL DEFAULT '0',
  `answer_concept` int DEFAULT NULL,
  `answer_drug` int DEFAULT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `sort_weight` double DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`concept_answer_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `answer` (`answer_concept`),
  KEY `answer_answer_drug_fk` (`answer_drug`),
  KEY `answer_creator` (`creator`),
  KEY `answers_for_concept` (`concept_id`),
  CONSTRAINT `answer` FOREIGN KEY (`answer_concept`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `answer_answer_drug_fk` FOREIGN KEY (`answer_drug`) REFERENCES `drug` (`drug_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `answer_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `answers_for_concept` FOREIGN KEY (`concept_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_answer`
--

LOCK TABLES `concept_answer` WRITE;
/*!40000 ALTER TABLE `concept_answer` DISABLE KEYS */;
/*!40000 ALTER TABLE `concept_answer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_attribute`
--

DROP TABLE IF EXISTS `concept_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_attribute` (
  `concept_attribute_id` int NOT NULL AUTO_INCREMENT,
  `concept_id` int NOT NULL,
  `attribute_type_id` int NOT NULL,
  `value_reference` text NOT NULL,
  `uuid` char(38) NOT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`concept_attribute_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `concept_attribute_attribute_type_id_fk` (`attribute_type_id`),
  KEY `concept_attribute_changed_by_fk` (`changed_by`),
  KEY `concept_attribute_concept_fk` (`concept_id`),
  KEY `concept_attribute_creator_fk` (`creator`),
  KEY `concept_attribute_voided_by_fk` (`voided_by`),
  CONSTRAINT `concept_attribute_attribute_type_id_fk` FOREIGN KEY (`attribute_type_id`) REFERENCES `concept_attribute_type` (`concept_attribute_type_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `concept_attribute_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `concept_attribute_concept_fk` FOREIGN KEY (`concept_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `concept_attribute_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `concept_attribute_voided_by_fk` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_attribute`
--

LOCK TABLES `concept_attribute` WRITE;
/*!40000 ALTER TABLE `concept_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `concept_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_attribute_type`
--

DROP TABLE IF EXISTS `concept_attribute_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_attribute_type` (
  `concept_attribute_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `datatype` varchar(255) DEFAULT NULL,
  `datatype_config` text,
  `preferred_handler` varchar(255) DEFAULT NULL,
  `handler_config` text,
  `min_occurs` int NOT NULL,
  `max_occurs` int DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`concept_attribute_type_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `concept_attribute_type_changed_by_fk` (`changed_by`),
  KEY `concept_attribute_type_creator_fk` (`creator`),
  KEY `concept_attribute_type_retired_by_fk` (`retired_by`),
  CONSTRAINT `concept_attribute_type_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `concept_attribute_type_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `concept_attribute_type_retired_by_fk` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_attribute_type`
--

LOCK TABLES `concept_attribute_type` WRITE;
/*!40000 ALTER TABLE `concept_attribute_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `concept_attribute_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_class`
--

DROP TABLE IF EXISTS `concept_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_class` (
  `concept_class_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  `date_changed` datetime DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  PRIMARY KEY (`concept_class_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `concept_class_changed_by` (`changed_by`),
  KEY `concept_class_creator` (`creator`),
  KEY `concept_class_name_index` (`name`),
  KEY `concept_class_retired_status` (`retired`),
  KEY `user_who_retired_concept_class` (`retired_by`),
  CONSTRAINT `concept_class_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `concept_class_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_retired_concept_class` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_class`
--

LOCK TABLES `concept_class` WRITE;
/*!40000 ALTER TABLE `concept_class` DISABLE KEYS */;
INSERT INTO `concept_class` VALUES (1,'Test','Acq. during patient encounter (vitals, labs, etc.)',1,'2004-02-02 00:00:00',0,NULL,NULL,NULL,'8d4907b2-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL),(2,'Procedure','Describes a clinical procedure',1,'2004-03-02 00:00:00',0,NULL,NULL,NULL,'8d490bf4-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL),(3,'Drug','Drug',1,'2004-02-02 00:00:00',0,NULL,NULL,NULL,'8d490dfc-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL),(4,'Diagnosis','Conclusion drawn through findings',1,'2004-02-02 00:00:00',0,NULL,NULL,NULL,'8d4918b0-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL),(5,'Finding','Practitioner observation/finding',1,'2004-03-02 00:00:00',0,NULL,NULL,NULL,'8d491a9a-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL),(6,'Anatomy','Anatomic sites / descriptors',1,'2004-03-02 00:00:00',0,NULL,NULL,NULL,'8d491c7a-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL),(7,'Question','Question (eg, patient history, SF36 items)',1,'2004-03-02 00:00:00',0,NULL,NULL,NULL,'8d491e50-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL),(8,'LabSet','Term to describe laboratory sets',1,'2004-03-02 00:00:00',0,NULL,NULL,NULL,'8d492026-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL),(9,'MedSet','Term to describe medication sets',1,'2004-02-02 00:00:00',0,NULL,NULL,NULL,'8d4923b4-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL),(10,'ConvSet','Term to describe convenience sets',1,'2004-03-02 00:00:00',0,NULL,NULL,NULL,'8d492594-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL),(11,'Misc','Terms which don\'t fit other categories',1,'2004-03-02 00:00:00',0,NULL,NULL,NULL,'8d492774-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL),(12,'Symptom','Patient-reported observation',1,'2004-10-04 00:00:00',0,NULL,NULL,NULL,'8d492954-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL),(13,'Symptom/Finding','Observation that can be reported from patient or found on exam',1,'2004-10-04 00:00:00',0,NULL,NULL,NULL,'8d492b2a-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL),(14,'Specimen','Body or fluid specimen',1,'2004-12-02 00:00:00',0,NULL,NULL,NULL,'8d492d0a-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL),(15,'Misc Order','Orderable items which aren\'t tests or drugs',1,'2005-02-17 00:00:00',0,NULL,NULL,NULL,'8d492ee0-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL),(16,'Frequency','A class for order frequencies',1,'2014-03-06 00:00:00',0,NULL,NULL,NULL,'8e071bfe-520c-44c0-a89b-538e9129b42a',NULL,NULL);
/*!40000 ALTER TABLE `concept_class` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_complex`
--

DROP TABLE IF EXISTS `concept_complex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_complex` (
  `concept_id` int NOT NULL,
  `handler` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`concept_id`),
  CONSTRAINT `concept_attributes` FOREIGN KEY (`concept_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_complex`
--

LOCK TABLES `concept_complex` WRITE;
/*!40000 ALTER TABLE `concept_complex` DISABLE KEYS */;
/*!40000 ALTER TABLE `concept_complex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_datatype`
--

DROP TABLE IF EXISTS `concept_datatype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_datatype` (
  `concept_datatype_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `hl7_abbreviation` varchar(3) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`concept_datatype_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `concept_datatype_creator` (`creator`),
  KEY `concept_datatype_name_index` (`name`),
  KEY `concept_datatype_retired_status` (`retired`),
  KEY `user_who_retired_concept_datatype` (`retired_by`),
  CONSTRAINT `concept_datatype_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_retired_concept_datatype` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_datatype`
--

LOCK TABLES `concept_datatype` WRITE;
/*!40000 ALTER TABLE `concept_datatype` DISABLE KEYS */;
INSERT INTO `concept_datatype` VALUES (1,'Numeric','NM','Numeric value, including integer or float (e.g., creatinine, weight)',1,'2004-02-02 00:00:00',0,NULL,NULL,NULL,'8d4a4488-c2cc-11de-8d13-0010c6dffd0f'),(2,'Coded','CWE','Value determined by term dictionary lookup (i.e., term identifier)',1,'2004-02-02 00:00:00',0,NULL,NULL,NULL,'8d4a48b6-c2cc-11de-8d13-0010c6dffd0f'),(3,'Text','ST','Free text',1,'2004-02-02 00:00:00',0,NULL,NULL,NULL,'8d4a4ab4-c2cc-11de-8d13-0010c6dffd0f'),(4,'N/A','ZZ','Not associated with a datatype (e.g., term answers, sets)',1,'2004-02-02 00:00:00',0,NULL,NULL,NULL,'8d4a4c94-c2cc-11de-8d13-0010c6dffd0f'),(5,'Document','RP','Pointer to a binary or text-based document (e.g., clinical document, RTF, XML, EKG, image, etc.) stored in complex_obs table',1,'2004-04-15 00:00:00',0,NULL,NULL,NULL,'8d4a4e74-c2cc-11de-8d13-0010c6dffd0f'),(6,'Date','DT','Absolute date',1,'2004-07-22 00:00:00',0,NULL,NULL,NULL,'8d4a505e-c2cc-11de-8d13-0010c6dffd0f'),(7,'Time','TM','Absolute time of day',1,'2004-07-22 00:00:00',0,NULL,NULL,NULL,'8d4a591e-c2cc-11de-8d13-0010c6dffd0f'),(8,'Datetime','TS','Absolute date and time',1,'2004-07-22 00:00:00',0,NULL,NULL,NULL,'8d4a5af4-c2cc-11de-8d13-0010c6dffd0f'),(10,'Boolean','BIT','Boolean value (yes/no, true/false)',1,'2004-08-26 00:00:00',0,NULL,NULL,NULL,'8d4a5cca-c2cc-11de-8d13-0010c6dffd0f'),(11,'Rule','ZZ','Value derived from other data',1,'2006-09-11 00:00:00',0,NULL,NULL,NULL,'8d4a5e96-c2cc-11de-8d13-0010c6dffd0f'),(12,'Structured Numeric','SN','Complex numeric values possible (ie, <5, 1-10, etc.)',1,'2005-08-06 00:00:00',0,NULL,NULL,NULL,'8d4a606c-c2cc-11de-8d13-0010c6dffd0f'),(13,'Complex','ED','Complex value.  Analogous to HL7 Embedded Datatype',1,'2008-05-28 12:25:34',0,NULL,NULL,NULL,'8d4a6242-c2cc-11de-8d13-0010c6dffd0f');
/*!40000 ALTER TABLE `concept_datatype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_description`
--

DROP TABLE IF EXISTS `concept_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_description` (
  `concept_description_id` int NOT NULL AUTO_INCREMENT,
  `concept_id` int NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `locale` varchar(50) NOT NULL DEFAULT '',
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`concept_description_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `description_for_concept` (`concept_id`),
  KEY `user_who_changed_description` (`changed_by`),
  KEY `user_who_created_description` (`creator`),
  CONSTRAINT `description_for_concept` FOREIGN KEY (`concept_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_changed_description` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_created_description` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_description`
--

LOCK TABLES `concept_description` WRITE;
/*!40000 ALTER TABLE `concept_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `concept_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_map_type`
--

DROP TABLE IF EXISTS `concept_map_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_map_type` (
  `concept_map_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `is_hidden` tinyint(1) NOT NULL DEFAULT '0',
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`concept_map_type_id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `mapped_user_changed_concept_map_type` (`changed_by`),
  KEY `mapped_user_creator_concept_map_type` (`creator`),
  KEY `mapped_user_retired_concept_map_type` (`retired_by`),
  CONSTRAINT `mapped_user_changed_concept_map_type` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `mapped_user_creator_concept_map_type` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `mapped_user_retired_concept_map_type` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_map_type`
--

LOCK TABLES `concept_map_type` WRITE;
/*!40000 ALTER TABLE `concept_map_type` DISABLE KEYS */;
INSERT INTO `concept_map_type` VALUES (1,'SAME-AS',NULL,1,'2018-06-04 00:00:00',NULL,NULL,0,0,NULL,NULL,NULL,'35543629-7d8c-11e1-909d-c80aa9edcf4e'),(2,'NARROWER-THAN',NULL,1,'2018-06-04 00:00:00',NULL,NULL,0,0,NULL,NULL,NULL,'43ac5109-7d8c-11e1-909d-c80aa9edcf4e'),(3,'BROADER-THAN',NULL,1,'2018-06-04 00:00:00',NULL,NULL,0,0,NULL,NULL,NULL,'4b9d9421-7d8c-11e1-909d-c80aa9edcf4e'),(4,'Associated finding',NULL,1,'2018-06-04 00:00:00',NULL,NULL,0,0,NULL,NULL,NULL,'55e02065-7d8c-11e1-909d-c80aa9edcf4e'),(5,'Associated morphology',NULL,1,'2018-06-04 00:00:00',NULL,NULL,0,0,NULL,NULL,NULL,'605f4a61-7d8c-11e1-909d-c80aa9edcf4e'),(6,'Associated procedure',NULL,1,'2018-06-04 00:00:00',NULL,NULL,0,0,NULL,NULL,NULL,'6eb1bfce-7d8c-11e1-909d-c80aa9edcf4e'),(7,'Associated with',NULL,1,'2018-06-04 00:00:00',NULL,NULL,0,0,NULL,NULL,NULL,'781bdc8f-7d8c-11e1-909d-c80aa9edcf4e'),(8,'Causative agent',NULL,1,'2018-06-04 00:00:00',NULL,NULL,0,0,NULL,NULL,NULL,'808f9e19-7d8c-11e1-909d-c80aa9edcf4e'),(9,'Finding site',NULL,1,'2018-06-04 00:00:00',NULL,NULL,0,0,NULL,NULL,NULL,'889c3013-7d8c-11e1-909d-c80aa9edcf4e'),(10,'Has specimen',NULL,1,'2018-06-04 00:00:00',NULL,NULL,0,0,NULL,NULL,NULL,'929600b9-7d8c-11e1-909d-c80aa9edcf4e'),(11,'Laterality',NULL,1,'2018-06-04 00:00:00',NULL,NULL,0,0,NULL,NULL,NULL,'999c6fc0-7d8c-11e1-909d-c80aa9edcf4e'),(12,'Severity',NULL,1,'2018-06-04 00:00:00',NULL,NULL,0,0,NULL,NULL,NULL,'a0e52281-7d8c-11e1-909d-c80aa9edcf4e'),(13,'Access',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'f9e90b29-7d8c-11e1-909d-c80aa9edcf4e'),(14,'After',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'01b60e29-7d8d-11e1-909d-c80aa9edcf4e'),(15,'Clinical course',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'5f7c3702-7d8d-11e1-909d-c80aa9edcf4e'),(16,'Component',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'67debecc-7d8d-11e1-909d-c80aa9edcf4e'),(17,'Direct device',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'718c00da-7d8d-11e1-909d-c80aa9edcf4e'),(18,'Direct morphology',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'7b9509cb-7d8d-11e1-909d-c80aa9edcf4e'),(19,'Direct substance',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'82bb495d-7d8d-11e1-909d-c80aa9edcf4e'),(20,'Due to',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'8b77f7d3-7d8d-11e1-909d-c80aa9edcf4e'),(21,'Episodicity',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'94a81179-7d8d-11e1-909d-c80aa9edcf4e'),(22,'Finding context',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'9d23c22e-7d8d-11e1-909d-c80aa9edcf4e'),(23,'Finding informer',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'a4524368-7d8d-11e1-909d-c80aa9edcf4e'),(24,'Finding method',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'af089254-7d8d-11e1-909d-c80aa9edcf4e'),(25,'Has active ingredient',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'b65aa605-7d8d-11e1-909d-c80aa9edcf4e'),(26,'Has definitional manifestation',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'c2b7b2fa-7d8d-11e1-909d-c80aa9edcf4'),(27,'Has dose form',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'cc3878e6-7d8d-11e1-909d-c80aa9edcf4e'),(28,'Has focus',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'d67c5840-7d8d-11e1-909d-c80aa9edcf4e'),(29,'Has intent',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'de2fb2c5-7d8d-11e1-909d-c80aa9edcf4e'),(30,'Has interpretation',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'e758838b-7d8d-11e1-909d-c80aa9edcf4e'),(31,'Indirect device',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'ee63c142-7d8d-11e1-909d-c80aa9edcf4e'),(32,'Indirect morphology',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'f4f36681-7d8d-11e1-909d-c80aa9edcf4e'),(33,'Interprets',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'fc7f5fed-7d8d-11e1-909d-c80aa9edcf4e'),(34,'Measurement method',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'06b11d79-7d8e-11e1-909d-c80aa9edcf4e'),(35,'Method',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'0efb4753-7d8e-11e1-909d-c80aa9edcf4e'),(36,'Occurrence',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'16e7b617-7d8e-11e1-909d-c80aa9edcf4e'),(37,'Part of',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'1e82007b-7d8e-11e1-909d-c80aa9edcf4e'),(38,'Pathological process',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'2969915e-7d8e-11e1-909d-c80aa9edcf4e'),(39,'Priority',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'32d57796-7d8e-11e1-909d-c80aa9edcf4e'),(40,'Procedure context',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'3f11904c-7d8e-11e1-909d-c80aa9edcf4e'),(41,'Procedure device',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'468c4aa3-7d8e-11e1-909d-c80aa9edcf4e'),(42,'Procedure morphology',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'5383e889-7d8e-11e1-909d-c80aa9edcf4e'),(43,'Procedure site',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'5ad2655d-7d8e-11e1-909d-c80aa9edcf4e'),(44,'Procedure site - Direct',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'66085196-7d8e-11e1-909d-c80aa9edcf4e'),(45,'Procedure site - Indirect',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'7080e843-7d8e-11e1-909d-c80aa9edcf4e'),(46,'Property',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'76bfb796-7d8e-11e1-909d-c80aa9edcf4e'),(47,'Recipient category',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'7e7d00e4-7d8e-11e1-909d-c80aa9edcf4e'),(48,'Revision status',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'851e14c1-7d8e-11e1-909d-c80aa9edcf4e'),(49,'Route of administration',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'8ee5b13d-7d8e-11e1-909d-c80aa9edcf4e'),(50,'Scale type',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'986acf48-7d8e-11e1-909d-c80aa9edcf4e'),(51,'Specimen procedure',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'a6937642-7d8e-11e1-909d-c80aa9edcf4e'),(52,'Specimen source identity',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'b1d6941e-7d8e-11e1-909d-c80aa9edcf4e'),(53,'Specimen source morphology',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'b7c793c1-7d8e-11e1-909d-c80aa9edcf4e'),(54,'Specimen source topography',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'be9f9eb8-7d8e-11e1-909d-c80aa9edcf4e'),(55,'Specimen substance',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'c8f2bacb-7d8e-11e1-909d-c80aa9edcf4e'),(56,'Subject of information',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'d0664c4f-7d8e-11e1-909d-c80aa9edcf4e'),(57,'Subject relationship context',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'dace9d13-7d8e-11e1-909d-c80aa9edcf4e'),(58,'Surgical approach',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'e3cd666d-7d8e-11e1-909d-c80aa9edcf4e'),(59,'Temporal context',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'ed96447d-7d8e-11e1-909d-c80aa9edcf4e'),(60,'Time aspect',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'f415bcce-7d8e-11e1-909d-c80aa9edcf4e'),(61,'Using access device',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'fa9538a9-7d8e-11e1-909d-c80aa9edcf4e'),(62,'Using device',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'06588655-7d8f-11e1-909d-c80aa9edcf4e'),(63,'Using energy',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'0c2ae0bc-7d8f-11e1-909d-c80aa9edcf4e'),(64,'Using substance',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'13d2c607-7d8f-11e1-909d-c80aa9edcf4e'),(65,'IS A',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'1ce7a784-7d8f-11e1-909d-c80aa9edcf4e'),(66,'MAY BE A',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'267812a3-7d8f-11e1-909d-c80aa9edcf4e'),(67,'MOVED FROM',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'2de3168e-7d8f-11e1-909d-c80aa9edcf4e'),(68,'MOVED TO',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'32f0fd99-7d8f-11e1-909d-c80aa9edcf4e'),(69,'REPLACED BY',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'3b3b9a7d-7d8f-11e1-909d-c80aa9edcf4e'),(70,'WAS A',NULL,1,'2018-06-04 00:00:00',NULL,NULL,1,0,NULL,NULL,NULL,'41a034da-7d8f-11e1-909d-c80aa9edcf4e');
/*!40000 ALTER TABLE `concept_map_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_name`
--

DROP TABLE IF EXISTS `concept_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_name` (
  `concept_name_id` int NOT NULL AUTO_INCREMENT,
  `concept_id` int DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `locale` varchar(50) NOT NULL DEFAULT '',
  `locale_preferred` tinyint(1) DEFAULT '0',
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `concept_name_type` varchar(50) DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  `date_changed` datetime DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  PRIMARY KEY (`concept_name_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `concept_name_changed_by` (`changed_by`),
  KEY `name_for_concept` (`concept_id`),
  KEY `name_of_concept` (`name`),
  KEY `user_who_created_name` (`creator`),
  KEY `user_who_voided_this_name` (`voided_by`),
  CONSTRAINT `concept_name_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `name_for_concept` FOREIGN KEY (`concept_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_created_name` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_voided_this_name` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_name`
--

LOCK TABLES `concept_name` WRITE;
/*!40000 ALTER TABLE `concept_name` DISABLE KEYS */;
INSERT INTO `concept_name` VALUES (1,1,'Verdadeiro','pt',0,1,'2018-06-04 18:29:58',NULL,0,NULL,NULL,NULL,'7561f550-ccee-43b6-bcf4-269992d6c284',NULL,NULL),(2,1,'Sim','pt',0,1,'2018-06-04 18:29:58',NULL,0,NULL,NULL,NULL,'89522273-55b5-4c4a-8e0b-cc7a66f3f3aa',NULL,NULL),(3,1,'True','en',1,1,'2018-06-04 18:29:58','FULLY_SPECIFIED',0,NULL,NULL,NULL,'111eb000-3113-4d74-9d9b-98ae5d566a98',NULL,NULL),(4,1,'Yes','en',0,1,'2018-06-04 18:29:58',NULL,0,NULL,NULL,NULL,'a31778d2-53ab-4c4b-a333-a0149d1c25c6',NULL,NULL),(5,1,'Vero','it',0,1,'2018-06-04 18:29:58',NULL,0,NULL,NULL,NULL,'a069d777-3999-4bb4-8217-d4fae1f337bc',NULL,NULL),(6,1,'Sì','it',0,1,'2018-06-04 18:29:58',NULL,0,NULL,NULL,NULL,'f16c811c-d970-4f02-be47-0c7afea9eddc',NULL,NULL),(7,1,'Vrai','fr',0,1,'2018-06-04 18:29:58',NULL,0,NULL,NULL,NULL,'bb75175c-5d1b-492a-8c38-98506e2e6b2d',NULL,NULL),(8,1,'Oui','fr',0,1,'2018-06-04 18:29:58',NULL,0,NULL,NULL,NULL,'c4c4b0f6-c80c-410b-9f48-72b683072184',NULL,NULL),(9,1,'Verdadero','es',0,1,'2018-06-04 18:29:58',NULL,0,NULL,NULL,NULL,'bf9ace2a-ff96-44fc-b529-172f5c3ac0b0',NULL,NULL),(10,1,'Sí','es',0,1,'2018-06-04 18:29:58',NULL,0,NULL,NULL,NULL,'b58d53a3-c6dd-469a-8db1-0a80dfe4c542',NULL,NULL),(11,2,'Falso','pt',0,1,'2018-06-04 18:29:58',NULL,0,NULL,NULL,NULL,'2553457e-849d-4a5c-9824-2f0a9ba79461',NULL,NULL),(12,2,'Não','pt',0,1,'2018-06-04 18:29:58',NULL,0,NULL,NULL,NULL,'38a0828c-c54e-4bdb-8217-defb0fdfc4b6',NULL,NULL),(13,2,'False','en',1,1,'2018-06-04 18:29:58','FULLY_SPECIFIED',0,NULL,NULL,NULL,'ac6d888e-dc00-4402-9a2a-576438161f96',NULL,NULL),(14,2,'No','en',0,1,'2018-06-04 18:29:58',NULL,0,NULL,NULL,NULL,'17a5cdd3-a0a9-406a-b39f-5cd7e8d634c4',NULL,NULL),(15,2,'Falso','it',0,1,'2018-06-04 18:29:58',NULL,0,NULL,NULL,NULL,'026e4e70-28c5-458d-8bbf-be7abaf09519',NULL,NULL),(16,2,'No','it',0,1,'2018-06-04 18:29:58',NULL,0,NULL,NULL,NULL,'23851ffa-da5d-4086-8107-e0318b4d26eb',NULL,NULL),(17,2,'Faux','fr',0,1,'2018-06-04 18:29:58',NULL,0,NULL,NULL,NULL,'5709a1b5-b3de-472f-bf7a-eb57c5cb7144',NULL,NULL),(18,2,'Non','fr',0,1,'2018-06-04 18:29:58',NULL,0,NULL,NULL,NULL,'3990b17b-22a0-4b66-9d06-1645030e6b60',NULL,NULL),(19,2,'Falso','es',0,1,'2018-06-04 18:29:58',NULL,0,NULL,NULL,NULL,'ae3cf994-72e1-471d-9af0-96dace0b6787',NULL,NULL),(20,2,'No','es',0,1,'2018-06-04 18:29:58',NULL,0,NULL,NULL,NULL,'72071f05-d7e2-4687-ac2e-c7d9809d888a',NULL,NULL);
/*!40000 ALTER TABLE `concept_name` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_name_tag`
--

DROP TABLE IF EXISTS `concept_name_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_name_tag` (
  `concept_name_tag_id` int NOT NULL AUTO_INCREMENT,
  `tag` varchar(50) NOT NULL,
  `description` text,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  `date_changed` datetime DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  PRIMARY KEY (`concept_name_tag_id`),
  UNIQUE KEY `tag` (`tag`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `concept_name_tag_changed_by` (`changed_by`),
  KEY `user_who_created_name_tag` (`creator`),
  KEY `user_who_voided_name_tag` (`voided_by`),
  CONSTRAINT `concept_name_tag_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_name_tag`
--

LOCK TABLES `concept_name_tag` WRITE;
/*!40000 ALTER TABLE `concept_name_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `concept_name_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_name_tag_map`
--

DROP TABLE IF EXISTS `concept_name_tag_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_name_tag_map` (
  `concept_name_id` int NOT NULL,
  `concept_name_tag_id` int NOT NULL,
  KEY `mapped_concept_name` (`concept_name_id`),
  KEY `mapped_concept_name_tag` (`concept_name_tag_id`),
  CONSTRAINT `mapped_concept_name` FOREIGN KEY (`concept_name_id`) REFERENCES `concept_name` (`concept_name_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `mapped_concept_name_tag` FOREIGN KEY (`concept_name_tag_id`) REFERENCES `concept_name_tag` (`concept_name_tag_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_name_tag_map`
--

LOCK TABLES `concept_name_tag_map` WRITE;
/*!40000 ALTER TABLE `concept_name_tag_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `concept_name_tag_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_numeric`
--

DROP TABLE IF EXISTS `concept_numeric`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_numeric` (
  `concept_id` int NOT NULL DEFAULT '0',
  `hi_absolute` double DEFAULT NULL,
  `hi_critical` double DEFAULT NULL,
  `hi_normal` double DEFAULT NULL,
  `low_absolute` double DEFAULT NULL,
  `low_critical` double DEFAULT NULL,
  `low_normal` double DEFAULT NULL,
  `units` varchar(50) DEFAULT NULL,
  `allow_decimal` tinyint(1) DEFAULT '0',
  `display_precision` int DEFAULT NULL,
  PRIMARY KEY (`concept_id`),
  CONSTRAINT `numeric_attributes` FOREIGN KEY (`concept_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_numeric`
--

LOCK TABLES `concept_numeric` WRITE;
/*!40000 ALTER TABLE `concept_numeric` DISABLE KEYS */;
/*!40000 ALTER TABLE `concept_numeric` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_proposal`
--

DROP TABLE IF EXISTS `concept_proposal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_proposal` (
  `concept_proposal_id` int NOT NULL AUTO_INCREMENT,
  `concept_id` int DEFAULT NULL,
  `encounter_id` int DEFAULT NULL,
  `original_text` varchar(255) NOT NULL DEFAULT '',
  `final_text` varchar(255) DEFAULT NULL,
  `obs_id` int DEFAULT NULL,
  `obs_concept_id` int DEFAULT NULL,
  `state` varchar(32) NOT NULL DEFAULT 'UNMAPPED',
  `comments` varchar(255) DEFAULT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `locale` varchar(50) NOT NULL DEFAULT '',
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`concept_proposal_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `concept_for_proposal` (`concept_id`),
  KEY `encounter_for_proposal` (`encounter_id`),
  KEY `proposal_obs_concept_id` (`obs_concept_id`),
  KEY `proposal_obs_id` (`obs_id`),
  KEY `user_who_changed_proposal` (`changed_by`),
  KEY `user_who_created_proposal` (`creator`),
  CONSTRAINT `concept_for_proposal` FOREIGN KEY (`concept_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `encounter_for_proposal` FOREIGN KEY (`encounter_id`) REFERENCES `encounter` (`encounter_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `proposal_obs_concept_id` FOREIGN KEY (`obs_concept_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `proposal_obs_id` FOREIGN KEY (`obs_id`) REFERENCES `obs` (`obs_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_changed_proposal` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_created_proposal` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_proposal`
--

LOCK TABLES `concept_proposal` WRITE;
/*!40000 ALTER TABLE `concept_proposal` DISABLE KEYS */;
/*!40000 ALTER TABLE `concept_proposal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_proposal_tag_map`
--

DROP TABLE IF EXISTS `concept_proposal_tag_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_proposal_tag_map` (
  `concept_proposal_id` int NOT NULL,
  `concept_name_tag_id` int NOT NULL,
  KEY `mapped_concept_proposal` (`concept_proposal_id`),
  KEY `mapped_concept_proposal_tag` (`concept_name_tag_id`),
  CONSTRAINT `mapped_concept_proposal` FOREIGN KEY (`concept_proposal_id`) REFERENCES `concept_proposal` (`concept_proposal_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `mapped_concept_proposal_tag` FOREIGN KEY (`concept_name_tag_id`) REFERENCES `concept_name_tag` (`concept_name_tag_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_proposal_tag_map`
--

LOCK TABLES `concept_proposal_tag_map` WRITE;
/*!40000 ALTER TABLE `concept_proposal_tag_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `concept_proposal_tag_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_reference_map`
--

DROP TABLE IF EXISTS `concept_reference_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_reference_map` (
  `concept_map_id` int NOT NULL AUTO_INCREMENT,
  `concept_reference_term_id` int NOT NULL,
  `concept_map_type_id` int NOT NULL DEFAULT '1',
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `concept_id` int NOT NULL DEFAULT '0',
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`concept_map_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `map_creator` (`creator`),
  KEY `map_for_concept` (`concept_id`),
  KEY `mapped_concept_map_type` (`concept_map_type_id`),
  KEY `mapped_concept_reference_term` (`concept_reference_term_id`),
  KEY `mapped_user_changed_ref_term` (`changed_by`),
  CONSTRAINT `map_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `map_for_concept` FOREIGN KEY (`concept_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `mapped_concept_map_type` FOREIGN KEY (`concept_map_type_id`) REFERENCES `concept_map_type` (`concept_map_type_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `mapped_concept_reference_term` FOREIGN KEY (`concept_reference_term_id`) REFERENCES `concept_reference_term` (`concept_reference_term_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `mapped_user_changed_ref_term` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_reference_map`
--

LOCK TABLES `concept_reference_map` WRITE;
/*!40000 ALTER TABLE `concept_reference_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `concept_reference_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_reference_range`
--

DROP TABLE IF EXISTS `concept_reference_range`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_reference_range` (
  `concept_reference_range_id` int NOT NULL AUTO_INCREMENT,
  `concept_id` int NOT NULL,
  `criteria` varchar(255) NOT NULL,
  `hi_absolute` double DEFAULT NULL,
  `hi_critical` double DEFAULT NULL,
  `hi_normal` double DEFAULT NULL,
  `low_absolute` double DEFAULT NULL,
  `low_critical` double DEFAULT NULL,
  `low_normal` double DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`concept_reference_range_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `fk_concept_numeric_reference_range` (`concept_id`),
  CONSTRAINT `fk_concept_numeric_reference_range` FOREIGN KEY (`concept_id`) REFERENCES `concept_numeric` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_reference_range`
--

LOCK TABLES `concept_reference_range` WRITE;
/*!40000 ALTER TABLE `concept_reference_range` DISABLE KEYS */;
/*!40000 ALTER TABLE `concept_reference_range` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_reference_source`
--

DROP TABLE IF EXISTS `concept_reference_source`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_reference_source` (
  `concept_source_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `hl7_code` varchar(50) DEFAULT '',
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  `unique_id` varchar(250) DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  PRIMARY KEY (`concept_source_id`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `hl7_code` (`hl7_code`),
  UNIQUE KEY `unique_id` (`unique_id`),
  KEY `concept_reference_source_changed_by` (`changed_by`),
  KEY `concept_source_creator` (`creator`),
  KEY `user_who_retired_concept_source` (`retired_by`),
  CONSTRAINT `concept_reference_source_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `concept_source_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_retired_concept_source` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_reference_source`
--

LOCK TABLES `concept_reference_source` WRITE;
/*!40000 ALTER TABLE `concept_reference_source` DISABLE KEYS */;
/*!40000 ALTER TABLE `concept_reference_source` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_reference_term`
--

DROP TABLE IF EXISTS `concept_reference_term`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_reference_term` (
  `concept_reference_term_id` int NOT NULL AUTO_INCREMENT,
  `concept_source_id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `code` varchar(255) NOT NULL,
  `version` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `date_changed` datetime DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`concept_reference_term_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `idx_code_concept_reference_term` (`code`),
  KEY `mapped_concept_source` (`concept_source_id`),
  KEY `mapped_user_changed` (`changed_by`),
  KEY `mapped_user_creator` (`creator`),
  KEY `mapped_user_retired` (`retired_by`),
  CONSTRAINT `mapped_concept_source` FOREIGN KEY (`concept_source_id`) REFERENCES `concept_reference_source` (`concept_source_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `mapped_user_changed` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `mapped_user_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `mapped_user_retired` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_reference_term`
--

LOCK TABLES `concept_reference_term` WRITE;
/*!40000 ALTER TABLE `concept_reference_term` DISABLE KEYS */;
/*!40000 ALTER TABLE `concept_reference_term` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_reference_term_map`
--

DROP TABLE IF EXISTS `concept_reference_term_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_reference_term_map` (
  `concept_reference_term_map_id` int NOT NULL AUTO_INCREMENT,
  `term_a_id` int NOT NULL,
  `term_b_id` int NOT NULL,
  `a_is_to_b_id` int NOT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`concept_reference_term_map_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `mapped_concept_map_type_ref_term_map` (`a_is_to_b_id`),
  KEY `mapped_term_a` (`term_a_id`),
  KEY `mapped_term_b` (`term_b_id`),
  KEY `mapped_user_changed_ref_term_map` (`changed_by`),
  KEY `mapped_user_creator_ref_term_map` (`creator`),
  CONSTRAINT `mapped_concept_map_type_ref_term_map` FOREIGN KEY (`a_is_to_b_id`) REFERENCES `concept_map_type` (`concept_map_type_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `mapped_term_a` FOREIGN KEY (`term_a_id`) REFERENCES `concept_reference_term` (`concept_reference_term_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `mapped_term_b` FOREIGN KEY (`term_b_id`) REFERENCES `concept_reference_term` (`concept_reference_term_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `mapped_user_changed_ref_term_map` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `mapped_user_creator_ref_term_map` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_reference_term_map`
--

LOCK TABLES `concept_reference_term_map` WRITE;
/*!40000 ALTER TABLE `concept_reference_term_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `concept_reference_term_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_set`
--

DROP TABLE IF EXISTS `concept_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_set` (
  `concept_set_id` int NOT NULL AUTO_INCREMENT,
  `concept_id` int NOT NULL DEFAULT '0',
  `concept_set` int NOT NULL DEFAULT '0',
  `sort_weight` double DEFAULT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`concept_set_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `has_a` (`concept_set`),
  KEY `idx_concept_set_concept` (`concept_id`),
  KEY `user_who_created` (`creator`),
  CONSTRAINT `has_a` FOREIGN KEY (`concept_set`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_created` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_set`
--

LOCK TABLES `concept_set` WRITE;
/*!40000 ALTER TABLE `concept_set` DISABLE KEYS */;
/*!40000 ALTER TABLE `concept_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_state_conversion`
--

DROP TABLE IF EXISTS `concept_state_conversion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_state_conversion` (
  `concept_state_conversion_id` int NOT NULL AUTO_INCREMENT,
  `concept_id` int DEFAULT '0',
  `program_workflow_id` int DEFAULT '0',
  `program_workflow_state_id` int DEFAULT '0',
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`concept_state_conversion_id`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `unique_workflow_concept_in_conversion` (`program_workflow_id`,`concept_id`),
  KEY `concept_triggers_conversion` (`concept_id`),
  KEY `conversion_to_state` (`program_workflow_state_id`),
  CONSTRAINT `concept_triggers_conversion` FOREIGN KEY (`concept_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `conversion_involves_workflow` FOREIGN KEY (`program_workflow_id`) REFERENCES `program_workflow` (`program_workflow_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `conversion_to_state` FOREIGN KEY (`program_workflow_state_id`) REFERENCES `program_workflow_state` (`program_workflow_state_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_state_conversion`
--

LOCK TABLES `concept_state_conversion` WRITE;
/*!40000 ALTER TABLE `concept_state_conversion` DISABLE KEYS */;
/*!40000 ALTER TABLE `concept_state_conversion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_stop_word`
--

DROP TABLE IF EXISTS `concept_stop_word`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_stop_word` (
  `concept_stop_word_id` int NOT NULL AUTO_INCREMENT,
  `word` varchar(50) NOT NULL,
  `locale` varchar(50) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`concept_stop_word_id`),
  UNIQUE KEY `Unique_StopWord_Key` (`word`,`locale`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_stop_word`
--

LOCK TABLES `concept_stop_word` WRITE;
/*!40000 ALTER TABLE `concept_stop_word` DISABLE KEYS */;
INSERT INTO `concept_stop_word` VALUES (1,'A','en','f5f45540-e2a7-11df-87ae-18a905e044dc'),(2,'AND','en','f5f469ae-e2a7-11df-87ae-18a905e044dc'),(3,'AT','en','f5f47070-e2a7-11df-87ae-18a905e044dc'),(4,'BUT','en','f5f476c4-e2a7-11df-87ae-18a905e044dc'),(5,'BY','en','f5f47d04-e2a7-11df-87ae-18a905e044dc'),(6,'FOR','en','f5f4834e-e2a7-11df-87ae-18a905e044dc'),(7,'HAS','en','f5f48a24-e2a7-11df-87ae-18a905e044dc'),(8,'OF','en','f5f49064-e2a7-11df-87ae-18a905e044dc'),(9,'THE','en','f5f496ae-e2a7-11df-87ae-18a905e044dc'),(10,'TO','en','f5f49cda-e2a7-11df-87ae-18a905e044dc');
/*!40000 ALTER TABLE `concept_stop_word` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conditions`
--

DROP TABLE IF EXISTS `conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conditions` (
  `condition_id` int NOT NULL AUTO_INCREMENT,
  `additional_detail` varchar(255) DEFAULT NULL,
  `previous_version` int DEFAULT NULL,
  `condition_coded` int DEFAULT NULL,
  `condition_non_coded` varchar(255) DEFAULT NULL,
  `condition_coded_name` int DEFAULT NULL,
  `clinical_status` varchar(50) NOT NULL,
  `verification_status` varchar(50) DEFAULT NULL,
  `onset_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `uuid` varchar(38) DEFAULT NULL,
  `creator` int NOT NULL,
  `voided_by` int DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  `patient_id` int NOT NULL,
  `end_date` datetime DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `encounter_id` int DEFAULT NULL,
  `form_namespace_and_path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`condition_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `condition_changed_by_fk` (`changed_by`),
  KEY `condition_condition_coded_fk` (`condition_coded`),
  KEY `condition_condition_coded_name_fk` (`condition_coded_name`),
  KEY `condition_creator_fk` (`creator`),
  KEY `condition_patient_fk` (`patient_id`),
  KEY `condition_previous_version_fk` (`previous_version`),
  KEY `condition_voided_by_fk` (`voided_by`),
  KEY `conditions_encounter_id_fk` (`encounter_id`),
  CONSTRAINT `condition_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `condition_condition_coded_fk` FOREIGN KEY (`condition_coded`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `condition_condition_coded_name_fk` FOREIGN KEY (`condition_coded_name`) REFERENCES `concept_name` (`concept_name_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `condition_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `condition_patient_fk` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `condition_previous_version_fk` FOREIGN KEY (`previous_version`) REFERENCES `conditions` (`condition_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `condition_voided_by_fk` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `conditions_encounter_id_fk` FOREIGN KEY (`encounter_id`) REFERENCES `encounter` (`encounter_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conditions`
--

LOCK TABLES `conditions` WRITE;
/*!40000 ALTER TABLE `conditions` DISABLE KEYS */;
/*!40000 ALTER TABLE `conditions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diagnosis_attribute`
--

DROP TABLE IF EXISTS `diagnosis_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `diagnosis_attribute` (
  `diagnosis_attribute_id` int NOT NULL AUTO_INCREMENT,
  `diagnosis_id` int NOT NULL,
  `attribute_type_id` int NOT NULL,
  `value_reference` text NOT NULL,
  `uuid` char(38) NOT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`diagnosis_attribute_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `diagnosis_attribute_attribute_type_id_fk` (`attribute_type_id`),
  KEY `diagnosis_attribute_changed_by_fk` (`changed_by`),
  KEY `diagnosis_attribute_creator_fk` (`creator`),
  KEY `diagnosis_attribute_diagnosis_fk` (`diagnosis_id`),
  KEY `diagnosis_attribute_voided_by_fk` (`voided_by`),
  CONSTRAINT `diagnosis_attribute_attribute_type_id_fk` FOREIGN KEY (`attribute_type_id`) REFERENCES `diagnosis_attribute_type` (`diagnosis_attribute_type_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `diagnosis_attribute_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `diagnosis_attribute_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `diagnosis_attribute_diagnosis_fk` FOREIGN KEY (`diagnosis_id`) REFERENCES `encounter_diagnosis` (`diagnosis_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `diagnosis_attribute_voided_by_fk` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diagnosis_attribute`
--

LOCK TABLES `diagnosis_attribute` WRITE;
/*!40000 ALTER TABLE `diagnosis_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `diagnosis_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diagnosis_attribute_type`
--

DROP TABLE IF EXISTS `diagnosis_attribute_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `diagnosis_attribute_type` (
  `diagnosis_attribute_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `datatype` varchar(255) DEFAULT NULL,
  `datatype_config` text,
  `preferred_handler` varchar(255) DEFAULT NULL,
  `handler_config` text,
  `min_occurs` int NOT NULL,
  `max_occurs` int DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`diagnosis_attribute_type_id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `diagnosis_attribute_type_changed_by_fk` (`changed_by`),
  KEY `diagnosis_attribute_type_creator_fk` (`creator`),
  KEY `diagnosis_attribute_type_retired_by_fk` (`retired_by`),
  CONSTRAINT `diagnosis_attribute_type_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `diagnosis_attribute_type_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `diagnosis_attribute_type_retired_by_fk` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diagnosis_attribute_type`
--

LOCK TABLES `diagnosis_attribute_type` WRITE;
/*!40000 ALTER TABLE `diagnosis_attribute_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `diagnosis_attribute_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drug`
--

DROP TABLE IF EXISTS `drug`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drug` (
  `drug_id` int NOT NULL AUTO_INCREMENT,
  `concept_id` int NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `combination` tinyint(1) NOT NULL DEFAULT '0',
  `dosage_form` int DEFAULT NULL,
  `maximum_daily_dose` double DEFAULT NULL,
  `minimum_daily_dose` double DEFAULT NULL,
  `route` int DEFAULT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  `strength` varchar(255) DEFAULT NULL,
  `dose_limit_units` int DEFAULT NULL,
  PRIMARY KEY (`drug_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `dosage_form_concept` (`dosage_form`),
  KEY `drug_changed_by` (`changed_by`),
  KEY `drug_creator` (`creator`),
  KEY `drug_dose_limit_units_fk` (`dose_limit_units`),
  KEY `drug_retired_by` (`retired_by`),
  KEY `primary_drug_concept` (`concept_id`),
  KEY `route_concept` (`route`),
  CONSTRAINT `dosage_form_concept` FOREIGN KEY (`dosage_form`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `drug_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `drug_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `drug_dose_limit_units_fk` FOREIGN KEY (`dose_limit_units`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `drug_retired_by` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `primary_drug_concept` FOREIGN KEY (`concept_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `route_concept` FOREIGN KEY (`route`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drug`
--

LOCK TABLES `drug` WRITE;
/*!40000 ALTER TABLE `drug` DISABLE KEYS */;
/*!40000 ALTER TABLE `drug` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drug_ingredient`
--

DROP TABLE IF EXISTS `drug_ingredient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drug_ingredient` (
  `drug_id` int NOT NULL,
  `ingredient_id` int NOT NULL,
  `uuid` char(38) NOT NULL,
  `strength` double DEFAULT NULL,
  `units` int DEFAULT NULL,
  PRIMARY KEY (`drug_id`,`ingredient_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `drug_ingredient_ingredient_id_fk` (`ingredient_id`),
  KEY `drug_ingredient_units_fk` (`units`),
  CONSTRAINT `drug_ingredient_drug_id_fk` FOREIGN KEY (`drug_id`) REFERENCES `drug` (`drug_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `drug_ingredient_ingredient_id_fk` FOREIGN KEY (`ingredient_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `drug_ingredient_units_fk` FOREIGN KEY (`units`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drug_ingredient`
--

LOCK TABLES `drug_ingredient` WRITE;
/*!40000 ALTER TABLE `drug_ingredient` DISABLE KEYS */;
/*!40000 ALTER TABLE `drug_ingredient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drug_order`
--

DROP TABLE IF EXISTS `drug_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drug_order` (
  `order_id` int NOT NULL DEFAULT '0',
  `drug_inventory_id` int DEFAULT NULL,
  `dose` double DEFAULT NULL,
  `as_needed` tinyint(1) DEFAULT '0',
  `dosing_type` varchar(255) DEFAULT NULL,
  `quantity` double DEFAULT NULL,
  `as_needed_condition` varchar(255) DEFAULT NULL,
  `num_refills` int DEFAULT NULL,
  `dosing_instructions` text,
  `duration` int DEFAULT NULL,
  `duration_units` int DEFAULT NULL,
  `quantity_units` int DEFAULT NULL,
  `route` int DEFAULT NULL,
  `dose_units` int DEFAULT NULL,
  `frequency` int DEFAULT NULL,
  `brand_name` varchar(255) DEFAULT NULL,
  `dispense_as_written` tinyint(1) NOT NULL DEFAULT '0',
  `drug_non_coded` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`order_id`),
  KEY `drug_order_dose_units` (`dose_units`),
  KEY `drug_order_duration_units_fk` (`duration_units`),
  KEY `drug_order_frequency_fk` (`frequency`),
  KEY `drug_order_quantity_units` (`quantity_units`),
  KEY `drug_order_route_fk` (`route`),
  KEY `inventory_item` (`drug_inventory_id`),
  CONSTRAINT `drug_order_dose_units` FOREIGN KEY (`dose_units`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `drug_order_duration_units_fk` FOREIGN KEY (`duration_units`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `drug_order_frequency_fk` FOREIGN KEY (`frequency`) REFERENCES `order_frequency` (`order_frequency_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `drug_order_quantity_units` FOREIGN KEY (`quantity_units`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `drug_order_route_fk` FOREIGN KEY (`route`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `extends_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `inventory_item` FOREIGN KEY (`drug_inventory_id`) REFERENCES `drug` (`drug_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drug_order`
--

LOCK TABLES `drug_order` WRITE;
/*!40000 ALTER TABLE `drug_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `drug_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drug_reference_map`
--

DROP TABLE IF EXISTS `drug_reference_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drug_reference_map` (
  `drug_reference_map_id` int NOT NULL AUTO_INCREMENT,
  `drug_id` int NOT NULL,
  `term_id` int NOT NULL,
  `concept_map_type` int NOT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`drug_reference_map_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `concept_map_type_for_drug_reference_map` (`concept_map_type`),
  KEY `concept_reference_term_for_drug_reference_map` (`term_id`),
  KEY `drug_for_drug_reference_map` (`drug_id`),
  KEY `drug_reference_map_creator` (`creator`),
  KEY `user_who_changed_drug_reference_map` (`changed_by`),
  KEY `user_who_retired_drug_reference_map` (`retired_by`),
  CONSTRAINT `concept_map_type_for_drug_reference_map` FOREIGN KEY (`concept_map_type`) REFERENCES `concept_map_type` (`concept_map_type_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `concept_reference_term_for_drug_reference_map` FOREIGN KEY (`term_id`) REFERENCES `concept_reference_term` (`concept_reference_term_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `drug_for_drug_reference_map` FOREIGN KEY (`drug_id`) REFERENCES `drug` (`drug_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `drug_reference_map_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_changed_drug_reference_map` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_retired_drug_reference_map` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drug_reference_map`
--

LOCK TABLES `drug_reference_map` WRITE;
/*!40000 ALTER TABLE `drug_reference_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `drug_reference_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `encounter`
--

DROP TABLE IF EXISTS `encounter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `encounter` (
  `encounter_id` int NOT NULL AUTO_INCREMENT,
  `encounter_type` int NOT NULL,
  `patient_id` int NOT NULL DEFAULT '0',
  `location_id` int DEFAULT NULL,
  `form_id` int DEFAULT NULL,
  `encounter_datetime` datetime NOT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `visit_id` int DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `encounter_changed_by` (`changed_by`),
  KEY `encounter_datetime_idx` (`encounter_datetime`),
  KEY `encounter_form` (`form_id`),
  KEY `encounter_ibfk_1` (`creator`),
  KEY `encounter_location` (`location_id`),
  KEY `encounter_patient` (`patient_id`),
  KEY `encounter_type_id` (`encounter_type`),
  KEY `encounter_visit_id_fk` (`visit_id`),
  KEY `user_who_voided_encounter` (`voided_by`),
  CONSTRAINT `encounter_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `encounter_form` FOREIGN KEY (`form_id`) REFERENCES `form` (`form_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `encounter_ibfk_1` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `encounter_location` FOREIGN KEY (`location_id`) REFERENCES `location` (`location_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `encounter_patient` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `encounter_type_id` FOREIGN KEY (`encounter_type`) REFERENCES `encounter_type` (`encounter_type_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `encounter_visit_id_fk` FOREIGN KEY (`visit_id`) REFERENCES `visit` (`visit_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_voided_encounter` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `encounter`
--

LOCK TABLES `encounter` WRITE;
/*!40000 ALTER TABLE `encounter` DISABLE KEYS */;
/*!40000 ALTER TABLE `encounter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `encounter_diagnosis`
--

DROP TABLE IF EXISTS `encounter_diagnosis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `encounter_diagnosis` (
  `diagnosis_id` int NOT NULL AUTO_INCREMENT,
  `diagnosis_coded` int DEFAULT NULL,
  `diagnosis_non_coded` varchar(255) DEFAULT NULL,
  `diagnosis_coded_name` int DEFAULT NULL,
  `encounter_id` int NOT NULL,
  `patient_id` int NOT NULL,
  `condition_id` int DEFAULT NULL,
  `certainty` varchar(255) NOT NULL,
  `dx_rank` int NOT NULL,
  `uuid` char(38) NOT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `form_namespace_and_path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`diagnosis_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `encounter_diagnosis_changed_by_fk` (`changed_by`),
  KEY `encounter_diagnosis_coded_fk` (`diagnosis_coded`),
  KEY `encounter_diagnosis_coded_name_fk` (`diagnosis_coded_name`),
  KEY `encounter_diagnosis_condition_id_fk` (`condition_id`),
  KEY `encounter_diagnosis_creator_fk` (`creator`),
  KEY `encounter_diagnosis_encounter_id_fk` (`encounter_id`),
  KEY `encounter_diagnosis_patient_fk` (`patient_id`),
  KEY `encounter_diagnosis_voided_by_fk` (`voided_by`),
  CONSTRAINT `encounter_diagnosis_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `encounter_diagnosis_coded_fk` FOREIGN KEY (`diagnosis_coded`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `encounter_diagnosis_coded_name_fk` FOREIGN KEY (`diagnosis_coded_name`) REFERENCES `concept_name` (`concept_name_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `encounter_diagnosis_condition_id_fk` FOREIGN KEY (`condition_id`) REFERENCES `conditions` (`condition_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `encounter_diagnosis_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `encounter_diagnosis_encounter_id_fk` FOREIGN KEY (`encounter_id`) REFERENCES `encounter` (`encounter_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `encounter_diagnosis_patient_fk` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `encounter_diagnosis_voided_by_fk` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `encounter_diagnosis`
--

LOCK TABLES `encounter_diagnosis` WRITE;
/*!40000 ALTER TABLE `encounter_diagnosis` DISABLE KEYS */;
/*!40000 ALTER TABLE `encounter_diagnosis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `encounter_provider`
--

DROP TABLE IF EXISTS `encounter_provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `encounter_provider` (
  `encounter_provider_id` int NOT NULL AUTO_INCREMENT,
  `encounter_id` int NOT NULL,
  `provider_id` int NOT NULL,
  `encounter_role_id` int NOT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `date_voided` datetime DEFAULT NULL,
  `voided_by` int DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`encounter_provider_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `encounter_id_fk` (`encounter_id`),
  KEY `encounter_provider_changed_by` (`changed_by`),
  KEY `encounter_provider_creator` (`creator`),
  KEY `encounter_provider_voided_by` (`voided_by`),
  KEY `encounter_role_id_fk` (`encounter_role_id`),
  KEY `provider_id_fk` (`provider_id`),
  CONSTRAINT `encounter_id_fk` FOREIGN KEY (`encounter_id`) REFERENCES `encounter` (`encounter_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `encounter_provider_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `encounter_provider_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `encounter_provider_voided_by` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `encounter_role_id_fk` FOREIGN KEY (`encounter_role_id`) REFERENCES `encounter_role` (`encounter_role_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `provider_id_fk` FOREIGN KEY (`provider_id`) REFERENCES `provider` (`provider_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `encounter_provider`
--

LOCK TABLES `encounter_provider` WRITE;
/*!40000 ALTER TABLE `encounter_provider` DISABLE KEYS */;
/*!40000 ALTER TABLE `encounter_provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `encounter_role`
--

DROP TABLE IF EXISTS `encounter_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `encounter_role` (
  `encounter_role_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`encounter_role_id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `encounter_role_changed_by_fk` (`changed_by`),
  KEY `encounter_role_creator_fk` (`creator`),
  KEY `encounter_role_retired_by_fk` (`retired_by`),
  CONSTRAINT `encounter_role_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `encounter_role_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `encounter_role_retired_by_fk` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `encounter_role`
--

LOCK TABLES `encounter_role` WRITE;
/*!40000 ALTER TABLE `encounter_role` DISABLE KEYS */;
INSERT INTO `encounter_role` VALUES (1,'Unknown','Unknown encounter role for legacy providers with no encounter role set',1,'2011-08-18 14:00:00',NULL,NULL,0,NULL,NULL,NULL,'a0b03050-c99b-11e0-9572-0800200c9a66');
/*!40000 ALTER TABLE `encounter_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `encounter_type`
--

DROP TABLE IF EXISTS `encounter_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `encounter_type` (
  `encounter_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` text,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  `edit_privilege` varchar(255) DEFAULT NULL,
  `view_privilege` varchar(255) DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  PRIMARY KEY (`encounter_type_id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `encounter_type_changed_by` (`changed_by`),
  KEY `encounter_type_retired_status` (`retired`),
  KEY `privilege_which_can_edit_encounter_type` (`edit_privilege`),
  KEY `privilege_which_can_view_encounter_type` (`view_privilege`),
  KEY `user_who_created_type` (`creator`),
  KEY `user_who_retired_encounter_type` (`retired_by`),
  CONSTRAINT `encounter_type_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `privilege_which_can_edit_encounter_type` FOREIGN KEY (`edit_privilege`) REFERENCES `privilege` (`privilege`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `privilege_which_can_view_encounter_type` FOREIGN KEY (`view_privilege`) REFERENCES `privilege` (`privilege`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_created_type` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_retired_encounter_type` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `encounter_type`
--

LOCK TABLES `encounter_type` WRITE;
/*!40000 ALTER TABLE `encounter_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `encounter_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fhir_concept_source`
--

DROP TABLE IF EXISTS `fhir_concept_source`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fhir_concept_source` (
  `fhir_concept_source_id` int NOT NULL AUTO_INCREMENT,
  `concept_source_id` int DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` varchar(38) NOT NULL,
  PRIMARY KEY (`fhir_concept_source_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `fhir_concept_source_concept_reference_source_fk` (`concept_source_id`),
  KEY `fhir_concept_source_creator_fk` (`creator`),
  KEY `fhir_concept_source_changed_by_fk` (`changed_by`),
  KEY `fhir_concept_source_retired_by_fk` (`retired_by`),
  CONSTRAINT `fhir_concept_source_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`),
  CONSTRAINT `fhir_concept_source_concept_reference_source_fk` FOREIGN KEY (`concept_source_id`) REFERENCES `concept_reference_source` (`concept_source_id`),
  CONSTRAINT `fhir_concept_source_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`),
  CONSTRAINT `fhir_concept_source_retired_by_fk` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fhir_concept_source`
--

LOCK TABLES `fhir_concept_source` WRITE;
/*!40000 ALTER TABLE `fhir_concept_source` DISABLE KEYS */;
/*!40000 ALTER TABLE `fhir_concept_source` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fhir_contact_point_map`
--

DROP TABLE IF EXISTS `fhir_contact_point_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fhir_contact_point_map` (
  `fhir_contact_point_map_id` int NOT NULL AUTO_INCREMENT,
  `attribute_type_domain` varchar(100) NOT NULL,
  `attribute_type_id` int NOT NULL,
  `rank` int DEFAULT NULL,
  `system` varchar(50) DEFAULT NULL,
  `use` varchar(50) DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `date_voided` datetime DEFAULT NULL,
  `voided_by` int DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `uuid` varchar(38) NOT NULL,
  PRIMARY KEY (`fhir_contact_point_map_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `fhir_contact_point_map_creator_fk` (`creator`),
  KEY `fhir_contact_point_map_changed_by_fk` (`changed_by`),
  KEY `fhir_contact_point_map_voided_by_fk` (`voided_by`),
  KEY `fhir_contact_point_map_attribute_type_domain_id` (`attribute_type_domain`,`attribute_type_id`),
  CONSTRAINT `fhir_contact_point_map_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`),
  CONSTRAINT `fhir_contact_point_map_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`),
  CONSTRAINT `fhir_contact_point_map_voided_by_fk` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fhir_contact_point_map`
--

LOCK TABLES `fhir_contact_point_map` WRITE;
/*!40000 ALTER TABLE `fhir_contact_point_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `fhir_contact_point_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fhir_diagnostic_report`
--

DROP TABLE IF EXISTS `fhir_diagnostic_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fhir_diagnostic_report` (
  `diagnostic_report_id` int NOT NULL AUTO_INCREMENT,
  `status` varchar(50) NOT NULL,
  `concept_id` int DEFAULT NULL,
  `subject_id` int DEFAULT NULL,
  `encounter_id` int DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  `issued` datetime DEFAULT NULL,
  PRIMARY KEY (`diagnostic_report_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `fhir_diagnostic_report_creator` (`creator`),
  KEY `fhir_diagnostic_report_changed_by` (`changed_by`),
  KEY `fhir_diagnostic_report_voided_by` (`voided_by`),
  KEY `fhir_diagnostic_report_code` (`concept_id`),
  KEY `fhir_diagnostic_report_subject` (`subject_id`),
  KEY `fhir_diagnostic_report_encounter` (`encounter_id`),
  CONSTRAINT `fhir_diagnostic_report_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`),
  CONSTRAINT `fhir_diagnostic_report_code` FOREIGN KEY (`concept_id`) REFERENCES `concept` (`concept_id`),
  CONSTRAINT `fhir_diagnostic_report_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`),
  CONSTRAINT `fhir_diagnostic_report_encounter` FOREIGN KEY (`encounter_id`) REFERENCES `encounter` (`encounter_id`),
  CONSTRAINT `fhir_diagnostic_report_subject` FOREIGN KEY (`subject_id`) REFERENCES `patient` (`patient_id`),
  CONSTRAINT `fhir_diagnostic_report_voided_by` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fhir_diagnostic_report`
--

LOCK TABLES `fhir_diagnostic_report` WRITE;
/*!40000 ALTER TABLE `fhir_diagnostic_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `fhir_diagnostic_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fhir_diagnostic_report_performers`
--

DROP TABLE IF EXISTS `fhir_diagnostic_report_performers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fhir_diagnostic_report_performers` (
  `diagnostic_report_id` int NOT NULL,
  `provider_id` int NOT NULL,
  PRIMARY KEY (`diagnostic_report_id`,`provider_id`),
  KEY `fhir_diagnostic_report_performers_reference` (`provider_id`),
  CONSTRAINT `fhir_diagnostic_report_performers_diagnostic_report` FOREIGN KEY (`diagnostic_report_id`) REFERENCES `fhir_diagnostic_report` (`diagnostic_report_id`),
  CONSTRAINT `fhir_diagnostic_report_performers_reference` FOREIGN KEY (`provider_id`) REFERENCES `provider` (`provider_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fhir_diagnostic_report_performers`
--

LOCK TABLES `fhir_diagnostic_report_performers` WRITE;
/*!40000 ALTER TABLE `fhir_diagnostic_report_performers` DISABLE KEYS */;
/*!40000 ALTER TABLE `fhir_diagnostic_report_performers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fhir_diagnostic_report_results`
--

DROP TABLE IF EXISTS `fhir_diagnostic_report_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fhir_diagnostic_report_results` (
  `diagnostic_report_id` int NOT NULL,
  `obs_id` int NOT NULL,
  PRIMARY KEY (`diagnostic_report_id`,`obs_id`),
  KEY `fhir_diagnostic_report_results_reference` (`obs_id`),
  CONSTRAINT `fhir_diagnostic_report_results_diagnostic_report` FOREIGN KEY (`diagnostic_report_id`) REFERENCES `fhir_diagnostic_report` (`diagnostic_report_id`),
  CONSTRAINT `fhir_diagnostic_report_results_reference` FOREIGN KEY (`obs_id`) REFERENCES `obs` (`obs_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fhir_diagnostic_report_results`
--

LOCK TABLES `fhir_diagnostic_report_results` WRITE;
/*!40000 ALTER TABLE `fhir_diagnostic_report_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `fhir_diagnostic_report_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fhir_encounter_class_map`
--

DROP TABLE IF EXISTS `fhir_encounter_class_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fhir_encounter_class_map` (
  `encounter_class_map_id` int NOT NULL AUTO_INCREMENT,
  `location_id` int DEFAULT NULL,
  `encounter_class` varchar(255) DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retired_reason` varchar(255) DEFAULT NULL,
  `uuid` char(36) NOT NULL,
  PRIMARY KEY (`encounter_class_map_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `fhir_encounter_class_map_creator` (`creator`),
  KEY `fhir_encounter_class_map_changed_by` (`changed_by`),
  KEY `fhir_encounter_class_map_retired_by` (`retired_by`),
  KEY `fhir_encounter_class_map_location` (`location_id`),
  CONSTRAINT `fhir_encounter_class_map_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`),
  CONSTRAINT `fhir_encounter_class_map_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`),
  CONSTRAINT `fhir_encounter_class_map_location` FOREIGN KEY (`location_id`) REFERENCES `location` (`location_id`),
  CONSTRAINT `fhir_encounter_class_map_retired_by` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fhir_encounter_class_map`
--

LOCK TABLES `fhir_encounter_class_map` WRITE;
/*!40000 ALTER TABLE `fhir_encounter_class_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `fhir_encounter_class_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fhir_observation_category_map`
--

DROP TABLE IF EXISTS `fhir_observation_category_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fhir_observation_category_map` (
  `observation_category_map_id` int NOT NULL AUTO_INCREMENT,
  `concept_class_id` int DEFAULT NULL,
  `observation_category` varchar(255) NOT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retired_reason` varchar(255) DEFAULT NULL,
  `uuid` char(36) NOT NULL,
  PRIMARY KEY (`observation_category_map_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `fhir_observation_category_map_creator` (`creator`),
  KEY `fhir_observation_category_map_changed_by` (`changed_by`),
  KEY `fhir_observation_category_map_retired_by` (`retired_by`),
  KEY `fhir_observation_category_map_concept_class` (`concept_class_id`),
  KEY `fhir_observation_category_map_observation_category` (`observation_category`),
  CONSTRAINT `fhir_observation_category_map_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`),
  CONSTRAINT `fhir_observation_category_map_concept_class` FOREIGN KEY (`concept_class_id`) REFERENCES `concept_class` (`concept_class_id`),
  CONSTRAINT `fhir_observation_category_map_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`),
  CONSTRAINT `fhir_observation_category_map_retired_by` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fhir_observation_category_map`
--

LOCK TABLES `fhir_observation_category_map` WRITE;
/*!40000 ALTER TABLE `fhir_observation_category_map` DISABLE KEYS */;
INSERT INTO `fhir_observation_category_map` VALUES (1,1,'laboratory',1,'2025-05-15 15:43:51',NULL,NULL,0,NULL,NULL,NULL,'41518422-318a-11f0-b092-0b65da17e126'),(2,2,'procedure',1,'2025-05-15 15:43:51',NULL,NULL,0,NULL,NULL,NULL,'41519e8a-318a-11f0-b092-0b65da17e126'),(3,5,'exam',1,'2025-05-15 15:43:51',NULL,NULL,0,NULL,NULL,NULL,'4151cb12-318a-11f0-b092-0b65da17e126');
/*!40000 ALTER TABLE `fhir_observation_category_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fhir_patient_identifier_system`
--

DROP TABLE IF EXISTS `fhir_patient_identifier_system`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fhir_patient_identifier_system` (
  `fhir_patient_identifier_system_id` int NOT NULL AUTO_INCREMENT,
  `patient_identifier_type_id` int DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` varchar(38) NOT NULL,
  PRIMARY KEY (`fhir_patient_identifier_system_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `fhir_patient_identifier_system_patient_identifier_type_fk` (`patient_identifier_type_id`),
  KEY `fhir_patient_identifier_system_creator_fk` (`creator`),
  KEY `fhir_patient_identifier_system_changed_by_fk` (`changed_by`),
  KEY `fhir_patient_identifier_system_retired_by_fk` (`retired_by`),
  CONSTRAINT `fhir_patient_identifier_system_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`),
  CONSTRAINT `fhir_patient_identifier_system_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`),
  CONSTRAINT `fhir_patient_identifier_system_patient_identifier_type_fk` FOREIGN KEY (`patient_identifier_type_id`) REFERENCES `patient_identifier_type` (`patient_identifier_type_id`),
  CONSTRAINT `fhir_patient_identifier_system_retired_by_fk` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fhir_patient_identifier_system`
--

LOCK TABLES `fhir_patient_identifier_system` WRITE;
/*!40000 ALTER TABLE `fhir_patient_identifier_system` DISABLE KEYS */;
/*!40000 ALTER TABLE `fhir_patient_identifier_system` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fhir_reference`
--

DROP TABLE IF EXISTS `fhir_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fhir_reference` (
  `reference_id` int NOT NULL AUTO_INCREMENT,
  `target_type` varchar(255) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` varchar(38) NOT NULL,
  `target_uuid` char(38) DEFAULT NULL,
  PRIMARY KEY (`reference_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `fhir_reference_creator_fk` (`creator`),
  KEY `fhir_reference_changed_by_fk` (`changed_by`),
  KEY `fhir_reference_retired_by_fk` (`retired_by`),
  CONSTRAINT `fhir_reference_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`),
  CONSTRAINT `fhir_reference_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`),
  CONSTRAINT `fhir_reference_retired_by_fk` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fhir_reference`
--

LOCK TABLES `fhir_reference` WRITE;
/*!40000 ALTER TABLE `fhir_reference` DISABLE KEYS */;
/*!40000 ALTER TABLE `fhir_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fhir_task`
--

DROP TABLE IF EXISTS `fhir_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fhir_task` (
  `task_id` int NOT NULL AUTO_INCREMENT,
  `status` varchar(255) NOT NULL DEFAULT 'UNKNOWN',
  `status_reason` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  `intent` varchar(255) NOT NULL,
  `owner_reference_id` int DEFAULT NULL,
  `encounter_reference_id` int DEFAULT NULL,
  `for_reference_id` int DEFAULT NULL,
  `based_on` varchar(255) DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `location_reference_id` int DEFAULT NULL,
  `execution_start_time` datetime DEFAULT NULL,
  `execution_end_time` datetime DEFAULT NULL,
  `task_code` int DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`task_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `task_creator` (`creator`),
  KEY `task_changed_by` (`changed_by`),
  KEY `fhir_task_retired_by_fk` (`retired_by`),
  KEY `task_owner_reference_fk` (`owner_reference_id`),
  KEY `task_for_reference_fk` (`for_reference_id`),
  KEY `task_encounter_reference_fk` (`encounter_reference_id`),
  KEY `task_location_reference_fk` (`location_reference_id`),
  KEY `task_code_fk` (`task_code`),
  CONSTRAINT `fhir_task_retired_by_fk` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`),
  CONSTRAINT `task_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`),
  CONSTRAINT `task_code_fk` FOREIGN KEY (`task_code`) REFERENCES `concept` (`concept_id`),
  CONSTRAINT `task_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`),
  CONSTRAINT `task_encounter_reference_fk` FOREIGN KEY (`encounter_reference_id`) REFERENCES `fhir_reference` (`reference_id`),
  CONSTRAINT `task_for_reference_fk` FOREIGN KEY (`for_reference_id`) REFERENCES `fhir_reference` (`reference_id`),
  CONSTRAINT `task_location_reference_fk` FOREIGN KEY (`location_reference_id`) REFERENCES `fhir_reference` (`reference_id`),
  CONSTRAINT `task_owner_reference_fk` FOREIGN KEY (`owner_reference_id`) REFERENCES `fhir_reference` (`reference_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fhir_task`
--

LOCK TABLES `fhir_task` WRITE;
/*!40000 ALTER TABLE `fhir_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `fhir_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fhir_task_based_on_reference`
--

DROP TABLE IF EXISTS `fhir_task_based_on_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fhir_task_based_on_reference` (
  `task_id` int NOT NULL,
  `reference_id` int NOT NULL,
  UNIQUE KEY `reference_id` (`reference_id`),
  KEY `task_based_on_fk` (`task_id`),
  CONSTRAINT `reference_based_on_fk` FOREIGN KEY (`reference_id`) REFERENCES `fhir_reference` (`reference_id`),
  CONSTRAINT `task_based_on_fk` FOREIGN KEY (`task_id`) REFERENCES `fhir_task` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fhir_task_based_on_reference`
--

LOCK TABLES `fhir_task_based_on_reference` WRITE;
/*!40000 ALTER TABLE `fhir_task_based_on_reference` DISABLE KEYS */;
/*!40000 ALTER TABLE `fhir_task_based_on_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fhir_task_input`
--

DROP TABLE IF EXISTS `fhir_task_input`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fhir_task_input` (
  `task_input_id` int NOT NULL AUTO_INCREMENT,
  `task_id` int DEFAULT NULL,
  `type_id` int DEFAULT NULL,
  `value_datetime` datetime DEFAULT NULL,
  `value_numeric` double DEFAULT NULL,
  `value_text` varchar(255) DEFAULT NULL,
  `value_reference_id` int DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` varchar(38) NOT NULL,
  PRIMARY KEY (`task_input_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `fhir_task_input_creator_fk` (`creator`),
  KEY `fhir_task_input_changed_by_fk` (`changed_by`),
  KEY `fhir_task_input_retired_by_fk` (`retired_by`),
  KEY `input_type_fk` (`type_id`),
  KEY `input_reference_fk` (`value_reference_id`),
  KEY `input_task_fk` (`task_id`),
  CONSTRAINT `fhir_task_input_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`),
  CONSTRAINT `fhir_task_input_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`),
  CONSTRAINT `fhir_task_input_retired_by_fk` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`),
  CONSTRAINT `input_reference_fk` FOREIGN KEY (`value_reference_id`) REFERENCES `fhir_reference` (`reference_id`),
  CONSTRAINT `input_task_fk` FOREIGN KEY (`task_id`) REFERENCES `fhir_task` (`task_id`),
  CONSTRAINT `input_type_fk` FOREIGN KEY (`type_id`) REFERENCES `concept` (`concept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fhir_task_input`
--

LOCK TABLES `fhir_task_input` WRITE;
/*!40000 ALTER TABLE `fhir_task_input` DISABLE KEYS */;
/*!40000 ALTER TABLE `fhir_task_input` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fhir_task_output`
--

DROP TABLE IF EXISTS `fhir_task_output`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fhir_task_output` (
  `task_output_id` int NOT NULL AUTO_INCREMENT,
  `task_id` int DEFAULT NULL,
  `type_id` int NOT NULL,
  `value_datetime` datetime DEFAULT NULL,
  `value_numeric` double DEFAULT NULL,
  `value_text` varchar(255) DEFAULT NULL,
  `value_reference_id` int DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` varchar(38) NOT NULL,
  PRIMARY KEY (`task_output_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `fhir_task_output_creator_fk` (`creator`),
  KEY `fhir_task_output_changed_by_fk` (`changed_by`),
  KEY `fhir_task_output_retired_by_fk` (`retired_by`),
  KEY `output_type_fk` (`type_id`),
  KEY `output_reference_fk` (`value_reference_id`),
  KEY `output_task_fk` (`task_id`),
  CONSTRAINT `fhir_task_output_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`),
  CONSTRAINT `fhir_task_output_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`),
  CONSTRAINT `fhir_task_output_retired_by_fk` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`),
  CONSTRAINT `output_reference_fk` FOREIGN KEY (`value_reference_id`) REFERENCES `fhir_reference` (`reference_id`),
  CONSTRAINT `output_task_fk` FOREIGN KEY (`task_id`) REFERENCES `fhir_task` (`task_id`),
  CONSTRAINT `output_type_fk` FOREIGN KEY (`type_id`) REFERENCES `concept` (`concept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fhir_task_output`
--

LOCK TABLES `fhir_task_output` WRITE;
/*!40000 ALTER TABLE `fhir_task_output` DISABLE KEYS */;
/*!40000 ALTER TABLE `fhir_task_output` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fhir_task_part_of_reference`
--

DROP TABLE IF EXISTS `fhir_task_part_of_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fhir_task_part_of_reference` (
  `task_id` int NOT NULL,
  `reference_id` int NOT NULL,
  KEY `task_part_of_fk` (`task_id`),
  KEY `reference_part_of_fk` (`reference_id`),
  CONSTRAINT `reference_part_of_fk` FOREIGN KEY (`reference_id`) REFERENCES `fhir_reference` (`reference_id`),
  CONSTRAINT `task_part_of_fk` FOREIGN KEY (`task_id`) REFERENCES `fhir_task` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fhir_task_part_of_reference`
--

LOCK TABLES `fhir_task_part_of_reference` WRITE;
/*!40000 ALTER TABLE `fhir_task_part_of_reference` DISABLE KEYS */;
/*!40000 ALTER TABLE `fhir_task_part_of_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field`
--

DROP TABLE IF EXISTS `field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `field` (
  `field_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `field_type` int DEFAULT NULL,
  `concept_id` int DEFAULT NULL,
  `table_name` varchar(50) DEFAULT NULL,
  `attribute_name` varchar(50) DEFAULT NULL,
  `default_value` text,
  `select_multiple` tinyint(1) NOT NULL DEFAULT '0',
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`field_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `concept_for_field` (`concept_id`),
  KEY `field_retired_status` (`retired`),
  KEY `type_of_field` (`field_type`),
  KEY `user_who_changed_field` (`changed_by`),
  KEY `user_who_created_field` (`creator`),
  KEY `user_who_retired_field` (`retired_by`),
  CONSTRAINT `concept_for_field` FOREIGN KEY (`concept_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `type_of_field` FOREIGN KEY (`field_type`) REFERENCES `field_type` (`field_type_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_changed_field` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_created_field` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_retired_field` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field`
--

LOCK TABLES `field` WRITE;
/*!40000 ALTER TABLE `field` DISABLE KEYS */;
/*!40000 ALTER TABLE `field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_answer`
--

DROP TABLE IF EXISTS `field_answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_answer` (
  `field_id` int NOT NULL DEFAULT '0',
  `answer_id` int NOT NULL DEFAULT '0',
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`field_id`,`answer_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `field_answer_concept` (`answer_id`),
  KEY `user_who_created_field_answer` (`creator`),
  CONSTRAINT `answers_for_field` FOREIGN KEY (`field_id`) REFERENCES `field` (`field_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `field_answer_concept` FOREIGN KEY (`answer_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_created_field_answer` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_answer`
--

LOCK TABLES `field_answer` WRITE;
/*!40000 ALTER TABLE `field_answer` DISABLE KEYS */;
/*!40000 ALTER TABLE `field_answer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_type`
--

DROP TABLE IF EXISTS `field_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_type` (
  `field_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `description` text,
  `is_set` tinyint(1) NOT NULL DEFAULT '0',
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`field_type_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `user_who_created_field_type` (`creator`),
  CONSTRAINT `user_who_created_field_type` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_type`
--

LOCK TABLES `field_type` WRITE;
/*!40000 ALTER TABLE `field_type` DISABLE KEYS */;
INSERT INTO `field_type` VALUES (1,'Concept','',0,1,'2005-02-22 00:00:00','8d5e7d7c-c2cc-11de-8d13-0010c6dffd0f'),(2,'Database element','',0,1,'2005-02-22 00:00:00','8d5e8196-c2cc-11de-8d13-0010c6dffd0f'),(3,'Set of Concepts','',1,1,'2005-02-22 00:00:00','8d5e836c-c2cc-11de-8d13-0010c6dffd0f'),(4,'Miscellaneous Set','',1,1,'2005-02-22 00:00:00','8d5e852e-c2cc-11de-8d13-0010c6dffd0f'),(5,'Section','',1,1,'2005-02-22 00:00:00','8d5e86fa-c2cc-11de-8d13-0010c6dffd0f');
/*!40000 ALTER TABLE `field_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form`
--

DROP TABLE IF EXISTS `form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `form` (
  `form_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `version` varchar(50) NOT NULL DEFAULT '',
  `build` int DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `xslt` text,
  `template` text,
  `description` text,
  `encounter_type` int DEFAULT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retired_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`form_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `form_encounter_type` (`encounter_type`),
  KEY `form_published_and_retired_index` (`published`,`retired`),
  KEY `form_published_index` (`published`),
  KEY `form_retired_index` (`retired`),
  KEY `user_who_created_form` (`creator`),
  KEY `user_who_last_changed_form` (`changed_by`),
  KEY `user_who_retired_form` (`retired_by`),
  CONSTRAINT `form_encounter_type` FOREIGN KEY (`encounter_type`) REFERENCES `encounter_type` (`encounter_type_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_created_form` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_last_changed_form` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_retired_form` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form`
--

LOCK TABLES `form` WRITE;
/*!40000 ALTER TABLE `form` DISABLE KEYS */;
/*!40000 ALTER TABLE `form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_field`
--

DROP TABLE IF EXISTS `form_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_field` (
  `form_field_id` int NOT NULL AUTO_INCREMENT,
  `form_id` int NOT NULL DEFAULT '0',
  `field_id` int NOT NULL DEFAULT '0',
  `field_number` int DEFAULT NULL,
  `field_part` varchar(5) DEFAULT NULL,
  `page_number` int DEFAULT NULL,
  `parent_form_field` int DEFAULT NULL,
  `min_occurs` int DEFAULT NULL,
  `max_occurs` int DEFAULT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `sort_weight` float DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`form_field_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `field_within_form` (`field_id`),
  KEY `form_containing_field` (`form_id`),
  KEY `form_field_hierarchy` (`parent_form_field`),
  KEY `user_who_created_form_field` (`creator`),
  KEY `user_who_last_changed_form_field` (`changed_by`),
  CONSTRAINT `field_within_form` FOREIGN KEY (`field_id`) REFERENCES `field` (`field_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `form_containing_field` FOREIGN KEY (`form_id`) REFERENCES `form` (`form_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `form_field_hierarchy` FOREIGN KEY (`parent_form_field`) REFERENCES `form_field` (`form_field_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_created_form_field` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_last_changed_form_field` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_field`
--

LOCK TABLES `form_field` WRITE;
/*!40000 ALTER TABLE `form_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_resource`
--

DROP TABLE IF EXISTS `form_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_resource` (
  `form_resource_id` int NOT NULL AUTO_INCREMENT,
  `form_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `value_reference` text NOT NULL,
  `datatype` varchar(255) DEFAULT NULL,
  `datatype_config` text,
  `preferred_handler` varchar(255) DEFAULT NULL,
  `handler_config` text,
  `uuid` char(38) NOT NULL,
  `date_changed` datetime DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  PRIMARY KEY (`form_resource_id`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `unique_form_and_name` (`form_id`,`name`),
  KEY `form_resource_changed_by` (`changed_by`),
  CONSTRAINT `form_resource_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `form_resource_form_fk` FOREIGN KEY (`form_id`) REFERENCES `form` (`form_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_resource`
--

LOCK TABLES `form_resource` WRITE;
/*!40000 ALTER TABLE `form_resource` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `global_property`
--

DROP TABLE IF EXISTS `global_property`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `global_property` (
  `property` varchar(255) NOT NULL DEFAULT '',
  `property_value` text,
  `description` text,
  `uuid` char(38) NOT NULL,
  `datatype` varchar(255) DEFAULT NULL,
  `datatype_config` text,
  `preferred_handler` varchar(255) DEFAULT NULL,
  `handler_config` text,
  `date_changed` datetime DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  `view_privilege` varchar(255) DEFAULT NULL,
  `edit_privilege` varchar(255) DEFAULT NULL,
  `delete_privilege` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`property`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `global_property_changed_by` (`changed_by`),
  KEY `global_property_delete_privilege_fk` (`delete_privilege`),
  KEY `global_property_edit_privilege_fk` (`edit_privilege`),
  KEY `global_property_view_privilege_fk` (`view_privilege`),
  CONSTRAINT `global_property_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `global_property_delete_privilege_fk` FOREIGN KEY (`delete_privilege`) REFERENCES `privilege` (`privilege`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `global_property_edit_privilege_fk` FOREIGN KEY (`edit_privilege`) REFERENCES `privilege` (`privilege`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `global_property_view_privilege_fk` FOREIGN KEY (`view_privilege`) REFERENCES `privilege` (`privilege`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `global_property`
--

LOCK TABLES `global_property` WRITE;
/*!40000 ALTER TABLE `global_property` DISABLE KEYS */;
INSERT INTO `global_property` VALUES ('allergy.allergen.ConceptClasses','Drug,MedSet','A comma-separated list of the allowed concept classes for the allergen field of the allergy dialog','eaf3f161-3752-412e-9a88-7bba5b702345',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('allergy.concept.allergen.drug','162552AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA','UUID for the drug allergens concept','73901ac7-58af-4af7-ba24-84d4fa6cc5b9',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('allergy.concept.allergen.environment','162554AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA','UUID for the environment allergens concept','11df86f4-9ac9-4ef0-9c27-794b6e80ac30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('allergy.concept.allergen.food','162553AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA','UUID for the food allergens concept','7a5d3497-9451-43e3-9875-577401e7e3e8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('allergy.concept.otherNonCoded','5622AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA','UUID for the allergy other non coded concept','e58daa38-3811-44b1-b46e-576c33ef15c0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('allergy.concept.reactions','162555AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA','UUID for the allergy reactions concept','b31775b0-c9f7-4182-b5b3-8215057d0c36',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('allergy.concept.severity.mild','1498AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA','UUID for the MILD severity concept','9cfc01ef-aed3-429f-afd7-5f5a85c1a8ee',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('allergy.concept.severity.moderate','1499AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA','UUID for the MODERATE severity concept','48acac7b-3eb4-4aff-ae1b-19ce279ca7b6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('allergy.concept.severity.severe','1500AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA','UUID for the SEVERE severity concept','4fa87d11-8875-49d1-87d2-2750397670af',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('allergy.concept.unknown','1067AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA','UUID for the allergy unknown concept','7e0827a8-d31b-4977-9b9a-fd8c2e2725f2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('allergy.reaction.ConceptClasses','Symptom','A comma-separated list of the allowed concept classes for the reaction field of the allergy dialog','5362e179-b305-4f3d-a689-1171cfcd5cbc',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('application.name','OpenMRS','The name of this application, as presented to the user, for example on the login and welcome pages.','e7681fbd-f513-40a2-bfdc-0c81c43842f4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('concept.defaultConceptMapType','NARROWER-THAN','Default concept map type which is used when no other is set','568e3a0f-77b2-4c9b-9509-d48dbc7c0957',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('conceptDrug.dosageForm.conceptClasses',NULL,'A comma-separated list of the allowed concept classes for the dosage form field of the concept drug management form.','82290e93-eab7-40a3-8442-5169a9f2cacf',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('conceptDrug.route.conceptClasses',NULL,'A comma-separated list of the allowed concept classes for the route field of the concept drug management form.','3ce0bad3-09e2-4aac-8359-abed0fc69490',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('concepts.locked','false','if true, do not allow editing concepts','edeaadd0-3ecf-4f80-86c9-a11634cab259','org.openmrs.customdatatype.datatype.BooleanDatatype',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('concept_map_type_management.enable','false','Enables or disables management of concept map types','29b994cf-b5b6-4b08-8308-b0fbeb066407','org.openmrs.customdatatype.datatype.BooleanDatatype',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('dashboard.encounters.maximumNumberToShow','3','An integer which, if specified, would determine the maximum number of encounters to display on the encounter tab of the patient dashboard.','f8b9de03-d4cf-420c-805b-e216f7735c2f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('dashboard.encounters.providerDisplayRoles',NULL,'A comma-separated list of encounter roles (by name or id). Providers with these roles in an encounter will be displayed on the encounter tab of the patient dashboard.','8a5fe900-f468-44a1-a92b-844766e863a6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('dashboard.encounters.showEditLink','true','true/false whether or not to show the \'Edit Encounter\' link on the patient dashboard','1c3728bc-eb24-411b-adaf-960c6e2cf78c','org.openmrs.customdatatype.datatype.BooleanDatatype',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('dashboard.encounters.showEmptyFields','true','true/false whether or not to show empty fields on the \'View Encounter\' window','26f8a463-dbc3-4398-a224-ed3f8fbd2e37','org.openmrs.customdatatype.datatype.BooleanDatatype',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('dashboard.encounters.showViewLink','true','true/false whether or not to show the \'View Encounter\' link on the patient dashboard','3ba232cb-c046-41b0-9ef7-38bece3a9520','org.openmrs.customdatatype.datatype.BooleanDatatype',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('dashboard.encounters.usePages','smart','true/false/smart on how to show the pages on the \'View Encounter\' window.  \'smart\' means that if > 50% of the fields have page numbers defined, show data in pages','042ff68c-a802-4e13-b4d2-195fc2ce776f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('dashboard.header.programs_to_show',NULL,'List of programs to show Enrollment details of in the patient header. (Should be an ordered comma-separated list of program_ids or names.)','b03b7a65-001e-4280-9b0e-c37ff229db96',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('dashboard.header.workflows_to_show',NULL,'List of programs to show Enrollment details of in the patient header. List of workflows to show current status of in the patient header. These will only be displayed if they belong to a program listed above. (Should be a comma-separated list of program_workflow_ids.)','81839be8-43cb-43fd-b1ba-7905d0bb85e9',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('dashboard.metadata.caseConversion',NULL,'Indicates which type automatic case conversion is applied to program/workflow/state in the patient dashboard. Valid values: lowercase, uppercase, capitalize. If empty no conversion is applied.','9c2e3714-9885-46e2-928c-1a5ec7a8ca28',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('dashboard.overview.showConcepts',NULL,'Comma delimited list of concepts ids to show on the patient dashboard overview tab','d84d155b-a2cc-439e-a4a3-ab8a8363bd9f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('dashboard.regimen.displayDrugSetIds','ANTIRETROVIRAL DRUGS,TUBERCULOSIS TREATMENT DRUGS','Drug sets that appear on the Patient Dashboard Regimen tab. Comma separated list of name of concepts that are defined as drug sets.','263d4083-3c2c-499b-98d7-53bd83f9b7de',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('dashboard.regimen.displayFrequencies','7 days/week,6 days/week,5 days/week,4 days/week,3 days/week,2 days/week,1 days/week','Frequency of a drug order that appear on the Patient Dashboard. Comma separated list of name of concepts that are defined as drug frequencies.','69142fe9-886d-4a2f-839e-81f590f4595a',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('dashboard.relationships.show_types',NULL,'Types of relationships separated by commas.  Doctor/Patient,Parent/Child','f21c41a3-d997-46df-8656-366f51299539',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('dashboard.showPatientName','false','Whether or not to display the patient name in the patient dashboard title. Note that enabling this could be security risk if multiple users operate on the same computer.','397a09b8-3fd4-49d9-898c-6c4d2f75a032','org.openmrs.customdatatype.datatype.BooleanDatatype',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('datePicker.weekStart','0','First day of the week in the date picker. Domingo/Dimanche/Sunday:0  Lunes/Lundi/Monday:1','d0352c10-93d4-4f6e-a845-439ccab5f598',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('default_locale','en','Specifies the default locale. You can specify both the language code(ISO-639) and the country code(ISO-3166), e.g. \'en_GB\' or just country: e.g. \'en\'','a152b28a-08dd-438f-a9d4-e409b95c1add',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('default_location','Unknown Location','The name of the location to use as a system default','8dc531c6-f132-4ae0-ac33-0feb276e50b0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('default_theme',NULL,'Default theme for users.  OpenMRS ships with themes of \'green\', \'orange\', \'purple\', and \'legacy\'','4733581d-d84e-4373-b019-9e4d3ee552e6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('drugOrder.drugOther',NULL,'Specifies the uuid of the concept which represents drug other non coded','4fe96ffd-c390-4167-92aa-3a9c54057430',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('drugOrder.requireDrug','false','Set to value true if you need to specify a formulation(Drug) when creating a drug order.','ea3b521f-4eb7-441c-bfaf-5ac523c2fe0c',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('drugOrder.requireOutpatientQuantity','true','true/false whether to require quantity, quantityUnits, and numRefills for outpatient drug orders','8b9e5f86-7c17-4c4e-ae46-0afca4fc977a',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('encounterForm.obsSortOrder','number','The sort order for the obs listed on the encounter edit form.  \'number\' sorts on the associated numbering from the form schema.  \'weight\' sorts on the order displayed in the form schema.','fc3671ef-c777-4878-87a7-977b59d5669a',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('EncounterType.encounterTypes.locked','false','saving, retiring or deleting an Encounter Type is not permitted, if true','999c7e01-c3bc-44b7-800d-42fa489fec7b','org.openmrs.customdatatype.datatype.BooleanDatatype',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('fhir2.administeringEncounterRoleUuid','546cce2d-6d58-4097-ba92-206c1a2a0462','Set administering encounter role uuid','16725131-468d-458e-931d-4ed8b56e21cf',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('fhir2.immunizationsEncounterTypeUuid','29c02aff-9a93-46c9-bf6f-48b552fcb1fa','Set immunizations encounter type uuid','06948da4-cf47-49a6-9456-e4e81280a37f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('fhir2.locationContactPointAttributeTypeUuid','abcde432-1691-11df-97a5-7038c432abcd','Set location attribute type uuid','c0678bcd-d811-452c-a519-966fd59be100',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('fhir2.locationTypeAttributeTypeUuid',NULL,'The UUID for the Location Attribute Type representing the Location Type','621b6ec4-caab-465f-9a5f-89b58d40433e',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('fhir2.mandatory','false','true/false whether or not the fhir2 module MUST start when openmrs starts.  This is used to make sure that mission critical modules are always running if openmrs is running.','ffcfd34c-5c57-44fa-8dfd-0df18c37aff8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('fhir2.narrativesOverridePropertyFile',NULL,'Path of narrative override properties file','92a6177e-e3c3-4432-8fbd-05c2c8a56214',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('fhir2.paging.default','10','Set default page size','5e81ac90-f08a-4320-9f9f-7326a5381f51',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('fhir2.paging.maximum','100','Set maximum page size','7cc3a2ac-66da-4ae1-8b12-721354a0db07',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('fhir2.personAttributeTypeUuid','14d4f066-15f5-102d-96e4-000c29c2a5d7','Set person attribute type uuid','c2deac8b-c1d1-4ab3-a85d-af503b516981',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('fhir2.personContactPointAttributeTypeUuid','14d4f066-15f5-102d-96e4-000c29c2a5d7','Set person attribute type uuid','d702c266-57a7-42b1-a8e8-4a308556c7bd',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('fhir2.providerContactPointAttributeTypeUuid','5021b1a1-e7f6-44b4-ba02-da2f2bcf8718','Set provider attribute type uuid','4924ca5e-404c-40bd-9fc2-cb3d455e657e',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('fhir2.started','true','DO NOT MODIFY. true/false whether or not the fhir2 module has been started.  This is used to make sure modules that were running  prior to a restart are started again','8d7242fb-a85c-4e1a-8224-f07d4e2f0565',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('fhir2.supportedLocationHierarchySearchDepth','5','Defines how many levels of searching to before when using a Location?partof:below={uuid} search.  Generally set this number to the number of levels in your location hierarchy.','a7b2f22d-e4cb-4734-9d4c-c8ea24682548',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('fhir2.uriPrefix',NULL,'Prefix for the FHIR server in case this cannot be automatically detected','7d4569ed-7c19-475a-abe4-870a9581227b',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FormEntry.enableDashboardTab','true','true/false whether or not to show a Form Entry tab on the patient dashboard','0d252df1-aaf4-4981-8c0a-d2ce53787b60','org.openmrs.customdatatype.datatype.BooleanDatatype',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FormEntry.enableOnEncounterTab','false','true/false whether or not to show a Enter Form button on the encounters tab of the patient dashboard','090f38fa-dd24-4ee3-985d-9fac0bc62ccb','org.openmrs.customdatatype.datatype.BooleanDatatype',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('forms.locked','false','Set to a value of true if you do not want any changes to be made on forms, else set to false.','3c20dd4d-04e7-4a41-aa24-da61bb90d169',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('graph.color.absolute','rgb(20,20,20)','Color of the \'invalid\' section of numeric graphs on the patient dashboard.','be51a832-ad5b-470c-9a4d-6faf116df6dc',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('graph.color.critical','rgb(200,0,0)','Color of the \'critical\' section of numeric graphs on the patient dashboard.','685f48e8-1f69-4ad7-8534-00400047d763',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('graph.color.normal','rgb(255,126,0)','Color of the \'normal\' section of numeric graphs on the patient dashboard.','f96c8671-0d6c-4467-b587-0ae50cc4ae56',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('gzip.enabled','false','Set to \'true\' to turn on OpenMRS\'s gzip filter, and have the webapp compress data before sending it to any client that supports it. Generally use this if you are running Tomcat standalone. If you are running Tomcat behind Apache, then you\'d want to use Apache to do gzip compression.','499e2875-5a0b-49c0-8263-b21c3b484cd6','org.openmrs.customdatatype.datatype.BooleanDatatype',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('hl7_archive.dir','hl7_archives','The default name or absolute path for the folder where to write the hl7_in_archives.','8993648a-375c-452f-bcd6-0ff8707cb0eb',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('hl7_processor.ignore_missing_patient_non_local','false','If true, hl7 messages for patients that are not found and are non-local will silently be dropped/ignored','b1ede925-6265-4257-a5ed-dbd2419c20ed','org.openmrs.customdatatype.datatype.BooleanDatatype',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('host.url',NULL,'The URL to redirect to after requesting for a password reset. Always provide a place holder in this url with name {activationKey}, it will get substituted by the actual activation key.','256fbf7d-546f-49f3-9cd0-566d7f4ff1db',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('layout.address.format','<org.openmrs.layout.address.AddressTemplate>     <nameMappings class=\"properties\">       <property name=\"postalCode\" value=\"Location.postalCode\"/>       <property name=\"address2\" value=\"Location.address2\"/>       <property name=\"address1\" value=\"Location.address1\"/>       <property name=\"country\" value=\"Location.country\"/>       <property name=\"stateProvince\" value=\"Location.stateProvince\"/>       <property name=\"cityVillage\" value=\"Location.cityVillage\"/>     </nameMappings>     <sizeMappings class=\"properties\">       <property name=\"postalCode\" value=\"10\"/>       <property name=\"address2\" value=\"40\"/>       <property name=\"address1\" value=\"40\"/>       <property name=\"country\" value=\"10\"/>       <property name=\"stateProvince\" value=\"10\"/>       <property name=\"cityVillage\" value=\"10\"/>     </sizeMappings>     <lineByLineFormat>       <string>address1</string>       <string>address2</string>       <string>cityVillage stateProvince country postalCode</string>     </lineByLineFormat>    <requiredElements> </requiredElements> </org.openmrs.layout.address.AddressTemplate>','XML description of address formats','d506f19e-1220-4fda-802c-326870fe64c2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('layout.name.format','short','Format in which to display the person names.  Valid values are short, long','5d64f396-f660-4ff5-9e03-e120bddc4591',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('locale.allowed.list','en, en_GB, es, fr, it, pt','Comma delimited list of locales allowed for use on system','ed779482-9150-4c4e-9124-561db7bcb420',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('location.field.style','default','Type of widget to use for location fields','4910b45c-0f32-4d6b-bc0b-9c5a80a2f8eb',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('log.layout','%p - %C{1}.%M(%L) |%d{ISO8601}| %m%n','A log layout pattern which is used by the OpenMRS file appender.','bb444578-e5bf-43b0-8b50-907165321ee8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('log.level','org.openmrs.api:info','Logging levels for log4j2.xml. Valid format is class:level,class:level. If class not specified, \'org.openmrs.api\' presumed. Valid levels are trace, debug, info, warn, error or fatal','089162f3-038f-45f5-a045-4584e4e8c877',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('log.location',NULL,'A directory where the OpenMRS log file appender is stored. The log file name is \'openmrs.log\'.','1940b15e-cc1c-4b85-9bac-6897415f99bc',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('login.url','owa/addonmanager/index.html','Responsible for defining the Authentication URL','54f496dd-b6a3-4dfa-8cc1-65f79b1b8015',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('mail.debug','false','true/false whether to print debugging information during mailing','b5a07cb7-fbcb-4bc8-8489-70376577f4cf',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('mail.default_content_type','text/plain','Content type to append to the mail messages','e4229af5-604a-4853-891c-df434d35f74d',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('mail.from','info@openmrs.org','Email address to use as the default from address','9618cc7b-27cf-4677-acb5-b47c4f0629ea',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('mail.password','test','Password for the SMTP user (if smtp_auth is enabled)','e48b2aa7-f360-481b-a604-383668abd27a',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('mail.smtp.starttls.enable','false','Set to true to enable TLS encryption, else set to false','ca2a6d7d-9387-42cd-b845-4eccecd2a606',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('mail.smtp_auth','false','true/false whether the smtp host requires authentication','cec5bf48-dcea-45e8-aa07-03f2addbf553',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('mail.smtp_host','localhost','SMTP host name','7f26cfaa-9e8c-4fb9-a561-fe84e2c21983',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('mail.smtp_port','25','SMTP port','17114e64-67c8-441d-9d37-4da26fe8f0d1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('mail.transport_protocol','smtp','Transport protocol for the messaging engine. Valid values: smtp','814e6dd6-192c-458d-afa5-c8079258600f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('mail.user','test','Username of the SMTP user (if smtp_auth is enabled)','99045648-3319-495a-80f0-dde97405154c',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('minSearchCharacters','2','Number of characters user must input before searching is started.','c584e421-cd40-4ffd-9943-d4ef1ef75eb0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('module_repository_folder','modules','Name of the folder in which to store the modules','1f3763b2-fd77-4056-90e4-212b871ff305',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('newPatientForm.relationships',NULL,'Comma separated list of the RelationshipTypes to show on the new/short patient form.  The list is defined like \'3a, 4b, 7a\'.  The number is the RelationshipTypeId and the \'a\' vs \'b\' part is which side of the relationship is filled in by the user.','f5ce96ed-6463-4cd1-a020-3792d44963b3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('new_patient_form.showRelationships','false','true/false whether or not to show the relationship editor on the addPatient.htm screen','6e5994b3-520d-4caf-a9fb-d61b19562523','org.openmrs.customdatatype.datatype.BooleanDatatype',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('obs.complex_obs_dir','complex_obs','Default directory for storing complex obs.','4e3ca595-2506-4548-be8b-5d18223918b3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('order.drugDispensingUnitsConceptUuid',NULL,'Specifies the uuid of the concept set where its members represent the possible drug dispensing units','38aac0e9-c759-4d19-ae54-24290e263c58',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('order.drugDosingUnitsConceptUuid',NULL,'Specifies the uuid of the concept set where its members represent the possible drug dosing units','dad63678-79df-4e35-b71d-4d1a48dc6911',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('order.drugRoutesConceptUuid',NULL,'Specifies the uuid of the concept set where its members represent the possible drug routes','c01d7641-125d-459e-8116-71366e8cdf7d',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('order.durationUnitsConceptUuid',NULL,'Specifies the uuid of the concept set where its members represent the possible duration units','b28c2607-688e-4edd-a850-9c8cbacb57a6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('order.nextOrderNumberSeed','1','The next order number available for assignment','1740c7ef-0630-425f-bbc6-15979cb59cde',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('order.orderNumberGeneratorBeanId',NULL,'Specifies spring bean id of the order generator to use when assigning order numbers','a75b7de3-91b7-4b50-89a8-428f1335cad9',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('order.testSpecimenSourcesConceptUuid',NULL,'Specifies the uuid of the concept set where its members represent the possible test specimen sources','feec06fa-62b5-4d51-bd8e-4f081bf555e2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('owa.appBaseUrl',NULL,'The base URL from where the Open Web Apps are hosted','4b97baa3-3f25-49c7-8780-60ecafab45c4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('owa.appFolderPath','/Users/mutajonathan/openmrs/openmrs/owa','The default location where the apps are stored on disk','17c447db-b728-4722-a417-2f32009d8582',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('owa.appStoreUrl','http://modules.openmrs.org','The default URL for the OpenMRS appstore','d6362a3f-72d6-43e6-bd94-12e88014a076',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('owa.mandatory','false','true/false whether or not the owa module MUST start when openmrs starts.  This is used to make sure that mission critical modules are always running if openmrs is running.','a502e4a7-64df-43fe-bd93-bcf2838821c5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('owa.started','true','DO NOT MODIFY. true/false whether or not the owa module has been started.  This is used to make sure modules that were running  prior to a restart are started again','84f28639-6384-4c67-b0a4-907d2bebc09b',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('patient.defaultPatientIdentifierValidator','org.openmrs.patient.impl.LuhnIdentifierValidator','This property sets the default patient identifier validator.  The default validator is only used in a handful of (mostly legacy) instances.  For example, it\'s used to generate the isValidCheckDigit calculated column and to append the string \"(default)\" to the name of the default validator on the editPatientIdentifierType form.','04762247-6d55-48d3-a2ad-36b40b29035e',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('patient.headerAttributeTypes',NULL,'A comma delimited list of PersonAttributeType names that will be shown on the patient dashboard','4609457a-9d21-4ec2-80ce-c83a200cbd00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('patient.identifierPrefix',NULL,'This property is only used if patient.identifierRegex is empty.  The string here is prepended to the sql indentifier search string.  The sql becomes \"... where identifier like \'<PREFIX><QUERY STRING><SUFFIX>\';\".  Typically this value is either a percent sign (%) or empty.','8d9239b3-06d1-465a-aae1-da73018bb9db',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('patient.identifierRegex',NULL,'WARNING: Using this search property can cause a drop in mysql performance with large patient sets.  A MySQL regular expression for the patient identifier search strings.  The @SEARCH@ string is replaced at runtime with the user\'s search string.  An empty regex will cause a simply \'like\' sql search to be used. Example: ^0*@SEARCH@([A-Z]+-[0-9])?$','a62944ef-6a15-42f6-9257-f99fb2c8c0ad',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('patient.identifierSearchPattern',NULL,'If this is empty, the regex or suffix/prefix search is used.  Comma separated list of identifiers to check.  Allows for faster searching of multiple options rather than the slow regex. e.g. @SEARCH@,0@SEARCH@,@SEARCH-1@-@CHECKDIGIT@,0@SEARCH-1@-@CHECKDIGIT@ would turn a request for \"4127\" into a search for \"in (\'4127\',\'04127\',\'412-7\',\'0412-7\')\"','b1489289-c8be-4235-b219-09e81ffbe7b1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('patient.identifierSuffix',NULL,'This property is only used if patient.identifierRegex is empty.  The string here is prepended to the sql indentifier search string.  The sql becomes \"... where identifier like \'<PREFIX><QUERY STRING><SUFFIX>\';\".  Typically this value is either a percent sign (%) or empty.','6df515d8-297c-437e-94c6-2858c3c955ee',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('patient.listingAttributeTypes',NULL,'A comma delimited list of PersonAttributeType names that should be displayed for patients in _lists_','e2057b0f-12c6-4a78-945d-0b08181f7977',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('patient.nameValidationRegex',NULL,'Names of the patients must pass this regex. Eg : ^[a-zA-Z \\\\\\\\-]+$ contains only english alphabet letters, spaces, and hyphens. A value of .* or the empty string means no validation is done.','33215153-23f5-4e00-967b-243b81017851',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('patient.viewingAttributeTypes',NULL,'A comma delimited list of PersonAttributeType names that should be displayed for patients when _viewing individually_','5805e57f-8f9a-4f3c-a0b1-a02a2504ef72',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('patientIdentifierSearch.matchMode','EXACT','Specifies how patient identifiers are matched while searching for a patient. Valid values are \'EXACT, \'ANYWHERE\' or \'START\'. Defaults to \'EXACT\' if missing or invalid value is present.','f57be38c-490d-452e-9a52-1e7450fe7b61',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('patientIdentifierTypes.locked','false','Set to a value of true if you do not want allow editing patient identifier types, else set to false.','1a799da5-986c-47f8-9685-b95cc5932dd5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('patientSearch.matchMode','START','Specifies how patient names are matched while searching patient. Valid values are \'ANYWHERE\' or \'START\'. Defaults to start if missing or invalid value is present.','43c4f838-51c1-495b-b474-b597b1fca708',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('patient_identifier.importantTypes',NULL,'A comma delimited list of PatientIdentifier names : PatientIdentifier locations that will be displayed on the patient dashboard.  E.g.: TRACnet ID:Rwanda,ELDID:Kenya','782440dd-ab92-4c9b-aa5e-28a9734917a3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('person.attributeSearchMatchMode','EXACT','Specifies how person attributes are matched while searching person. Valid values are \'ANYWHERE\' or \'EXACT\'. Defaults to exact if missing or invalid value is present.','638d4774-7867-4cb4-a8a7-e67d962636a9',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('person.searchMaxResults','1000','The maximum number of results returned by patient searches','6637deaf-0024-46bb-b999-e6d8c892e357',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('personAttributeTypes.locked','false','Set to a value of true if you do not want allow editing person attribute types, else set to false.','a9ba4279-7ce0-4638-b4e0-86745c189375',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('provider.unknownProviderUuid',NULL,'Specifies the uuid of the Unknown Provider account','d50ba61e-31ad-4d11-a674-49efca9c8b25',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('providerSearch.matchMode','EXACT','Specifies how provider identifiers are matched while searching for providers. Valid values are START,EXACT, END or ANYWHERE','87cf37be-07a6-4650-b644-df9926bf1e01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('reportProblem.url','http://errors.openmrs.org/scrap','The openmrs url where to submit bug reports','9bb8a464-69cc-4ae1-b8dc-03d926161350',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('scheduler.password','test','Password for the OpenMRS user that will perform the scheduler activities','f2f53ffd-c0c7-4123-bb7e-cfbd61ea1dcf',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('scheduler.username','admin','Username for the OpenMRS user that will perform the scheduler activities','00dc0a29-3fa0-4a36-aa07-7f40ae7645d0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('search.caseSensitiveDatabaseStringComparison','false','Indicates whether database string comparison is case sensitive or not. Setting this to false for MySQL with a case insensitive collation improves search performance.','89272e39-8689-4428-8c2c-11ec2273f159',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('search.indexVersion','8','Indicates the index version. If it is blank, the index needs to be rebuilt.','b3b885c5-d0f1-4ff1-93b0-995a331f128b',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('searchWidget.batchSize','200','The maximum number of search results that are returned by an ajax call','39a2b99f-9f6a-4d7f-9857-8d4031f248cb',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('searchWidget.dateDisplayFormat',NULL,'Date display format to be used to display the date somewhere in the UI i.e the search widgets and autocompletes','403c8cb8-4ea0-47ff-b296-d3c2acbbc10c',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('searchWidget.maximumResults','2000','Specifies the maximum number of results to return from a single search in the search widgets','696452cf-0171-4755-9b64-912d5080a79c',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('searchWidget.runInSerialMode','false','Specifies whether the search widgets should make ajax requests in serial or parallel order, a value of true is appropriate for implementations running on a slow network connection and vice versa','3ef448c6-3625-40df-8cba-d5bb0e92eaee','org.openmrs.customdatatype.datatype.BooleanDatatype',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('searchWidget.searchDelayInterval','300','Specifies time interval in milliseconds when searching, between keyboard keyup event and triggering the search off, should be higher if most users are slow when typing so as to minimise the load on the server','7668f58f-5178-46c4-ba8f-30ab409665b6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('security.allowedFailedLoginsBeforeLockout','7','Maximum number of failed logins allowed after which username is locked out','6ab3a5b8-dd9e-4f97-ab14-117e04c8a401',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('security.passwordCannotMatchUsername','true','Configure whether passwords must not match user\'s username or system id','2dc79f65-ec53-4349-b9ec-82340cfbc1ca','org.openmrs.customdatatype.datatype.BooleanDatatype',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('security.passwordCustomRegex',NULL,'Configure a custom regular expression that a password must match','0e86a20d-e25c-47b3-bace-438f40a1be9c',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('security.passwordMinimumLength','8','Configure the minimum length required of all passwords','5ff5841d-fa50-4532-8205-1808927b9259',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('security.passwordRequiresDigit','true','Configure whether passwords must contain at least one digit','5431d53a-f6ca-4af5-9840-06a73ef14de1','org.openmrs.customdatatype.datatype.BooleanDatatype',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('security.passwordRequiresNonDigit','true','Configure whether passwords must contain at least one non-digit','50b7640d-b2c8-4bf4-81d4-730323df9dd3','org.openmrs.customdatatype.datatype.BooleanDatatype',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('security.passwordRequiresUpperAndLowerCase','true','Configure whether passwords must contain both upper and lower case characters','7ffcb927-1341-4113-b2ed-df9a35801a55','org.openmrs.customdatatype.datatype.BooleanDatatype',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('security.passwordResetUrl',NULL,'The URL to redirect to after requesting for a password reset. Always provide a place holder in this url with name {activationKey}, it will get substituted by the actual activation key.','6eb1c4d6-d0e8-49bd-9e2f-f68e7c223e12',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('security.unlockAccountWaitingTime','5','Waiting time for account to get automatically unlocked after getting locked due to multiple invalid login tries','446b17de-8413-4e64-8b07-d3e981f02dd8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('security.validTime','600000','Specifies the duration of time in seconds for which a password reset token is valid, the default value is 10 minutes and the allowed values range from 1 minute to 12hrs','28764d15-f64a-49e0-807f-a309f9a99f41',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('user.headerAttributeTypes',NULL,'A comma delimited list of PersonAttributeType names that will be shown on the user dashboard. (not used in v1.5)','4f3f5fea-30eb-4e83-b7ae-9ae8704c09e0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('user.listingAttributeTypes',NULL,'A comma delimited list of PersonAttributeType names that should be displayed for users in _lists_','ecf4f41a-6690-460e-b765-616b10260a02',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('user.requireEmailAsUsername','false','Indicates whether a username must be a valid e-mail or not.','01bc73a8-08c0-4723-9358-9d02df17a93c','org.openmrs.customdatatype.datatype.BooleanDatatype',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('user.viewingAttributeTypes',NULL,'A comma delimited list of PersonAttributeType names that should be displayed for users when _viewing individually_','14f1663b-19b3-44b2-bf8a-c30431e19598',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('use_patient_attribute.healthCenter','false','Indicates whether or not the \'health center\' attribute is shown when viewing/searching for patients','7dea235a-3efd-40f3-9b3d-e64042043013','org.openmrs.customdatatype.datatype.BooleanDatatype',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('use_patient_attribute.mothersName','false','Indicates whether or not mother\'s name is able to be added/viewed for a patient','0ffb5e2b-9671-41e6-a504-88d02a24ccba','org.openmrs.customdatatype.datatype.BooleanDatatype',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('validation.disable','false','Disables validation of OpenMRS Objects. Only takes affect on next restart. Warning: only do this is you know what you are doing!','346a9dc0-5f6a-462d-9065-85bcc7b62203',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('visits.allowOverlappingVisits','true','true/false whether or not to allow visits of a given patient to overlap','e0376867-c667-4c81-b82f-f65ec7bfd5c7','org.openmrs.customdatatype.datatype.BooleanDatatype',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('visits.assignmentHandler','org.openmrs.api.handler.ExistingVisitAssignmentHandler','Set to the name of the class responsible for assigning encounters to visits.','c90dd1db-0611-451a-94c4-ac4b0f44035d',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('visits.autoCloseVisitType',NULL,'comma-separated list of the visit type(s) to automatically close','7abb62f4-81a6-4145-ac0d-f01034d666ce',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('visits.enabled','true','Set to true to enable the Visits feature. This will replace the \'Encounters\' tab with a \'Visits\' tab on the dashboard.','9c594c46-482d-48b3-9643-05641111fc9f','org.openmrs.customdatatype.datatype.BooleanDatatype',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('visits.encounterTypeToVisitTypeMapping',NULL,'Specifies how encounter types are mapped to visit types when automatically assigning encounters to visits. e.g 1:1, 2:1, 3:2 in the format encounterTypeId:visitTypeId or encounterTypeUuid:visitTypeUuid or a combination of encounter/visit type uuids and ids e.g 1:759799ab-c9a5-435e-b671-77773ada74e4','c84f289c-3869-4683-9b14-ebc47c374212',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('webservices.rest.allowedips',NULL,'A comma-separate list of IP addresses that are allowed to access the web services. An empty string allows everyone to access all ws. \n        IPs can be declared with bit masks e.g. 10.0.0.0/30 matches 10.0.0.0 - 10.0.0.3 and 10.0.0.0/24 matches 10.0.0.0 - 10.0.0.255.','0a0fa68d-5903-4cf7-accd-bb2754e45e89',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('webservices.rest.enableStackTraceDetails','true','If the value of this setting is \"true\", then the details of the stackTrace would be shown in the error response. However, the recommendation is to keep it as \"false\", from the Security perspective, to avoid leaking implementation details.','d40ed172-b13a-41b0-911c-3e78cf902ebc',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('webservices.rest.mandatory','false','true/false whether or not the webservices.rest module MUST start when openmrs starts.  This is used to make sure that mission critical modules are always running if openmrs is running.','e9e6166e-fb4d-4958-ae16-9f6410331c9f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('webservices.rest.maxResultsAbsolute','100','The absolute max results limit. If the client requests a larger number of results, then will get an error','778babf2-9530-436a-88f1-89d5f9e974fa',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('webservices.rest.maxResultsDefault','50','The default max results limit if the user does not provide a maximum when making the web service call.','f10ac22f-4db2-470c-92ea-1e5c332288fd',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('webservices.rest.quietDocs','true','If the value of this setting is \"true\", then nothing is logged while the Swagger specification is being generated.','e8bbec83-3415-4ab5-aa22-b24a888a4196',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('webservices.rest.started','true','DO NOT MODIFY. true/false whether or not the webservices.rest module has been started.  This is used to make sure modules that were running  prior to a restart are started again','d15136d6-e42f-49d8-97c9-749adb37b3e9',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('webservices.rest.uriPrefix',NULL,'The URI prefix through which clients consuming web services will connect to the web application, should be of the form http://{ipAddress}:{port}/{contextPath}','6bbc9988-2661-4cb0-93ee-008a9d27db27',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `global_property` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hl7_in_archive`
--

DROP TABLE IF EXISTS `hl7_in_archive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hl7_in_archive` (
  `hl7_in_archive_id` int NOT NULL AUTO_INCREMENT,
  `hl7_source` int NOT NULL DEFAULT '0',
  `hl7_source_key` varchar(255) DEFAULT NULL,
  `hl7_data` text NOT NULL,
  `date_created` datetime NOT NULL,
  `message_state` int DEFAULT '2',
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`hl7_in_archive_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `hl7_in_archive_message_state_idx` (`message_state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hl7_in_archive`
--

LOCK TABLES `hl7_in_archive` WRITE;
/*!40000 ALTER TABLE `hl7_in_archive` DISABLE KEYS */;
/*!40000 ALTER TABLE `hl7_in_archive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hl7_in_error`
--

DROP TABLE IF EXISTS `hl7_in_error`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hl7_in_error` (
  `hl7_in_error_id` int NOT NULL AUTO_INCREMENT,
  `hl7_source` int NOT NULL DEFAULT '0',
  `hl7_source_key` text,
  `hl7_data` text NOT NULL,
  `error` varchar(255) NOT NULL DEFAULT '',
  `error_details` mediumtext,
  `date_created` datetime NOT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`hl7_in_error_id`),
  UNIQUE KEY `uuid` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hl7_in_error`
--

LOCK TABLES `hl7_in_error` WRITE;
/*!40000 ALTER TABLE `hl7_in_error` DISABLE KEYS */;
/*!40000 ALTER TABLE `hl7_in_error` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hl7_in_queue`
--

DROP TABLE IF EXISTS `hl7_in_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hl7_in_queue` (
  `hl7_in_queue_id` int NOT NULL AUTO_INCREMENT,
  `hl7_source` int NOT NULL DEFAULT '0',
  `hl7_source_key` text,
  `hl7_data` text NOT NULL,
  `message_state` int NOT NULL DEFAULT '0',
  `date_processed` datetime DEFAULT NULL,
  `error_msg` text,
  `date_created` datetime DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`hl7_in_queue_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `hl7_source_with_queue` (`hl7_source`),
  CONSTRAINT `hl7_source_with_queue` FOREIGN KEY (`hl7_source`) REFERENCES `hl7_source` (`hl7_source_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hl7_in_queue`
--

LOCK TABLES `hl7_in_queue` WRITE;
/*!40000 ALTER TABLE `hl7_in_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `hl7_in_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hl7_source`
--

DROP TABLE IF EXISTS `hl7_source`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hl7_source` (
  `hl7_source_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`hl7_source_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `user_who_created_hl7_source` (`creator`),
  CONSTRAINT `user_who_created_hl7_source` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hl7_source`
--

LOCK TABLES `hl7_source` WRITE;
/*!40000 ALTER TABLE `hl7_source` DISABLE KEYS */;
INSERT INTO `hl7_source` VALUES (1,'LOCAL','',1,'2006-09-01 00:00:00','8d6b8bb6-c2cc-11de-8d13-0010c6dffd0f');
/*!40000 ALTER TABLE `hl7_source` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `liquibasechangelog`
--

DROP TABLE IF EXISTS `liquibasechangelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `liquibasechangelog` (
  `ID` varchar(255) NOT NULL,
  `AUTHOR` varchar(255) NOT NULL,
  `FILENAME` varchar(255) NOT NULL,
  `DATEEXECUTED` datetime NOT NULL,
  `ORDEREXECUTED` int NOT NULL,
  `EXECTYPE` varchar(10) NOT NULL,
  `MD5SUM` varchar(35) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `COMMENTS` varchar(255) DEFAULT NULL,
  `TAG` varchar(255) DEFAULT NULL,
  `LIQUIBASE` varchar(20) DEFAULT NULL,
  `CONTEXTS` varchar(255) DEFAULT NULL,
  `LABELS` varchar(255) DEFAULT NULL,
  `DEPLOYMENT_ID` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `liquibasechangelog`
--

LOCK TABLES `liquibasechangelog` WRITE;
/*!40000 ALTER TABLE `liquibasechangelog` DISABLE KEYS */;
INSERT INTO `liquibasechangelog` VALUES ('1740466200030-1','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',1,'EXECUTED','9:d60dc01d315ac826c3f5d21171332a7c','createTable tableName=allergy','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-2','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',2,'EXECUTED','9:324af0a340205829b90e284a962e8ef4','createTable tableName=allergy_reaction','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-3','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',3,'EXECUTED','9:3ec6de7aad8382b01335fbfc3a0fba1c','createTable tableName=care_setting','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-4','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',4,'EXECUTED','9:9d05998d6eac1ae347a4c400e218c0ff','createTable tableName=clob_datatype_storage','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-5','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',5,'EXECUTED','9:663a86464ede4d6ee1e0ea69f0427655','createTable tableName=cohort','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-6','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',6,'EXECUTED','9:b67ffe3328139c46be8bbf86f0ff19db','createTable tableName=cohort_member','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-7','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',7,'EXECUTED','9:9f812cce15e7708b163a5b7a3312040f','createTable tableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-8','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',8,'EXECUTED','9:d7007342ee6d6b500516ed85d617b07f','createTable tableName=concept_answer','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-9','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',9,'EXECUTED','9:ac91e6f3a4e94869bb08c293ebd41871','createTable tableName=concept_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-10','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',10,'EXECUTED','9:b039b1c0c41d5c941a0dd4201e15d981','createTable tableName=concept_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-11','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',11,'EXECUTED','9:b943564f76bcf8e453818fd4e47ba5f2','createTable tableName=concept_class','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-12','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',12,'EXECUTED','9:30653cb1ff36338d53ffe998b03af58f','createTable tableName=concept_complex','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-13','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',13,'EXECUTED','9:8e504301aff33520631ffda1b16e5698','createTable tableName=concept_datatype','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-14','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',14,'EXECUTED','9:b65aed3f1805e7edba2135e1562cb683','createTable tableName=concept_description','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-15','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',15,'EXECUTED','9:54a6007591b649403ff80d45c073d0a3','createTable tableName=concept_map_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-16','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',16,'EXECUTED','9:5581f3e824e770a72bfd579d2e703f16','createTable tableName=concept_name','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-17','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',17,'EXECUTED','9:d76e0a489db967dde8aed50af548d2e7','createTable tableName=concept_name_tag','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-18','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',18,'EXECUTED','9:ec08f35234bc572b56dcb47c55e66fab','createTable tableName=concept_name_tag_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-19','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',19,'EXECUTED','9:fb07a012ac8124459f35cbcd072a3766','createTable tableName=concept_numeric','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-20','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',20,'EXECUTED','9:fce20a899125330e8030477724fb9b39','createTable tableName=concept_proposal','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-21','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',21,'EXECUTED','9:a001b2993785e09f3ea6c2c6bc9720eb','createTable tableName=concept_proposal_tag_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-22','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',22,'EXECUTED','9:829007d26d68c0b0513cc08f3cfd49d0','createTable tableName=concept_reference_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-23','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',23,'EXECUTED','9:95ffb0ddebd0d71c074111fa210c9ca8','createTable tableName=concept_reference_range','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-24','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',24,'EXECUTED','9:91cea56d3df25658a0c65e0dc04c73ed','createTable tableName=concept_reference_source','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-25','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',25,'EXECUTED','9:cfb52672986ff66146aa9ed5b65ffc07','createTable tableName=concept_reference_term','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-26','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',26,'EXECUTED','9:60cde4fcd4c1cebbcd96f804ed8d1b00','createTable tableName=concept_reference_term_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-27','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',27,'EXECUTED','9:da89bd0536f2cbf772834160063cc55f','createTable tableName=concept_set','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-28','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',28,'EXECUTED','9:830ec8dfc09e36a0d6b4731df6ce53a8','createTable tableName=concept_state_conversion','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-29','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',29,'EXECUTED','9:356a1cca52ca6f8593bc0592c71782d1','createTable tableName=concept_stop_word','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-30','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',30,'EXECUTED','9:e69168b0a6dd8471733368c1a0c717ed','createTable tableName=conditions','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-31','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',31,'EXECUTED','9:2834c5ad5083557e016760e79737ce2a','createTable tableName=diagnosis_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-32','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',32,'EXECUTED','9:44d1d4beb82439d2f81617f173d94d96','createTable tableName=diagnosis_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-33','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',33,'EXECUTED','9:9384623490d8eb2d93c701cbb5775013','createTable tableName=drug','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-34','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',34,'EXECUTED','9:596270ead53b66cee3c512544cb9f23a','createTable tableName=drug_ingredient','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-35','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',35,'EXECUTED','9:9e32810bbebc54979ed76bd59a63383e','createTable tableName=drug_order','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-36','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',36,'EXECUTED','9:e5d6a1b9bd377a5b6d539dd9a1157315','createTable tableName=drug_reference_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-37','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',37,'EXECUTED','9:dfa52814ae6f5d4f2613f1a330a1e992','createTable tableName=encounter','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-38','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',38,'EXECUTED','9:45d40f4cc907ae1a3e8fbdc5f207adbf','createTable tableName=encounter_diagnosis','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-39','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',39,'EXECUTED','9:05a1cf97e25f666e0c8c39e35ac41e77','createTable tableName=encounter_provider','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-40','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',40,'EXECUTED','9:dd42b70149205fecf79b917eb6c6a3b7','createTable tableName=encounter_role','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-41','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',41,'EXECUTED','9:cc01ee7dc7118ff5d5dd83126c483de5','createTable tableName=encounter_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-42','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',42,'EXECUTED','9:d47ecf3309c3e173ab4837658bf18af9','createTable tableName=field','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-43','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',43,'EXECUTED','9:8a3c9863e9f0d12427ce1e8ae93d9919','createTable tableName=field_answer','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-44','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',44,'EXECUTED','9:108581ffc5175feb2a2a27ff069d6701','createTable tableName=field_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-45','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',45,'EXECUTED','9:6128f45d9f7026dce14c8a9df5157547','createTable tableName=form','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-46','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',46,'EXECUTED','9:308d47dee8f404c8feb433807047bd06','createTable tableName=form_field','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-47','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',47,'EXECUTED','9:948d8730c861c8b3ff51a81015b66262','createTable tableName=form_resource','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-48','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',48,'EXECUTED','9:7ffef3cb0051a9de8e86a6724c510094','createTable tableName=global_property','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-49','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',49,'EXECUTED','9:36f4bb132943f5344366e7fa3b6a3203','createTable tableName=hl7_in_archive','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-50','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',50,'EXECUTED','9:d97786ec2b32a37201ab584148fd8a46','createTable tableName=hl7_in_error','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-51','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',51,'EXECUTED','9:b5219322094a93040310cd0f42d8b4cc','createTable tableName=hl7_in_queue','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-52','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',52,'EXECUTED','9:c958bb2d6e8953c54e2873008b298d23','createTable tableName=hl7_source','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-55','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',53,'EXECUTED','9:a47c7059d2b28dcedb3c628ae49380aa','createTable tableName=location','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-56','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',54,'EXECUTED','9:72b7e7dc7ce9cd8ed61325dc5c0fcc54','createTable tableName=location_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-57','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',55,'EXECUTED','9:8a2970bffd8515984dbf76940d1edfe0','createTable tableName=location_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-58','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',56,'EXECUTED','9:b6f519a5e7edbbc65f9d8dfb6b5e0ace','createTable tableName=location_tag','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-59','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',57,'EXECUTED','9:dfa8564837bf26a17dbdca1712d1dbce','createTable tableName=location_tag_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-60','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',58,'EXECUTED','9:ac62536b8af363c5ad0f410a6a4948b9','createTable tableName=medication_dispense','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-61','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',59,'EXECUTED','9:a674cb7689874a9ae6f7b1287c785f24','createTable tableName=note','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-62','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',60,'EXECUTED','9:13e34ea9a1427e9ddaa6ba0de7ca8a28','createTable tableName=notification_alert','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-63','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',61,'EXECUTED','9:fc473e357a59a334cb58bba05b7518b7','createTable tableName=notification_alert_recipient','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-64','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',62,'EXECUTED','9:8f0937e0ee95813af9c0981996d819c1','createTable tableName=notification_template','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-65','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',63,'EXECUTED','9:3b01d06cf81d49bda772675357215b65','createTable tableName=obs','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-66','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:19',64,'EXECUTED','9:f5c82442dd0f684d0e7662a8499f0dcc','createTable tableName=obs_reference_range','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-67','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',65,'EXECUTED','9:097f154a1e31066cdc1bf153b1cc1949','createTable tableName=order_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-68','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',66,'EXECUTED','9:b41d0b70a23a6b96a8b83cb05fb3d01b','createTable tableName=order_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-69','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',67,'EXECUTED','9:f76f0ae0067d66badaa1b580064606f4','createTable tableName=order_frequency','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-70','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',68,'EXECUTED','9:68ec165726685b8b43856ae89a4de7c8','createTable tableName=order_group','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-71','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',69,'EXECUTED','9:dff2e62be49d21be84f8a985fadd0d3f','createTable tableName=order_group_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-72','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',70,'EXECUTED','9:c49b9266aded7a6bd2f84d8b0ec93a9f','createTable tableName=order_group_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-73','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',71,'EXECUTED','9:c993a16b69ffd7506b454a3abf233757','createTable tableName=order_set','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-74','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',72,'EXECUTED','9:204bcf69a5485bbf668c967149d6233e','createTable tableName=order_set_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-75','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',73,'EXECUTED','9:0a1e2aab58c6659441ea1cb3a6a41cd9','createTable tableName=order_set_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-76','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',74,'EXECUTED','9:793b9ece7988eeda56839cdf156dd153','createTable tableName=order_set_member','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-77','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',75,'EXECUTED','9:405eb18cfdf4efa60999c3bc5e540fd9','createTable tableName=order_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-78','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',76,'EXECUTED','9:db72baaa5a6ff3adf013c3ff594775ab','createTable tableName=order_type_class_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-79','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',77,'EXECUTED','9:30965be1e751060951ce8843f762e453','createTable tableName=orders','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-80','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',78,'EXECUTED','9:7848f01d7bf2edd067450f6bf4192340','createTable tableName=patient','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-81','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',79,'EXECUTED','9:a4a12db0b82c62a9b3925809ae9bcb54','createTable tableName=patient_identifier','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-82','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',80,'EXECUTED','9:3c97c43116c67d207dfa76b34f82ed56','createTable tableName=patient_identifier_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-83','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',81,'EXECUTED','9:dcad863f64667bd2871b4334575e7db3','createTable tableName=patient_program','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-84','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',82,'EXECUTED','9:cb15989ff5436fb49f6b6853da70aa4f','createTable tableName=patient_program_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-85','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',83,'EXECUTED','9:9668ee6622f88662ec9fbae9f124a7d3','createTable tableName=patient_state','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-86','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',84,'EXECUTED','9:87c966c067f894da777e4428c1c878cb','createTable tableName=person','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-87','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',85,'EXECUTED','9:82dc2a499f665145bd0e1fcdf3f1da63','createTable tableName=person_address','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-88','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',86,'EXECUTED','9:fcde5c192f4c433a35a0d63984f92955','createTable tableName=person_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-89','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',87,'EXECUTED','9:3f3c2e6794d38bbcc8b510c1c615f815','createTable tableName=person_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-90','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',88,'EXECUTED','9:64f6980eaf1231af34042dd999462d50','createTable tableName=person_merge_log','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-91','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',89,'EXECUTED','9:dffe0f8d59ae5d88312c57ad98787886','createTable tableName=person_name','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-92','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',90,'EXECUTED','9:7dd0d41187ad44802378c325939ee7dc','createTable tableName=privilege','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-93','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',91,'EXECUTED','9:fb79b7b281f8842f5ded52df60d3092a','createTable tableName=program','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-94','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',92,'EXECUTED','9:6fd3bcb5e44ada89554b04d1c53c20f5','createTable tableName=program_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-95','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',93,'EXECUTED','9:8a68861d401aaa4f3c8f730c702abae4','createTable tableName=program_workflow','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-96','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',94,'EXECUTED','9:8ecc09d861b84a463123922703e6fb7f','createTable tableName=program_workflow_state','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-97','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',95,'EXECUTED','9:e41d54fe7bc405a1fd5e128e97142b5e','createTable tableName=provider','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-98','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',96,'EXECUTED','9:a500777904acff1429d4f49d22c8099e','createTable tableName=provider_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-99','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',97,'EXECUTED','9:866c0979a75d02313cc6d50aa8ebfe4a','createTable tableName=provider_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-100','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',98,'EXECUTED','9:68e8299490a442bc348274a14c47bd67','createTable tableName=referral_order','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-101','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',99,'EXECUTED','9:35c59432b5ce6d6e5b1192517726c396','createTable tableName=relationship','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-102','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',100,'EXECUTED','9:86c37d1ca3c8f86d3af32edab5e4f849','createTable tableName=relationship_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-103','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',101,'EXECUTED','9:552db86214a9bca65c762f1bb5498e02','createTable tableName=report_object','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-104','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',102,'EXECUTED','9:3c264636708ced231c8f1aefbfb3fdc0','createTable tableName=report_schema_xml','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-105','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',103,'EXECUTED','9:2503742deb18681900f6ab0e249721f5','createTable tableName=role','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-106','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',104,'EXECUTED','9:3df554f889d00c9d8533e2ac60ce48ea','createTable tableName=role_privilege','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-107','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',105,'EXECUTED','9:7081e6108d174875ac0cbda456f61719','createTable tableName=role_role','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-108','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',106,'EXECUTED','9:0545caca18b2ed5d955a37a511760d97','createTable tableName=scheduler_task_config','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-109','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',107,'EXECUTED','9:0e81ca45a7d320af71b8dd237e5ccd26','createTable tableName=scheduler_task_config_property','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-110','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',108,'EXECUTED','9:ca3be08d46845b2b30f21802b0250e3d','createTable tableName=serialized_object','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-111','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',109,'EXECUTED','9:0046198bca17da5019db6c6681667cef','createTable tableName=test_order','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-112','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',110,'EXECUTED','9:4f0fa751e15df6cc8e8aceaa37d08de9','createTable tableName=user_property','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-113','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',111,'EXECUTED','9:90e678d4252e228729a32d51f2f6280f','createTable tableName=user_role','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-114','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',112,'EXECUTED','9:63103e82308c386cb1823ec54c0c362d','createTable tableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-115','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',113,'EXECUTED','9:910389e7e193d92c79a0cc19a6dd0ae2','createTable tableName=visit','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-116','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',114,'EXECUTED','9:8d1d2f0e1b9f24087218ea94513b7768','createTable tableName=visit_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-117','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',115,'EXECUTED','9:5e749bc047cc0842e9cff34adf952c56','createTable tableName=visit_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-118','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',116,'EXECUTED','9:47f280854ff534e955ebd087d3b0f3a0','createTable tableName=visit_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-119','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',117,'EXECUTED','9:5a5bbb04274aa15de7c10d5e3e179582','addUniqueConstraint constraintName=Unique_StopWord_Key, tableName=concept_stop_word','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-120','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',118,'EXECUTED','9:fa7bbb947ad6b25d01dba2235d96d179','addUniqueConstraint constraintName=unique_form_and_name, tableName=form_resource','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-121','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',119,'EXECUTED','9:ded55c7a79550e8070406b84b6bbe718','addUniqueConstraint constraintName=unique_workflow_concept_in_conversion, tableName=concept_state_conversion','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-122','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',120,'EXECUTED','9:98596931ba33c782f5104560efefcbaf','createIndex indexName=address_for_person, tableName=person_address','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-123','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',121,'EXECUTED','9:d18c6e390fed9325aa0660138685d840','createIndex indexName=alert_creator, tableName=notification_alert','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-124','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',122,'EXECUTED','9:2278d314ae53e5c84de8b805261c4a41','createIndex indexName=alert_date_to_expire_idx, tableName=notification_alert','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-125','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',123,'EXECUTED','9:20c06be5b0412fae52c49114ca923f19','createIndex indexName=alert_read_by_user, tableName=notification_alert_recipient','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-126','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',124,'EXECUTED','9:5f16ff216b835e67e792bbf8b447e2f4','createIndex indexName=allergy_changed_by_fk, tableName=allergy','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-127','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',125,'EXECUTED','9:726d49d023544943f65d005eeb218cbf','createIndex indexName=allergy_coded_allergen_fk, tableName=allergy','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-128','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',126,'EXECUTED','9:6756de6eee4b2b7732a799a82ed1ee5d','createIndex indexName=allergy_creator_fk, tableName=allergy','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-129','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',127,'EXECUTED','9:782a731d9e1daf33a59493be2689b934','createIndex indexName=allergy_encounter_id_fk, tableName=allergy','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-130','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',128,'EXECUTED','9:b5f0fe05649f11e1e1bc72db327d49db','createIndex indexName=allergy_patient_id_fk, tableName=allergy','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-131','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',129,'EXECUTED','9:858d2a444931c6bae28f821e36dab0b7','createIndex indexName=allergy_reaction_allergy_id_fk, tableName=allergy_reaction','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-132','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',130,'EXECUTED','9:c99fa649c9a847e7622fec1098fe48f3','createIndex indexName=allergy_reaction_reaction_concept_id_fk, tableName=allergy_reaction','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-133','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',131,'EXECUTED','9:52892195a7af97f9b971af7d4d3a8d9e','createIndex indexName=allergy_severity_concept_id_fk, tableName=allergy','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-134','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',132,'EXECUTED','9:67abcf0264fec91a0fe55d69845b707e','createIndex indexName=allergy_voided_by_fk, tableName=allergy','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-135','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',133,'EXECUTED','9:2b59cb0daa67fd2871336f53b76277b0','createIndex indexName=answer, tableName=concept_answer','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-136','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',134,'EXECUTED','9:f8ee5c049c0f046988dd25900593bd55','createIndex indexName=answer_answer_drug_fk, tableName=concept_answer','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-137','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',135,'EXECUTED','9:76983a84cdf55efb4d52647839ba5e58','createIndex indexName=answer_concept, tableName=obs','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-138','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',136,'EXECUTED','9:eebcd129fefc3ad7841a07f0c3237879','createIndex indexName=answer_concept_drug, tableName=obs','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-139','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',137,'EXECUTED','9:d5d0239e6173ea53102737dfb7a96e30','createIndex indexName=answer_creator, tableName=concept_answer','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-140','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',138,'EXECUTED','9:17af3db440e940c4b53ea19b9e1f09a2','createIndex indexName=answers_for_concept, tableName=concept_answer','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-141','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',139,'EXECUTED','9:884e26a09b0527cfbc3971ed82bb9941','createIndex indexName=attribute_changer, tableName=person_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-142','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',140,'EXECUTED','9:1c37bf66c6ea9c6bf6b1c80d95c3eb50','createIndex indexName=attribute_creator, tableName=person_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-143','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',141,'EXECUTED','9:e0789f9f58087c4c186a44ee528209bd','createIndex indexName=attribute_is_searchable, tableName=person_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-144','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',142,'EXECUTED','9:c96dd5c7c2adaec9304e12ea12c98f09','createIndex indexName=attribute_type_changer, tableName=person_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-145','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',143,'EXECUTED','9:459fb22837b12b9a36c831bd14a94c78','createIndex indexName=attribute_type_creator, tableName=person_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-146','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',144,'EXECUTED','9:c703fae59f67c8e6934e4668f1e5915d','createIndex indexName=attribute_voider, tableName=person_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-147','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',145,'EXECUTED','9:a532e9468dc38b6b9e55afad0c07ce76','createIndex indexName=care_setting_changed_by, tableName=care_setting','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-148','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',146,'EXECUTED','9:2ad3829207078322e567b6da980b79fa','createIndex indexName=care_setting_creator, tableName=care_setting','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-149','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',147,'EXECUTED','9:2a15f3a74298e878163f7bce1da7c52d','createIndex indexName=care_setting_retired_by, tableName=care_setting','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-150','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',148,'EXECUTED','9:a4169eaa1c7279a1306e17ad5016c78b','createIndex indexName=category_order_set_fk, tableName=order_set','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-151','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',149,'EXECUTED','9:9fc0d81266133ace97e29172a83fe4e1','createIndex indexName=cohort_creator, tableName=cohort','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-152','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',150,'EXECUTED','9:434b857f1db2dbde38d80a7617acd435','createIndex indexName=cohort_member_creator, tableName=cohort_member','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-153','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',151,'EXECUTED','9:30cc7ae76e644c2e2ca7f2fdeee5e7c4','createIndex indexName=concept_attribute_attribute_type_id_fk, tableName=concept_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-154','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',152,'EXECUTED','9:99d947946a049da53063e68f1dcb2190','createIndex indexName=concept_attribute_changed_by_fk, tableName=concept_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-155','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',153,'EXECUTED','9:160684550a08b746901f61af8bd0798a','createIndex indexName=concept_attribute_concept_fk, tableName=concept_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-156','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',154,'EXECUTED','9:acc85d257b7b342e1fde934b2a5417e7','createIndex indexName=concept_attribute_creator_fk, tableName=concept_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-157','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',155,'EXECUTED','9:342827b6f7f992bfbf7cae39b41400ef','createIndex indexName=concept_attribute_type_changed_by_fk, tableName=concept_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-158','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',156,'EXECUTED','9:3165bad39aa8ccf80410d76d449c1be5','createIndex indexName=concept_attribute_type_creator_fk, tableName=concept_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-159','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',157,'EXECUTED','9:731c1c73ee3ec3a246cec694d6931875','createIndex indexName=concept_attribute_type_retired_by_fk, tableName=concept_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-160','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',158,'EXECUTED','9:2ec5dc42339696d43642dbe80e43a7b3','createIndex indexName=concept_attribute_voided_by_fk, tableName=concept_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-161','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',159,'EXECUTED','9:ed995ba865b17935d12c97d3798849e1','createIndex indexName=concept_class_changed_by, tableName=concept_class','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-162','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',160,'EXECUTED','9:ea57a08f4056bb634a1b297dc5cdf9ae','createIndex indexName=concept_class_creator, tableName=concept_class','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-163','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',161,'EXECUTED','9:794ba98433c44eb49a98739d7fe16453','createIndex indexName=concept_class_name_index, tableName=concept_class','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-164','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',162,'EXECUTED','9:7d274336651f76de02a164301cff798c','createIndex indexName=concept_class_retired_status, tableName=concept_class','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-165','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',163,'EXECUTED','9:a68715a65b8ab862f9cb16251ea448ec','createIndex indexName=concept_classes, tableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-166','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',164,'EXECUTED','9:0758f263db0a50c1d6fe10e4193d12e2','createIndex indexName=concept_creator, tableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-167','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',165,'EXECUTED','9:d2ec8c58b5f7c5329b39ee7a2fa6dfb2','createIndex indexName=concept_datatype_creator, tableName=concept_datatype','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-168','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',166,'EXECUTED','9:e4cbd15a6da1b8198ff0a9011c66163d','createIndex indexName=concept_datatype_name_index, tableName=concept_datatype','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-169','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',167,'EXECUTED','9:03044f2305a2fecaa0d4cf4b5ac724e5','createIndex indexName=concept_datatype_retired_status, tableName=concept_datatype','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-170','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',168,'EXECUTED','9:ebde2b6ab1301ca3244d395936871c98','createIndex indexName=concept_datatypes, tableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-171','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',169,'EXECUTED','9:08572547d2e99bb78bde82b323973a8f','createIndex indexName=concept_for_field, tableName=field','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-172','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',170,'EXECUTED','9:c2402cf8dc5a76baaa93980959716a74','createIndex indexName=concept_for_proposal, tableName=concept_proposal','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-173','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',171,'EXECUTED','9:8df920d32b331fc9018867c9cfa8a289','createIndex indexName=concept_map_type_for_drug_reference_map, tableName=drug_reference_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-174','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',172,'EXECUTED','9:210eed46cfd2534ee3b2c8b29ebabd6e','createIndex indexName=concept_name_changed_by, tableName=concept_name','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-175','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',173,'EXECUTED','9:0d82da902a7779050cc92dfeadb3be4d','createIndex indexName=concept_name_tag_changed_by, tableName=concept_name_tag','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-176','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',174,'EXECUTED','9:53d2c19128eb91dfa5a811f6657ebb98','createIndex indexName=concept_reference_source_changed_by, tableName=concept_reference_source','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-177','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',175,'EXECUTED','9:0da5e227acf68ced63c9a657d430cb0d','createIndex indexName=concept_reference_term_for_drug_reference_map, tableName=drug_reference_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-178','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',176,'EXECUTED','9:aabf62133b8d387bb2de27052922508d','createIndex indexName=concept_source_creator, tableName=concept_reference_source','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-179','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',177,'EXECUTED','9:147c2fd4c0842f6254cb6cf9c4566106','createIndex indexName=concept_triggers_conversion, tableName=concept_state_conversion','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-180','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',178,'EXECUTED','9:fe4518125f9e5645da4715572fea0747','createIndex indexName=condition_changed_by_fk, tableName=conditions','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-181','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',179,'EXECUTED','9:4d2707595b491ed60c9d212588608682','createIndex indexName=condition_condition_coded_fk, tableName=conditions','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-182','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',180,'EXECUTED','9:ba0d4bd317e132f0beb848a837e67d2d','createIndex indexName=condition_condition_coded_name_fk, tableName=conditions','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-183','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',181,'EXECUTED','9:fe55416c54c201d92fc7520c5288a23d','createIndex indexName=condition_creator_fk, tableName=conditions','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-184','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',182,'EXECUTED','9:6c8f31c32e1d8c00b3ef040f3e740500','createIndex indexName=condition_patient_fk, tableName=conditions','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-185','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',183,'EXECUTED','9:a2b976e46b1e1d301798865a7c8c34aa','createIndex indexName=condition_previous_version_fk, tableName=conditions','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-186','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',184,'EXECUTED','9:29cc89e15ba0778a91a30cd9eefcd937','createIndex indexName=condition_voided_by_fk, tableName=conditions','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-187','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',185,'EXECUTED','9:9eb3d136af6f1db205dc1e9d85f14d10','createIndex indexName=conditions_encounter_id_fk, tableName=conditions','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-188','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',186,'EXECUTED','9:a30ce123201e75537d4aea0b4f16d75f','createIndex indexName=conversion_to_state, tableName=concept_state_conversion','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-189','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',187,'EXECUTED','9:18b113fcb18aaf503fd8fdfbdffafb3b','createIndex indexName=defines_attribute_type, tableName=person_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-190','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',188,'EXECUTED','9:457e183908eafb8fdf40ecf9ef59866f','createIndex indexName=defines_identifier_type, tableName=patient_identifier','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-191','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',189,'EXECUTED','9:8e6a6ae07c7309dd7f9b64127ec01882','createIndex indexName=description_for_concept, tableName=concept_description','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-192','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',190,'EXECUTED','9:5268ab61292673a56dd3d9c750ab035f','createIndex indexName=diagnosis_attribute_attribute_type_id_fk, tableName=diagnosis_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-193','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',191,'EXECUTED','9:fcd798dea44c536741be86c180fb8a0d','createIndex indexName=diagnosis_attribute_changed_by_fk, tableName=diagnosis_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-194','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',192,'EXECUTED','9:78fcd02cde88e3361626eb7ccb2c00de','createIndex indexName=diagnosis_attribute_creator_fk, tableName=diagnosis_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-195','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',193,'EXECUTED','9:c9f446f0e4828d4ea65052a398997e59','createIndex indexName=diagnosis_attribute_diagnosis_fk, tableName=diagnosis_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-196','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',194,'EXECUTED','9:aaac3fa6ecb873c7af2767fe8ccd25ef','createIndex indexName=diagnosis_attribute_type_changed_by_fk, tableName=diagnosis_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-197','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',195,'EXECUTED','9:7083683f4d79a6a6a22b605bac40049f','createIndex indexName=diagnosis_attribute_type_creator_fk, tableName=diagnosis_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-198','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',196,'EXECUTED','9:bffc74db0ce3dc3b000ac3fec6822f51','createIndex indexName=diagnosis_attribute_type_retired_by_fk, tableName=diagnosis_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-199','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',197,'EXECUTED','9:31cce63dc5900bb0d9b3e82bcbf4ddef','createIndex indexName=diagnosis_attribute_voided_by_fk, tableName=diagnosis_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-200','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',198,'EXECUTED','9:6d3c58543248f165cffbcd4d0f1803c9','createIndex indexName=discontinued_because, tableName=orders','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-201','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',199,'EXECUTED','9:8e885179520ca793d1444326e962c9f6','createIndex indexName=dosage_form_concept, tableName=drug','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-202','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',200,'EXECUTED','9:af28d2764bb208628873938327dc5e00','createIndex indexName=drug_changed_by, tableName=drug','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-203','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',201,'EXECUTED','9:5c2e07e965584c9ed01180a097daf5de','createIndex indexName=drug_creator, tableName=drug','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-204','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',202,'EXECUTED','9:baddf1ef2e34564316cbebd1cb4de01d','createIndex indexName=drug_dose_limit_units_fk, tableName=drug','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-205','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',203,'EXECUTED','9:4a345629782789db299ebf43715412c7','createIndex indexName=drug_for_drug_reference_map, tableName=drug_reference_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-206','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',204,'EXECUTED','9:c73bb66d3e42009a507f1d0d68070a75','createIndex indexName=drug_ingredient_ingredient_id_fk, tableName=drug_ingredient','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-207','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',205,'EXECUTED','9:02ec92fdfc36034e98053a96db1af087','createIndex indexName=drug_ingredient_units_fk, tableName=drug_ingredient','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-208','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',206,'EXECUTED','9:902fc9f15732d81316a76f8e4cc41751','createIndex indexName=drug_order_dose_units, tableName=drug_order','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-209','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',207,'EXECUTED','9:6d3645c460dd9852ee68819e14621baf','createIndex indexName=drug_order_duration_units_fk, tableName=drug_order','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-210','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',208,'EXECUTED','9:828d7ca3b2e2f9321e17ca9476cde10c','createIndex indexName=drug_order_frequency_fk, tableName=drug_order','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-211','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',209,'EXECUTED','9:6d5b5c5769e796644b23e53a94de5d52','createIndex indexName=drug_order_quantity_units, tableName=drug_order','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-212','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',210,'EXECUTED','9:95cb8795704d83066aa4453811565d1a','createIndex indexName=drug_order_route_fk, tableName=drug_order','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-213','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',211,'EXECUTED','9:252f9f79f6771323a43aab97b1d399f4','createIndex indexName=drug_reference_map_creator, tableName=drug_reference_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-214','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',212,'EXECUTED','9:89c5212e5f7e191af2377a9f1ae84721','createIndex indexName=drug_retired_by, tableName=drug','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-215','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',213,'EXECUTED','9:e3a54fccb93daf49b2fb1431f37638b1','createIndex indexName=encounter_changed_by, tableName=encounter','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-216','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',214,'EXECUTED','9:046ab551330b4f3341ee780bead9cd77','createIndex indexName=encounter_datetime_idx, tableName=encounter','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-217','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',215,'EXECUTED','9:eac35b50d3bd06f95a9f32b8771b92aa','createIndex indexName=encounter_diagnosis_changed_by_fk, tableName=encounter_diagnosis','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-218','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',216,'EXECUTED','9:1bd4fc0c19be4164c217c7a02e961bc8','createIndex indexName=encounter_diagnosis_coded_fk, tableName=encounter_diagnosis','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-219','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',217,'EXECUTED','9:a709283d1c1fb02f4332487f60a13dab','createIndex indexName=encounter_diagnosis_coded_name_fk, tableName=encounter_diagnosis','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-220','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',218,'EXECUTED','9:8417e1d842bd684d88a0dff74ad51913','createIndex indexName=encounter_diagnosis_condition_id_fk, tableName=encounter_diagnosis','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-221','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',219,'EXECUTED','9:977a750d9153eee0db1fe8a905d57e7c','createIndex indexName=encounter_diagnosis_creator_fk, tableName=encounter_diagnosis','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-222','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',220,'EXECUTED','9:93e46db9ed3da6fa1e186ef68a115d07','createIndex indexName=encounter_diagnosis_encounter_id_fk, tableName=encounter_diagnosis','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-223','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',221,'EXECUTED','9:347bcaf51c72d95b38842ebd2eb14ca0','createIndex indexName=encounter_diagnosis_patient_fk, tableName=encounter_diagnosis','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-224','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',222,'EXECUTED','9:516e557a538af4e1b9bdaab32be563c1','createIndex indexName=encounter_diagnosis_voided_by_fk, tableName=encounter_diagnosis','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-225','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',223,'EXECUTED','9:869a342df864bfbf8e2249314380dff1','createIndex indexName=encounter_for_proposal, tableName=concept_proposal','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-226','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',224,'EXECUTED','9:63f27e5f30a44eb4b627ee5fba13e961','createIndex indexName=encounter_form, tableName=encounter','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-227','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',225,'EXECUTED','9:73d3f1be54af152897179d3c1b118c2c','createIndex indexName=encounter_ibfk_1, tableName=encounter','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-228','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',226,'EXECUTED','9:19047b0c40b4dd19a751c87597f37227','createIndex indexName=encounter_id_fk, tableName=encounter_provider','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-229','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',227,'EXECUTED','9:730e9852873e50f0b2eea3adcfa146e1','createIndex indexName=encounter_location, tableName=encounter','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-230','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',228,'EXECUTED','9:80070390943bf39bee023684909d6553','createIndex indexName=encounter_note, tableName=note','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-231','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',229,'EXECUTED','9:ec648ee277fa3a8d089203c5f05b62da','createIndex indexName=encounter_observations, tableName=obs','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-232','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',230,'EXECUTED','9:c2c46b5ae50676e4cbf0ca9e470a5c4c','createIndex indexName=encounter_patient, tableName=encounter','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-233','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:20',231,'EXECUTED','9:2b25a9673f4a72bcc00934bd769b3b87','createIndex indexName=encounter_provider_changed_by, tableName=encounter_provider','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-234','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',232,'EXECUTED','9:551212be648a6b25f55cd7baf0d21cd2','createIndex indexName=encounter_provider_creator, tableName=encounter_provider','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-235','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',233,'EXECUTED','9:d955a82eb7fe5fe3169e34c1fa2c5097','createIndex indexName=encounter_provider_voided_by, tableName=encounter_provider','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-236','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',234,'EXECUTED','9:4308fa2b0c060f9536ea0ca5f958174d','createIndex indexName=encounter_role_changed_by_fk, tableName=encounter_role','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-237','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',235,'EXECUTED','9:2025a82fad04065e9416b7fa23d43704','createIndex indexName=encounter_role_creator_fk, tableName=encounter_role','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-238','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',236,'EXECUTED','9:17e4f07140e3fe814b0cb74a3686525f','createIndex indexName=encounter_role_id_fk, tableName=encounter_provider','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-239','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',237,'EXECUTED','9:faef2e53e051172cd31f7fb8ea5dd674','createIndex indexName=encounter_role_retired_by_fk, tableName=encounter_role','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-240','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',238,'EXECUTED','9:b499de19affb80e796e3d2812c3ac7d7','createIndex indexName=encounter_type_changed_by, tableName=encounter_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-241','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',239,'EXECUTED','9:b21a0b8cc949b2d117c4e019631ed038','createIndex indexName=encounter_type_id, tableName=encounter','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-242','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',240,'EXECUTED','9:7edff9fb7ac52e0a4549cd851327b104','createIndex indexName=encounter_type_retired_status, tableName=encounter_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-243','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',241,'EXECUTED','9:5cdf89c6bdadc1336dd61681327cabd7','createIndex indexName=encounter_visit_id_fk, tableName=encounter','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-244','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',242,'EXECUTED','9:f5a176c4c8afa473407bdcf5bbbbc84a','createIndex indexName=family_name2, tableName=person_name','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-245','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',243,'EXECUTED','9:1414385cfed3220326f98ac0c05351f1','createIndex indexName=field_answer_concept, tableName=field_answer','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-246','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',244,'EXECUTED','9:ce5051efe1a73d7e69b833e78f9e1699','createIndex indexName=field_retired_status, tableName=field','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-247','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',245,'EXECUTED','9:1f060b7f873aca98cad7a1e43a91436d','createIndex indexName=field_within_form, tableName=form_field','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-248','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',246,'EXECUTED','9:229281a4e1ae5b32e3021e9a70f0d680','createIndex indexName=first_name, tableName=person_name','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-249','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',247,'EXECUTED','9:ac8aa4372b211ec1b0cfcddf6d18b7ce','createIndex indexName=fk_concept_numeric_reference_range, tableName=concept_reference_range','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-250','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',248,'EXECUTED','9:08299bba89db2f4643943ad24393e376','createIndex indexName=fk_orderer_provider, tableName=orders','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-251','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',249,'EXECUTED','9:8087c33bd82fd3c1dc3bb6e46ee33e17','createIndex indexName=form_containing_field, tableName=form_field','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-252','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',250,'EXECUTED','9:7a4518fb37fe8840db1c1a1b47d98bd8','createIndex indexName=form_encounter_type, tableName=form','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-253','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',251,'EXECUTED','9:a6779f036456097fd92ef5ba78b88787','createIndex indexName=form_field_hierarchy, tableName=form_field','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-254','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',252,'EXECUTED','9:8181844ec262004e3dd3b25a75d7b394','createIndex indexName=form_published_and_retired_index, tableName=form','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-255','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',253,'EXECUTED','9:dcdbbfc642d60968f35d83b0520e9a47','createIndex indexName=form_published_index, tableName=form','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-256','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',254,'EXECUTED','9:d7420e9bb42002bab0c27938f38213b0','createIndex indexName=form_resource_changed_by, tableName=form_resource','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-257','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',255,'EXECUTED','9:f8b9bf134e613ef9d40fa4361a409474','createIndex indexName=form_retired_index, tableName=form','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-258','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',256,'EXECUTED','9:04d7d9553069edcf4d5182a67163e15c','createIndex indexName=global_property_changed_by, tableName=global_property','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-259','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',257,'EXECUTED','9:0de54a1284b3c43f445b78aa07c7566f','createIndex indexName=global_property_delete_privilege_fk, tableName=global_property','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-260','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',258,'EXECUTED','9:603dd2ac683b5b128e9a060ca938bcfb','createIndex indexName=global_property_edit_privilege_fk, tableName=global_property','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-261','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',259,'EXECUTED','9:90e6be8ba96411c68aa28246858a2062','createIndex indexName=global_property_view_privilege_fk, tableName=global_property','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-262','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',260,'EXECUTED','9:0ed85737690f4c3911e5d3642163e86d','createIndex indexName=has_a, tableName=concept_set','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-263','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',261,'EXECUTED','9:98fdc22a8864f95a83950b1089f00645','createIndex indexName=hl7_in_archive_message_state_idx, tableName=hl7_in_archive','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-264','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',262,'EXECUTED','9:38acd317c634fe59c3b827e50ac6ba3a','createIndex indexName=hl7_source_with_queue, tableName=hl7_in_queue','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-265','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',263,'EXECUTED','9:b83a666a15fd4ccec72e5cda18d320f6','createIndex indexName=identifier_creator, tableName=patient_identifier','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-266','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',264,'EXECUTED','9:85f2422520fba2e34e2e9cbe41663df4','createIndex indexName=identifier_name, tableName=patient_identifier','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-267','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',265,'EXECUTED','9:a888cf47a72ddbe84052cadca99281a6','createIndex indexName=identifier_voider, tableName=patient_identifier','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-268','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',266,'EXECUTED','9:376a230c14684f385705b5678ba075cb','createIndex indexName=identifies_person, tableName=person_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-269','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',267,'EXECUTED','9:4f48feebbfd3981e440d40536b28c362','createIndex indexName=idx_code_concept_reference_term, tableName=concept_reference_term','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-270','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',268,'EXECUTED','9:596392ab3ef195d93029d24ab950e63e','createIndex indexName=idx_concept_set_concept, tableName=concept_set','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-271','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',269,'EXECUTED','9:a658c74da24fc685e87393d6112e19c0','createIndex indexName=idx_patient_identifier_patient, tableName=patient_identifier','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-272','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',270,'EXECUTED','9:32bb5c184e92cc7436a87e89100f043b','createIndex indexName=inherited_role, tableName=role_role','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-273','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',271,'EXECUTED','9:8a279e291f918d4324bcaeee94f47e6a','createIndex indexName=inventory_item, tableName=drug_order','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-274','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',272,'EXECUTED','9:95784c4a42be17e6e5ceb627fd948678','createIndex indexName=last_name, tableName=person_name','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-275','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',273,'EXECUTED','9:20f31afa2f00176f17b991d9673bd1e9','createIndex indexName=location_attribute_attribute_type_id_fk, tableName=location_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-276','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',274,'EXECUTED','9:c6db08a6d0c86a607338f2721d842842','createIndex indexName=location_attribute_changed_by_fk, tableName=location_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-277','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',275,'EXECUTED','9:f2eb3509089174539baa75eaf3d3aa5d','createIndex indexName=location_attribute_creator_fk, tableName=location_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-278','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',276,'EXECUTED','9:762f2808e9fdaad34bd50fd391029fc0','createIndex indexName=location_attribute_location_fk, tableName=location_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-279','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',277,'EXECUTED','9:9546c2a5630bdbc6b7c7b7762b06c8b3','createIndex indexName=location_attribute_type_changed_by_fk, tableName=location_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-280','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',278,'EXECUTED','9:0d0369b79254ab9bb131e7250cf4a231','createIndex indexName=location_attribute_type_creator_fk, tableName=location_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-281','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',279,'EXECUTED','9:76b8fa556a0f789cd6f30b5fcf4190b9','createIndex indexName=location_attribute_type_retired_by_fk, tableName=location_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-282','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',280,'EXECUTED','9:00516e8473bb725566405e91f0a42a88','createIndex indexName=location_attribute_voided_by_fk, tableName=location_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-283','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',281,'EXECUTED','9:18cf1bc743ed2da063035c272bdfbe55','createIndex indexName=location_changed_by, tableName=location','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-284','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',282,'EXECUTED','9:f4164fed7d0b40e157f0ac9b42a50487','createIndex indexName=location_retired_status, tableName=location','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-285','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',283,'EXECUTED','9:766032d4b5448cbfc64e1415401f0ee7','createIndex indexName=location_tag_changed_by, tableName=location_tag','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-286','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',284,'EXECUTED','9:e7eb6aaa47e85739ca77af6014d1fc0e','createIndex indexName=location_tag_creator, tableName=location_tag','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-287','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',285,'EXECUTED','9:a3bdb28e5a5b361a02af53526ba0a4fc','createIndex indexName=location_tag_map_tag, tableName=location_tag_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-288','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',286,'EXECUTED','9:d8f6953073a68242db5f197c0dcc45c5','createIndex indexName=location_tag_retired_by, tableName=location_tag','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-289','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',287,'EXECUTED','9:046ca8554510f4b36b3daeea796d3688','createIndex indexName=location_type_fk, tableName=location','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-290','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',288,'EXECUTED','9:3fd279c70d86d577a62f30e870cb77e9','createIndex indexName=map_creator, tableName=concept_reference_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-291','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',289,'EXECUTED','9:2e3d7b5ed77fe6eac3be0ba224b17b5a','createIndex indexName=map_for_concept, tableName=concept_reference_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-292','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',290,'EXECUTED','9:8fa8ad653001e6cdd5c69c046b20b792','createIndex indexName=mapped_concept_map_type, tableName=concept_reference_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-293','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',291,'EXECUTED','9:6477c3f340da3a315b014d7060dfd1b0','createIndex indexName=mapped_concept_map_type_ref_term_map, tableName=concept_reference_term_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-294','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',292,'EXECUTED','9:0aa46557eaec8ea70fc9a424d78a9d43','createIndex indexName=mapped_concept_name, tableName=concept_name_tag_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-295','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',293,'EXECUTED','9:573a7b9ed1c6c80d91e2e1084acd34e5','createIndex indexName=mapped_concept_name_tag, tableName=concept_name_tag_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-296','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',294,'EXECUTED','9:e9d6aa468a733286ab3dfbd08413bf03','createIndex indexName=mapped_concept_proposal, tableName=concept_proposal_tag_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-297','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',295,'EXECUTED','9:27d885aceb8d2be79c717cf314db37d2','createIndex indexName=mapped_concept_proposal_tag, tableName=concept_proposal_tag_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-298','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',296,'EXECUTED','9:0580edb975cbf0bd71ebc8ff995154e5','createIndex indexName=mapped_concept_reference_term, tableName=concept_reference_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-299','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',297,'EXECUTED','9:82f8bbd83b5729e9799574625578b3fc','createIndex indexName=mapped_concept_source, tableName=concept_reference_term','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-300','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',298,'EXECUTED','9:27bf55422f2539a7566b87d19e4cb462','createIndex indexName=mapped_term_a, tableName=concept_reference_term_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-301','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',299,'EXECUTED','9:93b8e44e9e3538c5c9c23ead49af5705','createIndex indexName=mapped_term_b, tableName=concept_reference_term_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-302','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',300,'EXECUTED','9:59dc3d8c01098dcb0ea337eb572961a6','createIndex indexName=mapped_user_changed, tableName=concept_reference_term','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-303','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',301,'EXECUTED','9:c02284870fba163948f6325e9f3edf62','createIndex indexName=mapped_user_changed_concept_map_type, tableName=concept_map_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-304','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',302,'EXECUTED','9:a16cc5453a449512a89a1f1ecc5a57a0','createIndex indexName=mapped_user_changed_ref_term, tableName=concept_reference_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-305','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',303,'EXECUTED','9:691f63e728c2e0fed80f2f42ebb16e8e','createIndex indexName=mapped_user_changed_ref_term_map, tableName=concept_reference_term_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-306','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',304,'EXECUTED','9:88da2263ec08e82fb3b93174d9875088','createIndex indexName=mapped_user_creator, tableName=concept_reference_term','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-307','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',305,'EXECUTED','9:e4d4385bca63b1ef9c1ec8266cce1f47','createIndex indexName=mapped_user_creator_concept_map_type, tableName=concept_map_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-308','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',306,'EXECUTED','9:0e71e59c9c38127181d54c026e4faeed','createIndex indexName=mapped_user_creator_ref_term_map, tableName=concept_reference_term_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-309','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',307,'EXECUTED','9:bd39b3ca13ca9956be02f98c900d5203','createIndex indexName=mapped_user_retired, tableName=concept_reference_term','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-310','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',308,'EXECUTED','9:7139312bd9df139374f2dbe93bef651b','createIndex indexName=mapped_user_retired_concept_map_type, tableName=concept_map_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-311','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',309,'EXECUTED','9:723cc1c67ad7c536b1ec502fbe81a69f','createIndex indexName=medication_dispense_changed_by_fk, tableName=medication_dispense','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-312','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',310,'EXECUTED','9:bd3aa2db2496851d0abab1f218135ffc','createIndex indexName=medication_dispense_concept_fk, tableName=medication_dispense','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-313','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',311,'EXECUTED','9:685738785687d3c063af258eb9a3eff6','createIndex indexName=medication_dispense_creator_fk, tableName=medication_dispense','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-314','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',312,'EXECUTED','9:717963348fa42c51407e59c3f32969e0','createIndex indexName=medication_dispense_dispenser_fk, tableName=medication_dispense','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-315','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:21',313,'EXECUTED','9:bbc37dde368f0ce6cf61937f6d471425','createIndex indexName=medication_dispense_dose_units_fk, tableName=medication_dispense','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-316','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',314,'EXECUTED','9:3a50e39dfd545696ca5c21b7bde6819f','createIndex indexName=medication_dispense_drug_fk, tableName=medication_dispense','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-317','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',315,'EXECUTED','9:835cdbed7f618940367f86d97677fa62','createIndex indexName=medication_dispense_drug_order_fk, tableName=medication_dispense','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-318','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',316,'EXECUTED','9:8470a2c8c119d3ee1c4e47ab19b928bf','createIndex indexName=medication_dispense_encounter_fk, tableName=medication_dispense','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-319','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',317,'EXECUTED','9:931fdecf6740d2f53128ace67232d2ab','createIndex indexName=medication_dispense_frequency_fk, tableName=medication_dispense','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-320','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',318,'EXECUTED','9:11f459d3733d315cc818fe4536362a47','createIndex indexName=medication_dispense_location_fk, tableName=medication_dispense','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-321','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',319,'EXECUTED','9:a3c0d185883e564b0ab7c58a17ae6e15','createIndex indexName=medication_dispense_patient_fk, tableName=medication_dispense','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-322','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',320,'EXECUTED','9:133b08fe4883e54945e71f0724df9ef6','createIndex indexName=medication_dispense_quantity_units_fk, tableName=medication_dispense','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-323','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',321,'EXECUTED','9:cf3878622d92f7d6ea4c2a7f65b813f5','createIndex indexName=medication_dispense_route_fk, tableName=medication_dispense','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-324','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',322,'EXECUTED','9:6807d14262d2c36c271591150fe3b4ba','createIndex indexName=medication_dispense_status_fk, tableName=medication_dispense','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-325','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',323,'EXECUTED','9:d7002bf6e173636662a0159038789a87','createIndex indexName=medication_dispense_status_reason_fk, tableName=medication_dispense','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-326','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',324,'EXECUTED','9:1409764d6296ce04b71cf514283bb3a5','createIndex indexName=medication_dispense_substitution_reason_fk, tableName=medication_dispense','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-327','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',325,'EXECUTED','9:a3686dd43fef80ad8d7529b3cf532d0e','createIndex indexName=medication_dispense_substitution_type_fk, tableName=medication_dispense','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-328','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',326,'EXECUTED','9:9d6ce835769d0e59fcc229db905a0c9d','createIndex indexName=medication_dispense_type_fk, tableName=medication_dispense','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-329','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',327,'EXECUTED','9:d91d18ef8e1a9d60e6111d3059e0c467','createIndex indexName=medication_dispense_voided_by_fk, tableName=medication_dispense','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-330','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',328,'EXECUTED','9:88077f9537e665481ae2ff8bfaa8c7c3','createIndex indexName=member_patient, tableName=cohort_member','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-331','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',329,'EXECUTED','9:94ce07753a2ff290a216f79197d2e3df','createIndex indexName=middle_name, tableName=person_name','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-332','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',330,'EXECUTED','9:e1d41c4002a7c1e195c61ec19c490e03','createIndex indexName=name_for_concept, tableName=concept_name','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-333','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',331,'EXECUTED','9:f8957c18f2306433809ad37471a1bf29','createIndex indexName=name_for_person, tableName=person_name','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-334','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',332,'EXECUTED','9:6d9797c929fdbfe6ecfa9d002a31ca09','createIndex indexName=name_of_attribute, tableName=person_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-335','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',333,'EXECUTED','9:a900a0e456267241f5d1153be0c3bb95','createIndex indexName=name_of_concept, tableName=concept_name','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-336','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',334,'EXECUTED','9:dc21d0268a73d16a3278ceec0fc33955','createIndex indexName=name_of_location, tableName=location','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-337','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',335,'EXECUTED','9:253883a009f0da794afb515b3e3dac15','createIndex indexName=note_hierarchy, tableName=note','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-338','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',336,'EXECUTED','9:286434fd1fc3c25d9b0e4537d5dbe6e6','createIndex indexName=obs_concept, tableName=obs','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-339','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',337,'EXECUTED','9:cb3487f0dec243a85d9833d28dfd2fdb','createIndex indexName=obs_datetime_idx, tableName=obs','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-340','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',338,'EXECUTED','9:853c47fc47573646dceab8994595d011','createIndex indexName=obs_enterer, tableName=obs','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-341','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',339,'EXECUTED','9:24b047cc2e3f707247830415179b6354','createIndex indexName=obs_grouping_id, tableName=obs','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-342','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',340,'EXECUTED','9:b6652865209655b0bbf40c4bc94e6558','createIndex indexName=obs_location, tableName=obs','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-343','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',341,'EXECUTED','9:6370889eb6ad0ae7980f410439836b42','createIndex indexName=obs_name_of_coded_value, tableName=obs','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-344','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',342,'EXECUTED','9:cdfd59d6786deaaf425038dc9d6904d4','createIndex indexName=obs_note, tableName=note','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-345','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',343,'EXECUTED','9:5491f5cc87e59cd3503ca3e4b741ef5d','createIndex indexName=obs_order, tableName=obs','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-346','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',344,'EXECUTED','9:c98e99e0e341ae1771ba79a07d4f20aa','createIndex indexName=order_attribute_attribute_type_id_fk, tableName=order_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-347','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',345,'EXECUTED','9:01ac76f94f51466f8706678ee1fd3c22','createIndex indexName=order_attribute_changed_by_fk, tableName=order_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-348','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',346,'EXECUTED','9:a2a9fd83c36ff3f34ce28f2701217fdd','createIndex indexName=order_attribute_creator_fk, tableName=order_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-349','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',347,'EXECUTED','9:6a9f467ad606da9e15d71d2b35a877ef','createIndex indexName=order_attribute_order_fk, tableName=order_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-350','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',348,'EXECUTED','9:90362e2afeaa33bc8cb63fb81114b35d','createIndex indexName=order_attribute_type_changed_by_fk, tableName=order_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-351','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',349,'EXECUTED','9:c0b9060bf54a7c68588273ce39a11448','createIndex indexName=order_attribute_type_creator_fk, tableName=order_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-352','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',350,'EXECUTED','9:a51cfdfbba38ab411daf253d99d2a093','createIndex indexName=order_attribute_type_retired_by_fk, tableName=order_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-353','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',351,'EXECUTED','9:a25099d523cb668a69f6d512f761cecc','createIndex indexName=order_attribute_voided_by_fk, tableName=order_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-354','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',352,'EXECUTED','9:2c4fa218f9c410c1e832f872d88fc281','createIndex indexName=order_creator, tableName=orders','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-355','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',353,'EXECUTED','9:e8a060e124bf3d76f939b59918515970','createIndex indexName=order_for_patient, tableName=orders','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-356','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',354,'EXECUTED','9:e1a2e5e4f4e4693bd9bd8802d202e6ba','createIndex indexName=order_frequency_changed_by_fk, tableName=order_frequency','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-357','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',355,'EXECUTED','9:8d4aaa20956bdabd313c3000a10d9eac','createIndex indexName=order_frequency_creator_fk, tableName=order_frequency','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-358','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',356,'EXECUTED','9:bb56b0853d67d0799c78a53107af6cc2','createIndex indexName=order_frequency_retired_by_fk, tableName=order_frequency','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-359','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',357,'EXECUTED','9:c4b0cf614b054b9d46791a157038973b','createIndex indexName=order_group_attribute_attribute_type_id_fk, tableName=order_group_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-360','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',358,'EXECUTED','9:5f867db2d8170adb53de7930f29dc347','createIndex indexName=order_group_attribute_changed_by_fk, tableName=order_group_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-361','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',359,'EXECUTED','9:bdd767104dd0244c0cc264a20f90bcba','createIndex indexName=order_group_attribute_creator_fk, tableName=order_group_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-362','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',360,'EXECUTED','9:01f5be3f18943cdb213fd4b051b48733','createIndex indexName=order_group_attribute_order_group_fk, tableName=order_group_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-363','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',361,'EXECUTED','9:a13bf1fe7543bab23de23f0127c2b83c','createIndex indexName=order_group_attribute_type_changed_by_fk, tableName=order_group_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-364','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',362,'EXECUTED','9:bcee108894b7deb263b3cd76fe2b5b8b','createIndex indexName=order_group_attribute_type_creator_fk, tableName=order_group_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-365','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',363,'EXECUTED','9:349dac56230e3a6390990a7efd604a65','createIndex indexName=order_group_attribute_type_retired_by_fk, tableName=order_group_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-366','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',364,'EXECUTED','9:a1cdc45afcf9a48839128f7ff8c0bba8','createIndex indexName=order_group_attribute_voided_by_fk, tableName=order_group_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-367','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',365,'EXECUTED','9:a5e1b33f031b276c4cb79ac7d819f5af','createIndex indexName=order_group_changed_by_fk, tableName=order_group','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-368','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',366,'EXECUTED','9:e732f399ddaf8e63d1866f896c4290fe','createIndex indexName=order_group_creator_fk, tableName=order_group','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-369','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',367,'EXECUTED','9:e406f587ebd482b57f2ef85b7c9c608b','createIndex indexName=order_group_encounter_id_fk, tableName=order_group','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-370','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',368,'EXECUTED','9:f9a890c9892bd111da8afe27fe940992','createIndex indexName=order_group_order_group_reason_fk, tableName=order_group','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-371','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',369,'EXECUTED','9:d0ecb4343dd787e72e544d33f05efa92','createIndex indexName=order_group_parent_order_group_fk, tableName=order_group','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-372','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',370,'EXECUTED','9:a86442b760a306aec40ad1cf3db540c4','createIndex indexName=order_group_patient_id_fk, tableName=order_group','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-373','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',371,'EXECUTED','9:1cbe680e1b36eb71fe536e71cda1b22a','createIndex indexName=order_group_previous_order_group_fk, tableName=order_group','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-374','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',372,'EXECUTED','9:2baf5668af08f9ba624b1655c70566e4','createIndex indexName=order_group_set_id_fk, tableName=order_group','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-375','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',373,'EXECUTED','9:fae3e6a495a763cc50b306c57b5c117f','createIndex indexName=order_group_voided_by_fk, tableName=order_group','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-376','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',374,'EXECUTED','9:cfef560e3b7088fe43663bd9d87f60fb','createIndex indexName=order_set_attribute_attribute_type_id_fk, tableName=order_set_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-377','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',375,'EXECUTED','9:ee7e2f1a602453013126b08429a60b8f','createIndex indexName=order_set_attribute_changed_by_fk, tableName=order_set_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-378','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',376,'EXECUTED','9:0ed8b7ccfb8754e6c6f82df16f086923','createIndex indexName=order_set_attribute_creator_fk, tableName=order_set_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-379','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',377,'EXECUTED','9:e2f688c153c37d041e9991d325006b3d','createIndex indexName=order_set_attribute_order_set_fk, tableName=order_set_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-380','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',378,'EXECUTED','9:bb712e359fea3f67404c2d1386ca0dea','createIndex indexName=order_set_attribute_type_changed_by_fk, tableName=order_set_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-381','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',379,'EXECUTED','9:71caa0c3f59fdedfa4f7db05e9531c92','createIndex indexName=order_set_attribute_type_creator_fk, tableName=order_set_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-382','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',380,'EXECUTED','9:2733c1785cb34e2c0c489316fda7e0dc','createIndex indexName=order_set_attribute_type_retired_by_fk, tableName=order_set_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-383','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',381,'EXECUTED','9:42ce5ee8c112f7072a8c387388fba11c','createIndex indexName=order_set_attribute_voided_by_fk, tableName=order_set_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-384','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',382,'EXECUTED','9:143e8ee97cb49256f0780ff757ebf7b8','createIndex indexName=order_set_changed_by_fk, tableName=order_set','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-385','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',383,'EXECUTED','9:6b5f7f7223cfde95ce3d1797fe663cd4','createIndex indexName=order_set_creator_fk, tableName=order_set','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-386','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',384,'EXECUTED','9:d71d901869e860d64dd76b48a11101e4','createIndex indexName=order_set_member_changed_by_fk, tableName=order_set_member','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-387','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',385,'EXECUTED','9:cee78d73e8ada71132583944e31f064d','createIndex indexName=order_set_member_concept_id_fk, tableName=order_set_member','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-388','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',386,'EXECUTED','9:b45865020c8071b9fdd28157d1c5546d','createIndex indexName=order_set_member_creator_fk, tableName=order_set_member','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-389','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',387,'EXECUTED','9:1b33755962c4bbaebbda4386d260c728','createIndex indexName=order_set_member_order_set_id_fk, tableName=order_set_member','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-390','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',388,'EXECUTED','9:b324f2dacefa6e3b09003b5f4fa40313','createIndex indexName=order_set_member_order_type_fk, tableName=order_set_member','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-391','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',389,'EXECUTED','9:e6ec0bf69437e0c5f282d32631cdcb2e','createIndex indexName=order_set_member_retired_by_fk, tableName=order_set_member','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-392','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',390,'EXECUTED','9:a3cb7f6e41b02df699ac19efc3bc893f','createIndex indexName=order_set_retired_by_fk, tableName=order_set','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-393','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',391,'EXECUTED','9:bf6f015c09128c78c5e8c3acaa3e253e','createIndex indexName=order_type_changed_by, tableName=order_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-394','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',392,'EXECUTED','9:3d2b140b32744bf3c6b0bdceb33664ae','createIndex indexName=order_type_parent_order_type, tableName=order_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-395','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',393,'EXECUTED','9:23341b0cd252a3777eefef4e2d0c4086','createIndex indexName=order_type_retired_status, tableName=order_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-396','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',394,'EXECUTED','9:8c37151d5dc291f5812c8469053411cb','createIndex indexName=orders_accession_number, tableName=orders','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-397','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',395,'EXECUTED','9:76fdbde5ad5240a2836c7fa764eb8a9c','createIndex indexName=orders_care_setting, tableName=orders','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-398','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',396,'EXECUTED','9:82b05cad02817b708c309c350f90d8e6','createIndex indexName=orders_in_encounter, tableName=orders','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-399','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',397,'EXECUTED','9:1a46623fabbdab02f73f7db4e9230cf7','createIndex indexName=orders_order_group_id_fk, tableName=orders','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-400','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',398,'EXECUTED','9:9c98b07f3ada0ab5574652f229a63f5f','createIndex indexName=orders_order_number, tableName=orders','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-401','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',399,'EXECUTED','9:7e9b1891258aa36b830ae26252baa0c0','createIndex indexName=parent_cohort, tableName=cohort_member','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-402','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',400,'EXECUTED','9:fcb0fa185dd300cafd88558883f9e7fe','createIndex indexName=parent_location, tableName=location','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-403','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',401,'EXECUTED','9:7027331ab7c72de5400e077404ae9ff0','createIndex indexName=patient_address_creator, tableName=person_address','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-404','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',402,'EXECUTED','9:49662387b29c56a74c30a4925c2fd4d4','createIndex indexName=patient_address_void, tableName=person_address','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-405','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',403,'EXECUTED','9:c93a9b3c89bdebb9a90fdf961fe87da2','createIndex indexName=patient_identifier_changed_by, tableName=patient_identifier','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-406','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',404,'EXECUTED','9:e04d3d371cd824ed0fec1033238514cd','createIndex indexName=patient_identifier_ibfk_2, tableName=patient_identifier','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-407','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',405,'EXECUTED','9:f9e97797a6c810b2107d3647cd26d663','createIndex indexName=patient_identifier_program_id_fk, tableName=patient_identifier','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-408','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',406,'EXECUTED','9:c2fca333a1117a0741de8b2f1fef8d28','createIndex indexName=patient_identifier_type_changed_by, tableName=patient_identifier_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-409','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',407,'EXECUTED','9:ac24e701c65af71cd94fe69751ce4327','createIndex indexName=patient_identifier_type_retired_status, tableName=patient_identifier_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-410','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',408,'EXECUTED','9:0d9f01dc793215727ff3332425fc2c72','createIndex indexName=patient_in_program, tableName=patient_program','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-411','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',409,'EXECUTED','9:06abe40668304963e13c54d05f718dc2','createIndex indexName=patient_note, tableName=note','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-412','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',410,'EXECUTED','9:0d987fad1f58d60f4004cfc9f990a9c2','createIndex indexName=patient_program_attribute_attributetype_fk, tableName=patient_program_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-413','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',411,'EXECUTED','9:e87c2c094b8ecb3d7b78025531fed318','createIndex indexName=patient_program_attribute_changed_by_fk, tableName=patient_program_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-414','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',412,'EXECUTED','9:bb7ec4fa4c79c833aacfce44d9801783','createIndex indexName=patient_program_attribute_creator_fk, tableName=patient_program_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-415','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',413,'EXECUTED','9:ee3fec80985724159c4dfc46dc2af19e','createIndex indexName=patient_program_attribute_programid_fk, tableName=patient_program_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-416','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',414,'EXECUTED','9:0fcd9ba41a27bc32a3dca55fe5f3cbba','createIndex indexName=patient_program_attribute_voided_by_fk, tableName=patient_program_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-417','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',415,'EXECUTED','9:c0ddee53be1e9c7dc5806bafc966048c','createIndex indexName=patient_program_creator, tableName=patient_program','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-418','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',416,'EXECUTED','9:34baed60a645b50cce9222ae8331f9a8','createIndex indexName=patient_program_for_state, tableName=patient_state','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-419','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',417,'EXECUTED','9:ff446fcc6ab47f7a4ce9a3db324084a1','createIndex indexName=patient_program_location_id, tableName=patient_program','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-420','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',418,'EXECUTED','9:08b406a19760bcd00d3e0b4a4d2ad00e','createIndex indexName=patient_program_outcome_concept_id_fk, tableName=patient_program','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-421','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',419,'EXECUTED','9:c3766349011cd61b379f3a0dcacde990','createIndex indexName=patient_state_changer, tableName=patient_state','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-422','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',420,'EXECUTED','9:6147d0fb0fcbb57d9289c8fb47a7d2c3','createIndex indexName=patient_state_creator, tableName=patient_state','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-423','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',421,'EXECUTED','9:60d9ef75d6d7538f86888d0c0be7c915','createIndex indexName=patient_state_encounter_id_fk, tableName=patient_state','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-424','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',422,'EXECUTED','9:4fec7a00f2e897b61381127bf32bef2c','createIndex indexName=patient_state_voider, tableName=patient_state','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-425','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',423,'EXECUTED','9:0a39e82b36b880c2b048e36a8649e861','createIndex indexName=person_a_is_person, tableName=relationship','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-426','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',424,'EXECUTED','9:8461548fd55948b9eae79a86f3479c6f','createIndex indexName=person_address_changed_by, tableName=person_address','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-427','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',425,'EXECUTED','9:774e969fe5633115b039bb450eb1c236','createIndex indexName=person_attribute_type_retired_status, tableName=person_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-428','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',426,'EXECUTED','9:9c16ba9bb19af4f584e0ff285ef7411e','createIndex indexName=person_b_is_person, tableName=relationship','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-429','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',427,'EXECUTED','9:9e975b763b4daba5a8dbdb0fcf9c6d88','createIndex indexName=person_birthdate, tableName=person','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-430','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',428,'EXECUTED','9:1fc39c7b3eb7c11347ccaf63db83c9f8','createIndex indexName=person_death_date, tableName=person','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-431','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',429,'EXECUTED','9:ff5089b2ad0128f9ff614c7a5f9afdce','createIndex indexName=person_died_because, tableName=person','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-432','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',430,'EXECUTED','9:fdfac473836a8e79730956d9bbd9131e','createIndex indexName=person_id_for_user, tableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-433','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',431,'EXECUTED','9:f1ec5e58437388296d0370cd23a3edb4','createIndex indexName=person_merge_log_changed_by_fk, tableName=person_merge_log','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-434','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:22',432,'EXECUTED','9:34c22ab747f3e68e28947ef93f748f82','createIndex indexName=person_merge_log_creator, tableName=person_merge_log','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-435','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',433,'EXECUTED','9:8435a153bbff8712681896e516d83dca','createIndex indexName=person_merge_log_loser, tableName=person_merge_log','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-436','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',434,'EXECUTED','9:3934b3db17635c77f196d414c0383c14','createIndex indexName=person_merge_log_voided_by_fk, tableName=person_merge_log','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-437','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',435,'EXECUTED','9:9fe0b9579a0e2f9dba204ac915511c4e','createIndex indexName=person_merge_log_winner, tableName=person_merge_log','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-438','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',436,'EXECUTED','9:1950489877972f9f354570944c6bfef1','createIndex indexName=person_obs, tableName=obs','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-439','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',437,'EXECUTED','9:ac1ab0fa84eb782dbfcbbd21358ceb7b','createIndex indexName=previous_order_id_order_id, tableName=orders','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-440','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',438,'EXECUTED','9:e7781bf85b386e5362f5ce5604d77601','createIndex indexName=previous_version, tableName=obs','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-441','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',439,'EXECUTED','9:c1effd0de2859380dc240e23b14153c4','createIndex indexName=primary_drug_concept, tableName=drug','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-442','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',440,'EXECUTED','9:365d1a29cc60fd3475e62ef379d579b1','createIndex indexName=privilege_definitions, tableName=role_privilege','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-443','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',441,'EXECUTED','9:723267c4f8a944016638dc01bb352df1','createIndex indexName=privilege_which_can_edit, tableName=person_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-444','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',442,'EXECUTED','9:ca8ec0ba74418339fc0281fe3d4857a9','createIndex indexName=privilege_which_can_edit_encounter_type, tableName=encounter_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-445','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',443,'EXECUTED','9:dc48d257c2d17b8f803c77c2d7a9e5f2','createIndex indexName=privilege_which_can_view_encounter_type, tableName=encounter_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-446','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',444,'EXECUTED','9:be2191c844ff485c90d25ba3ccee76fa','createIndex indexName=program_attribute_type_changed_by_fk, tableName=program_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-447','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',445,'EXECUTED','9:adba68c04a37b257b0ab723960078283','createIndex indexName=program_attribute_type_creator_fk, tableName=program_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-448','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',446,'EXECUTED','9:51f1c44336192b8a9ce36b6ff34698df','createIndex indexName=program_attribute_type_retired_by_fk, tableName=program_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-449','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',447,'EXECUTED','9:0a3e7fcc312e9032ea6d70b641fcfcb8','createIndex indexName=program_concept, tableName=program','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-450','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',448,'EXECUTED','9:6bb05b9b3a18eaf23e968b9a3448b5e3','createIndex indexName=program_creator, tableName=program','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-451','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',449,'EXECUTED','9:c739cea22e03866b1f89c165c154fcb8','createIndex indexName=program_for_patient, tableName=patient_program','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-452','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',450,'EXECUTED','9:2cbd7ca1e3807836ed30e2baf2d25b60','createIndex indexName=program_for_workflow, tableName=program_workflow','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-453','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',451,'EXECUTED','9:52b001f2ab78ef996577fc6a5707ed8c','createIndex indexName=program_outcomes_concept_id_fk, tableName=program','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-454','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',452,'EXECUTED','9:d29c8d32c9d992052064b6c111ca5e9d','createIndex indexName=proposal_obs_concept_id, tableName=concept_proposal','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-455','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',453,'EXECUTED','9:6d44c1512ed06cc59572e0919ad710a4','createIndex indexName=proposal_obs_id, tableName=concept_proposal','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-456','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',454,'EXECUTED','9:308db49f71deefda3c8fd2939aa2213a','createIndex indexName=provider_attribute_attribute_type_id_fk, tableName=provider_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-457','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',455,'EXECUTED','9:c980c852c29584fc05f0fbe51936892a','createIndex indexName=provider_attribute_changed_by_fk, tableName=provider_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-458','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',456,'EXECUTED','9:4ed0e1a53b2fe7bf7ce488c6758c8dfd','createIndex indexName=provider_attribute_creator_fk, tableName=provider_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-459','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',457,'EXECUTED','9:762053038785a070150e97358e9e8334','createIndex indexName=provider_attribute_provider_fk, tableName=provider_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-460','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',458,'EXECUTED','9:b8ed7f7390b2036b2608261131f97441','createIndex indexName=provider_attribute_type_changed_by_fk, tableName=provider_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-461','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',459,'EXECUTED','9:371e03928d4d2407bf3d20584c6f0314','createIndex indexName=provider_attribute_type_creator_fk, tableName=provider_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-462','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',460,'EXECUTED','9:61282cb3e2a737d8c3cdacf599b82c27','createIndex indexName=provider_attribute_type_retired_by_fk, tableName=provider_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-463','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',461,'EXECUTED','9:db8cbddf59c1350d6f27e6a7f2d9af4e','createIndex indexName=provider_attribute_voided_by_fk, tableName=provider_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-464','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',462,'EXECUTED','9:38bd85e063cc009022c2e0be8783274e','createIndex indexName=provider_changed_by_fk, tableName=provider','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-465','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',463,'EXECUTED','9:c023ffd8ad9523a412f389c03647e364','createIndex indexName=provider_creator_fk, tableName=provider','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-466','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',464,'EXECUTED','9:c43b657fcf7cf30926b7253b850ff8a5','createIndex indexName=provider_id_fk, tableName=encounter_provider','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-467','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',465,'EXECUTED','9:3de2f415f35b10af9caa5018c8801dde','createIndex indexName=provider_person_id_fk, tableName=provider','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-468','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:23',466,'EXECUTED','9:fc132bf17a367ec33c97f73ad072cb82','createIndex indexName=provider_retired_by_fk, tableName=provider','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-469','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:24',467,'EXECUTED','9:287f724ea5952cae55ea37996736b6ea','createIndex indexName=provider_role_id_fk, tableName=provider','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-470','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:24',468,'EXECUTED','9:f558b935f3d99caa828d8a5dded7fe7a','createIndex indexName=provider_speciality_id_fk, tableName=provider','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-471','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:24',469,'EXECUTED','9:f975f910b887340bad1b8a7365221c41','createIndex indexName=referral_order_frequency_index, tableName=referral_order','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-472','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:24',470,'EXECUTED','9:445dfdf809fe22e24f2a40f6b6bf58bb','createIndex indexName=referral_order_location_fk, tableName=referral_order','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-473','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:24',471,'EXECUTED','9:b31208d095e6497f1984e8252d833175','createIndex indexName=referral_order_specimen_source_index, tableName=referral_order','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-474','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:24',472,'EXECUTED','9:4eb720b60086c4ae1a6b04e7a9b112d9','createIndex indexName=relation_creator, tableName=relationship','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-475','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:24',473,'EXECUTED','9:a27e8cdeb5c477e76dd4d81667e41511','createIndex indexName=relation_voider, tableName=relationship','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-476','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:24',474,'EXECUTED','9:a9f8c8559b4410861087b195eaba420d','createIndex indexName=relationship_changed_by, tableName=relationship','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-477','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:24',475,'EXECUTED','9:97a898d84149d9669243053e52e9308d','createIndex indexName=relationship_type_changed_by, tableName=relationship_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-478','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:24',476,'EXECUTED','9:eb89161ae0b88effb7ef914ea8b2f5b7','createIndex indexName=relationship_type_id, tableName=relationship','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-479','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:24',477,'EXECUTED','9:b8ab5fba806947b62a13973de77179c5','createIndex indexName=report_object_creator, tableName=report_object','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-480','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:24',478,'EXECUTED','9:62b287774c5ccf984e3475a2b3110388','createIndex indexName=role_definitions, tableName=user_role','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-481','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:24',479,'EXECUTED','9:daebca2057d03fd5ca3f369bd3c871d6','createIndex indexName=role_privilege_to_role, tableName=role_privilege','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-482','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:24',480,'EXECUTED','9:fcd05567ec3f3f5ec12154caf524ca83','createIndex indexName=route_concept, tableName=drug','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-483','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:24',481,'EXECUTED','9:ec7c09706fe166ffa1ef849cc12f52da','createIndex indexName=scheduler_changer, tableName=scheduler_task_config','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-484','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:24',482,'EXECUTED','9:0482c4aa4a1e382477af9d4656bc38d6','createIndex indexName=scheduler_creator, tableName=scheduler_task_config','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-485','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:24',483,'EXECUTED','9:7081c99dfdda1ef536e6421d05e9f7c6','createIndex indexName=serialized_object_changed_by, tableName=serialized_object','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-486','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:24',484,'EXECUTED','9:4852d0f8c059810c0e60bd06bae77d18','createIndex indexName=serialized_object_creator, tableName=serialized_object','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-487','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:24',485,'EXECUTED','9:ede1cf693cda04ace4d2178e28ab5506','createIndex indexName=serialized_object_retired_by, tableName=serialized_object','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-488','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:24',486,'EXECUTED','9:9462ecdcb11893767b9d6c771e3e5226','createIndex indexName=state_changed_by, tableName=program_workflow_state','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-489','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:24',487,'EXECUTED','9:6389649588454e210711b07a676053eb','createIndex indexName=state_concept, tableName=program_workflow_state','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-490','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:24',488,'EXECUTED','9:d0b7d15452f9afdf25eb7aa850d99183','createIndex indexName=state_creator, tableName=program_workflow_state','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-491','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:24',489,'EXECUTED','9:e81c14465c50e1b785dab39ec9d94be8','createIndex indexName=state_for_patient, tableName=patient_state','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-492','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',490,'EXECUTED','9:c6b9df65e94c1da784522a406cfdbc3b','createIndex indexName=task_config_for_property, tableName=scheduler_task_config_property','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-493','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',491,'EXECUTED','9:d70dc2b1d18cb277eb199ed590e01613','createIndex indexName=test_order_frequency_fk, tableName=test_order','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-494','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',492,'EXECUTED','9:966656a9885a4f4880b433a5ea475115','createIndex indexName=test_order_location_fk, tableName=test_order','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-495','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',493,'EXECUTED','9:7972e97bf82da805d15c60c81ed70dd6','createIndex indexName=test_order_specimen_source_fk, tableName=test_order','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-496','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',494,'EXECUTED','9:8f4cfe154b3b909895eeb69944f7ff61','createIndex indexName=type_created_by, tableName=order_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-497','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',495,'EXECUTED','9:7b1a67707167bb6b28594b1e5265e8f0','createIndex indexName=type_creator, tableName=patient_identifier_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-498','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',496,'EXECUTED','9:69622234bf2103bcdebd3028c068283b','createIndex indexName=type_of_field, tableName=field','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-499','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',497,'EXECUTED','9:ba61ce581f9aafbafbb915fb32122d3d','createIndex indexName=type_of_order, tableName=orders','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-500','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',498,'EXECUTED','9:550aad1690a517852ed411d0f26aa495','createIndex indexName=user_creator, tableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-501','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',499,'EXECUTED','9:1e5ea3adea21f93a04525f1c2ac731bb','createIndex indexName=user_role_to_users, tableName=user_role','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-502','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',500,'EXECUTED','9:6e7cc688d86eea824947bedeb37f4843','createIndex indexName=user_who_changed, tableName=patient_program','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-503','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',501,'EXECUTED','9:54b9b6461cfac5bbc705e3bfea98894d','createIndex indexName=user_who_changed_alert, tableName=notification_alert','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-504','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',502,'EXECUTED','9:7160311b890576ae9b4e0e7b93dc809f','createIndex indexName=user_who_changed_cohort, tableName=cohort','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-505','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',503,'EXECUTED','9:87b420e5d38fb091a119af82493dad6c','createIndex indexName=user_who_changed_concept, tableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-506','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',504,'EXECUTED','9:854cd5ac9c6ee946874db8ac95f04ecf','createIndex indexName=user_who_changed_description, tableName=concept_description','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-507','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',505,'EXECUTED','9:58c0d8293de3511c71ab3c8f236131ad','createIndex indexName=user_who_changed_drug_reference_map, tableName=drug_reference_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-508','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',506,'EXECUTED','9:27364ad5c91d2050cdfb4711bf97843e','createIndex indexName=user_who_changed_field, tableName=field','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-509','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',507,'EXECUTED','9:729d491b56871afeff3f2a21e010473a','createIndex indexName=user_who_changed_note, tableName=note','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-510','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',508,'EXECUTED','9:8044090843896deb871a2ae3891e7dc8','createIndex indexName=user_who_changed_pat, tableName=patient','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-511','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',509,'EXECUTED','9:8c053fc07601dad1bc6f0bc4a1ee73ae','createIndex indexName=user_who_changed_person, tableName=person','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-512','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',510,'EXECUTED','9:9f2e046e42bd59cd4f6ad3fe7d5ff8f7','createIndex indexName=user_who_changed_program, tableName=program','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-513','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',511,'EXECUTED','9:5da4b69eb64d7bc27033356199c3a1f2','createIndex indexName=user_who_changed_proposal, tableName=concept_proposal','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-514','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',512,'EXECUTED','9:3c08fc5e8d8b3b571a5a6dd7f90f9122','createIndex indexName=user_who_changed_report_object, tableName=report_object','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-515','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',513,'EXECUTED','9:88cbaf07497d3f10bdfebcdca7e111a6','createIndex indexName=user_who_changed_user, tableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-516','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',514,'EXECUTED','9:defdb0b39f8ddfa97faf1e5eb8cc627a','createIndex indexName=user_who_created, tableName=concept_set','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-517','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',515,'EXECUTED','9:ebc883e9f48821e176ddab8f312aee49','createIndex indexName=user_who_created_description, tableName=concept_description','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-518','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',516,'EXECUTED','9:a9d81999265f81985688851a60d77747','createIndex indexName=user_who_created_field, tableName=field','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-519','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',517,'EXECUTED','9:a59115d2459a6b759b2fec5e6e5337c1','createIndex indexName=user_who_created_field_answer, tableName=field_answer','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-520','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',518,'EXECUTED','9:da5b482701afa783fdc537bbe4479b43','createIndex indexName=user_who_created_field_type, tableName=field_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-521','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',519,'EXECUTED','9:b970f229ac3b079f95a01d17b6e7bed6','createIndex indexName=user_who_created_form, tableName=form','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-522','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',520,'EXECUTED','9:af96ae2f9203c38a4d9bd9fa1a83304e','createIndex indexName=user_who_created_form_field, tableName=form_field','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-523','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:25',521,'EXECUTED','9:a1aee22f150600f836327d39772b4bff','createIndex indexName=user_who_created_hl7_source, tableName=hl7_source','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-524','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',522,'EXECUTED','9:1ae5cf1908a6ace060164781899c9b60','createIndex indexName=user_who_created_location, tableName=location','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-525','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',523,'EXECUTED','9:985f2f1fafc6e0026ad3ede44a25a619','createIndex indexName=user_who_created_name, tableName=concept_name','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-526','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',524,'EXECUTED','9:9c9937944fbd0c49dd3007c4b976db2a','createIndex indexName=user_who_created_name_tag, tableName=concept_name_tag','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-527','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',525,'EXECUTED','9:4efe0e130e17434348442edad7bc1691','createIndex indexName=user_who_created_note, tableName=note','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-528','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',526,'EXECUTED','9:7a886e6e609c5083c010fe9f6a662bb5','createIndex indexName=user_who_created_patient, tableName=patient','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-529','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',527,'EXECUTED','9:55dee31835373065d4b9acbfe4ec880c','createIndex indexName=user_who_created_person, tableName=person','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-530','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',528,'EXECUTED','9:12d43ff56e86934758f0a50046ee5660','createIndex indexName=user_who_created_proposal, tableName=concept_proposal','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-531','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',529,'EXECUTED','9:40f3a906254e269d3e6097b1a29e3e43','createIndex indexName=user_who_created_rel, tableName=relationship_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-532','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',530,'EXECUTED','9:f35f3ba07ac64bed393826a6ade7b9fa','createIndex indexName=user_who_created_type, tableName=encounter_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-533','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',531,'EXECUTED','9:717be0168142b31323a880abb4d2f607','createIndex indexName=user_who_last_changed_form, tableName=form','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-534','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',532,'EXECUTED','9:81c1a15869a07cc55a51b69354e197ea','createIndex indexName=user_who_last_changed_form_field, tableName=form_field','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-535','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',533,'EXECUTED','9:500caf57aa21a6d26eeef64a5a58b616','createIndex indexName=user_who_made_name, tableName=person_name','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-536','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',534,'EXECUTED','9:c906b658cf58dbc14befc2e2493406f6','createIndex indexName=user_who_retired_concept, tableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-537','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',535,'EXECUTED','9:abd22b2c7f8c695b7ece476e9a03af20','createIndex indexName=user_who_retired_concept_class, tableName=concept_class','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-538','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',536,'EXECUTED','9:23b1efc3b64edb3d9b007d2ce6a11f6c','createIndex indexName=user_who_retired_concept_datatype, tableName=concept_datatype','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-539','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',537,'EXECUTED','9:54962f2a0127da229496088720121c67','createIndex indexName=user_who_retired_concept_source, tableName=concept_reference_source','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-540','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',538,'EXECUTED','9:db2bd360da6c8209a5f402b67f80f853','createIndex indexName=user_who_retired_drug_reference_map, tableName=drug_reference_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-541','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',539,'EXECUTED','9:a8653a716055fdb592af750e1472b236','createIndex indexName=user_who_retired_encounter_type, tableName=encounter_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-542','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',540,'EXECUTED','9:d3513bd86f7e062c3f31852f97f1151e','createIndex indexName=user_who_retired_field, tableName=field','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-543','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',541,'EXECUTED','9:ce0afabff1b5bea6e83af40f27287ffc','createIndex indexName=user_who_retired_form, tableName=form','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-544','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',542,'EXECUTED','9:a47701913253e05f45f61bc0290ad8ca','createIndex indexName=user_who_retired_location, tableName=location','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-545','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',543,'EXECUTED','9:632608ffff583d4a96a7805492d9572c','createIndex indexName=user_who_retired_order_type, tableName=order_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-546','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',544,'EXECUTED','9:abff68ea01af8da721b56e9dde24c2e8','createIndex indexName=user_who_retired_patient_identifier_type, tableName=patient_identifier_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-547','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',545,'EXECUTED','9:f1593fd43b7d6dc9fa4880e5e75af855','createIndex indexName=user_who_retired_person_attribute_type, tableName=person_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-548','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',546,'EXECUTED','9:7816e6877258b2c529d1fb1e2891285a','createIndex indexName=user_who_retired_relationship_type, tableName=relationship_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-549','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',547,'EXECUTED','9:b7b711b36abf5a96decb23d5bab1cd0d','createIndex indexName=user_who_retired_this_user, tableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-550','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',548,'EXECUTED','9:d59000fad136de43930735af61dd95d5','createIndex indexName=user_who_voided_cohort, tableName=cohort','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-551','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',549,'EXECUTED','9:7547aebd36d8dc9c6f8e5fb7f4b79cb6','createIndex indexName=user_who_voided_encounter, tableName=encounter','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-552','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',550,'EXECUTED','9:a3c6cc3469331156db7ce08ffb775428','createIndex indexName=user_who_voided_name, tableName=person_name','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-553','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',551,'EXECUTED','9:8e2dfa83fa364ab7e3447cdacef0b5f5','createIndex indexName=user_who_voided_name_tag, tableName=concept_name_tag','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-554','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',552,'EXECUTED','9:6eda38e529ec760ff41362f2ffdd81d2','createIndex indexName=user_who_voided_obs, tableName=obs','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-555','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',553,'EXECUTED','9:8b1020e51145ceba751a07a59e5443b8','createIndex indexName=user_who_voided_order, tableName=orders','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-556','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',554,'EXECUTED','9:e7c4f1c1894bab9a1e2e7de9bcc84f97','createIndex indexName=user_who_voided_patient, tableName=patient','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-557','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',555,'EXECUTED','9:5aa403c49b7541e796b8bf2617960c06','createIndex indexName=user_who_voided_patient_program, tableName=patient_program','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-558','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',556,'EXECUTED','9:2bd5442f7da82260ce88e5da8114b3a3','createIndex indexName=user_who_voided_person, tableName=person','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-559','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',557,'EXECUTED','9:9f1c7ced5528afd1addfb6a5fe0b4d9d','createIndex indexName=user_who_voided_report_object, tableName=report_object','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-560','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',558,'EXECUTED','9:38d7712704a932615f337eb3576f01d4','createIndex indexName=user_who_voided_this_name, tableName=concept_name','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-561','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',559,'EXECUTED','9:ca5694dcab0d08fe8298fef02673b705','createIndex indexName=visit_attribute_attribute_type_id_fk, tableName=visit_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-562','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',560,'EXECUTED','9:b77d0aa321cd6380b869d97ecdae9a95','createIndex indexName=visit_attribute_changed_by_fk, tableName=visit_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-563','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',561,'EXECUTED','9:0007b768e70e0eec961f00603081b5bc','createIndex indexName=visit_attribute_creator_fk, tableName=visit_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-564','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',562,'EXECUTED','9:eeb57c751a1584beb0105946a15a46b1','createIndex indexName=visit_attribute_type_changed_by_fk, tableName=visit_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-565','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',563,'EXECUTED','9:78fc0af16765e1af3896b94dba3cff76','createIndex indexName=visit_attribute_type_creator_fk, tableName=visit_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-566','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',564,'EXECUTED','9:27f6f93021538f83e41dc53b6f973a0c','createIndex indexName=visit_attribute_type_retired_by_fk, tableName=visit_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-567','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',565,'EXECUTED','9:1b02c1993c0014662b9f9d88ed468de9','createIndex indexName=visit_attribute_visit_fk, tableName=visit_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-568','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',566,'EXECUTED','9:2bd68e166b4ee50f34caed1fa4b49be2','createIndex indexName=visit_attribute_voided_by_fk, tableName=visit_attribute','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-569','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',567,'EXECUTED','9:654a9b0b30189fb5751fb01533993b9d','createIndex indexName=visit_changed_by_fk, tableName=visit','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-570','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',568,'EXECUTED','9:98fc288cef9d5c69cc08357092ec1755','createIndex indexName=visit_creator_fk, tableName=visit','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-571','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',569,'EXECUTED','9:fb6a788ceeb07bda9cbe32b4453fd7bd','createIndex indexName=visit_indication_concept_fk, tableName=visit','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-572','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',570,'EXECUTED','9:ca26d7fbfe48f9148598a7c82de0c018','createIndex indexName=visit_location_fk, tableName=visit','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-573','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',571,'EXECUTED','9:ba94bb104a4927b26a5d7a8c216e2bf6','createIndex indexName=visit_patient_index, tableName=visit','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-574','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',572,'EXECUTED','9:4809cd4f2083015d6141418faa0e54d5','createIndex indexName=visit_type_changed_by, tableName=visit_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-575','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',573,'EXECUTED','9:6f21316be3dd48f811efdb5e5d8105d2','createIndex indexName=visit_type_creator, tableName=visit_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-576','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',574,'EXECUTED','9:34729d41f10e24322fcac3a39c47ed2a','createIndex indexName=visit_type_fk, tableName=visit','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-577','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',575,'EXECUTED','9:58c77fd41e3000866a1beb250f309aae','createIndex indexName=visit_type_retired_by, tableName=visit_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-578','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',576,'EXECUTED','9:9fa9728151d9814a6eef7a2a78482b37','createIndex indexName=visit_voided_by_fk, tableName=visit','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-579','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',577,'EXECUTED','9:485b340e2e9b28d1558de9b2ed7aed60','createIndex indexName=workflow_changed_by, tableName=program_workflow','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-580','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',578,'EXECUTED','9:3b34f504fb3e7efa0b209db99841c055','createIndex indexName=workflow_concept, tableName=program_workflow','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-581','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',579,'EXECUTED','9:9c7cadf47e21251d621aeb40b0a86ff8','createIndex indexName=workflow_creator, tableName=program_workflow','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-582','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',580,'EXECUTED','9:4bb5f11c0a6d49112cb3600c752a9a04','createIndex indexName=workflow_for_state, tableName=program_workflow_state','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-583','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',581,'EXECUTED','9:29ba91f4fac5b75bdd584f2b892eca81','addForeignKeyConstraint baseTableName=person_address, constraintName=address_for_person, referencedTableName=person','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-584','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',582,'EXECUTED','9:bba02f0ce64e2324f655222c1bc3c38e','addForeignKeyConstraint baseTableName=notification_alert, constraintName=alert_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-585','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',583,'EXECUTED','9:e903f30e23291f2b1cfcbc2d4c09a9b8','addForeignKeyConstraint baseTableName=notification_alert_recipient, constraintName=alert_read_by_user, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-586','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',584,'EXECUTED','9:346b1ec320ca0c5e4534a953a40f8260','addForeignKeyConstraint baseTableName=allergy, constraintName=allergy_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-587','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',585,'EXECUTED','9:cc3545c21112d4ff18eae60b04c7fbc2','addForeignKeyConstraint baseTableName=allergy, constraintName=allergy_coded_allergen_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-588','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',586,'EXECUTED','9:1913cb9c8acdaef303176a12924eacf8','addForeignKeyConstraint baseTableName=allergy, constraintName=allergy_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-589','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',587,'EXECUTED','9:a191cb12c5b170c3034e757b1cf80d0e','addForeignKeyConstraint baseTableName=allergy, constraintName=allergy_encounter_id_fk, referencedTableName=encounter','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-590','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',588,'EXECUTED','9:f87a0840a70c99de5026e3b9da5e3004','addForeignKeyConstraint baseTableName=allergy, constraintName=allergy_patient_id_fk, referencedTableName=patient','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-591','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',589,'EXECUTED','9:5ccf2593c1a70de5df369426c14e6ce4','addForeignKeyConstraint baseTableName=allergy_reaction, constraintName=allergy_reaction_allergy_id_fk, referencedTableName=allergy','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-592','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',590,'EXECUTED','9:6b2f3abb790cba099561fec7d413b505','addForeignKeyConstraint baseTableName=allergy_reaction, constraintName=allergy_reaction_reaction_concept_id_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-593','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',591,'EXECUTED','9:8c3207ef17e5a9da5c39c5d6785d41e2','addForeignKeyConstraint baseTableName=allergy, constraintName=allergy_severity_concept_id_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-594','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',592,'EXECUTED','9:59c8f58be8369a546ee63e616f8c22e4','addForeignKeyConstraint baseTableName=allergy, constraintName=allergy_voided_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-595','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',593,'EXECUTED','9:57b4b86bce0ada5eb1eb2285f1402835','addForeignKeyConstraint baseTableName=concept_answer, constraintName=answer, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-596','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',594,'EXECUTED','9:91472e7247e468c1e17069399566c866','addForeignKeyConstraint baseTableName=concept_answer, constraintName=answer_answer_drug_fk, referencedTableName=drug','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-597','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',595,'EXECUTED','9:2ccc83e95287abc84526bbd913386049','addForeignKeyConstraint baseTableName=obs, constraintName=answer_concept, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-598','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',596,'EXECUTED','9:a987a94fafde7c8fb08b4c2950906e98','addForeignKeyConstraint baseTableName=obs, constraintName=answer_concept_drug, referencedTableName=drug','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-599','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',597,'EXECUTED','9:e4fd442ee2c0410fafa939b375b71cf9','addForeignKeyConstraint baseTableName=concept_answer, constraintName=answer_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-600','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',598,'EXECUTED','9:a0303d17d8caf58fe7301c98e86c9bc2','addForeignKeyConstraint baseTableName=concept_answer, constraintName=answers_for_concept, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-601','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',599,'EXECUTED','9:c7284cf39393d2a8c6bef8e4c96afed0','addForeignKeyConstraint baseTableName=field_answer, constraintName=answers_for_field, referencedTableName=field','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-602','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',600,'EXECUTED','9:76d8aca237f1571d7300ec7788c410e4','addForeignKeyConstraint baseTableName=person_attribute, constraintName=attribute_changer, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-603','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',601,'EXECUTED','9:723363cc81ff7af62ee8fb2e7fe767b7','addForeignKeyConstraint baseTableName=person_attribute, constraintName=attribute_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-604','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',602,'EXECUTED','9:e90f1ac8fe1f84d40402b87c7783d87a','addForeignKeyConstraint baseTableName=person_attribute_type, constraintName=attribute_type_changer, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-605','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',603,'EXECUTED','9:f881c0875a697a50ba46c1e516af43a8','addForeignKeyConstraint baseTableName=person_attribute_type, constraintName=attribute_type_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-606','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',604,'EXECUTED','9:a9d7aa2e2eba636c1fa7dbeea90e76a1','addForeignKeyConstraint baseTableName=person_attribute, constraintName=attribute_voider, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-607','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',605,'EXECUTED','9:e12615313a25d9a06935cd8c2847ab8e','addForeignKeyConstraint baseTableName=care_setting, constraintName=care_setting_changed_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-608','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',606,'EXECUTED','9:3315c3e2f67dafd2b99d970ae97d40ab','addForeignKeyConstraint baseTableName=care_setting, constraintName=care_setting_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-609','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',607,'EXECUTED','9:11ff2acc6adcc6c008060f0d1d7f3ce9','addForeignKeyConstraint baseTableName=care_setting, constraintName=care_setting_retired_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-610','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',608,'EXECUTED','9:0932bdf7c69fd50bf9ae467f3067331d','addForeignKeyConstraint baseTableName=order_set, constraintName=category_order_set_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-611','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',609,'EXECUTED','9:34ee7ecea6f8527138737eeaabe5deeb','addForeignKeyConstraint baseTableName=cohort, constraintName=cohort_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-612','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',610,'EXECUTED','9:42d2cb783dfdecfd32e96dc536ddcd7b','addForeignKeyConstraint baseTableName=cohort_member, constraintName=cohort_member_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-613','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',611,'EXECUTED','9:7cd39464d5a06fc72f5d4cede44f6491','addForeignKeyConstraint baseTableName=concept_attribute, constraintName=concept_attribute_attribute_type_id_fk, referencedTableName=concept_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-614','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',612,'EXECUTED','9:52d104184aae726787a1d2241c921a5f','addForeignKeyConstraint baseTableName=concept_attribute, constraintName=concept_attribute_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-615','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',613,'EXECUTED','9:5550fcf891ddaf18fe72947f6b800279','addForeignKeyConstraint baseTableName=concept_attribute, constraintName=concept_attribute_concept_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-616','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',614,'EXECUTED','9:2794c7b2ff3004698ad56b8e1c209dfd','addForeignKeyConstraint baseTableName=concept_attribute, constraintName=concept_attribute_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-617','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',615,'EXECUTED','9:e7b54a743495b4f18be37067a75244e3','addForeignKeyConstraint baseTableName=concept_attribute_type, constraintName=concept_attribute_type_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-618','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',616,'EXECUTED','9:b7f4142b9bda45d69d3699680b54e63e','addForeignKeyConstraint baseTableName=concept_attribute_type, constraintName=concept_attribute_type_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-619','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',617,'EXECUTED','9:4273bb7cc94c9d79ed95fe132c99fe73','addForeignKeyConstraint baseTableName=concept_attribute_type, constraintName=concept_attribute_type_retired_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-620','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',618,'EXECUTED','9:7e7e34077aff75749115181c20e899de','addForeignKeyConstraint baseTableName=concept_attribute, constraintName=concept_attribute_voided_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-621','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',619,'EXECUTED','9:55cc3e63aa3fe7097dcf3ffb8cefd491','addForeignKeyConstraint baseTableName=concept_complex, constraintName=concept_attributes, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-622','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',620,'EXECUTED','9:c346baecfd8a1446d59a4571ebca1d68','addForeignKeyConstraint baseTableName=concept_class, constraintName=concept_class_changed_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-623','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:26',621,'EXECUTED','9:b7043b217e51486bde0c03956197e3aa','addForeignKeyConstraint baseTableName=concept_class, constraintName=concept_class_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-624','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',622,'EXECUTED','9:cf936e19a389b004310de336847c6145','addForeignKeyConstraint baseTableName=concept, constraintName=concept_classes, referencedTableName=concept_class','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-625','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',623,'EXECUTED','9:cfafc75733f5d7fd30c76d18a3074068','addForeignKeyConstraint baseTableName=concept, constraintName=concept_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-626','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',624,'EXECUTED','9:78ed5b4a722d0cb79057d09e348afb98','addForeignKeyConstraint baseTableName=concept_datatype, constraintName=concept_datatype_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-627','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',625,'EXECUTED','9:fa0e058d812ce3d14fe6c2ddf034aa05','addForeignKeyConstraint baseTableName=concept, constraintName=concept_datatypes, referencedTableName=concept_datatype','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-628','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',626,'EXECUTED','9:0300fcc036c9dae9bbe410bd6fd7c917','addForeignKeyConstraint baseTableName=field, constraintName=concept_for_field, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-629','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',627,'EXECUTED','9:9a0f0eb8f944984e8010267be9470b01','addForeignKeyConstraint baseTableName=concept_proposal, constraintName=concept_for_proposal, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-630','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',628,'EXECUTED','9:5912d2d5386f75a033b58aeb9269696e','addForeignKeyConstraint baseTableName=drug_reference_map, constraintName=concept_map_type_for_drug_reference_map, referencedTableName=concept_map_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-631','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',629,'EXECUTED','9:40d6b70f5489b07d9222ca26691c9296','addForeignKeyConstraint baseTableName=concept_name, constraintName=concept_name_changed_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-632','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',630,'EXECUTED','9:f5f2b02a50edc79d6149980ce4c0a823','addForeignKeyConstraint baseTableName=concept_name_tag, constraintName=concept_name_tag_changed_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-633','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',631,'EXECUTED','9:85358787fd1eeb47c8255b6da479ddf4','addForeignKeyConstraint baseTableName=concept_reference_source, constraintName=concept_reference_source_changed_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-634','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',632,'EXECUTED','9:241f28abe79a97e43da876096b927ca0','addForeignKeyConstraint baseTableName=drug_reference_map, constraintName=concept_reference_term_for_drug_reference_map, referencedTableName=concept_reference_term','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-635','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',633,'EXECUTED','9:bc2d7ae1c0fd5ef455281b5a92034cdf','addForeignKeyConstraint baseTableName=concept_reference_source, constraintName=concept_source_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-636','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',634,'EXECUTED','9:9eb595ad5c6235b40cdfffcb351c27d7','addForeignKeyConstraint baseTableName=concept_state_conversion, constraintName=concept_triggers_conversion, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-637','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',635,'EXECUTED','9:785978bd611370a7c48e41d7129c0a9a','addForeignKeyConstraint baseTableName=conditions, constraintName=condition_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-638','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',636,'EXECUTED','9:623dd4e01dcc96e7a96085cc4b9012dd','addForeignKeyConstraint baseTableName=conditions, constraintName=condition_condition_coded_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-639','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',637,'EXECUTED','9:513e38b1616e9c39fff0a81b88f6d48f','addForeignKeyConstraint baseTableName=conditions, constraintName=condition_condition_coded_name_fk, referencedTableName=concept_name','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-640','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',638,'EXECUTED','9:dfaa19f4cce98d82c4e0457816e8cf59','addForeignKeyConstraint baseTableName=conditions, constraintName=condition_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-641','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',639,'EXECUTED','9:83ec2123d445dc74363dd629a02d11e5','addForeignKeyConstraint baseTableName=conditions, constraintName=condition_patient_fk, referencedTableName=patient','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-642','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',640,'EXECUTED','9:07be6a9f15d636b41878aeae5d5c3ff3','addForeignKeyConstraint baseTableName=conditions, constraintName=condition_previous_version_fk, referencedTableName=conditions','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-643','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',641,'EXECUTED','9:86d3966776d0bd3d6118f322615720d4','addForeignKeyConstraint baseTableName=conditions, constraintName=condition_voided_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-644','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',642,'EXECUTED','9:88d60aaf8888ee41287734ac7524d2ea','addForeignKeyConstraint baseTableName=conditions, constraintName=conditions_encounter_id_fk, referencedTableName=encounter','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-645','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',643,'EXECUTED','9:ceaf17cc19578fab74c105e68559a2b0','addForeignKeyConstraint baseTableName=concept_state_conversion, constraintName=conversion_involves_workflow, referencedTableName=program_workflow','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-646','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',644,'EXECUTED','9:55297b53f50dc071d42a89a4cdc6f7a0','addForeignKeyConstraint baseTableName=concept_state_conversion, constraintName=conversion_to_state, referencedTableName=program_workflow_state','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-647','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',645,'EXECUTED','9:c7bb0d3d6445e8cf3fba8c7184a4f7f8','addForeignKeyConstraint baseTableName=person_attribute, constraintName=defines_attribute_type, referencedTableName=person_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-648','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',646,'EXECUTED','9:9787e3f362d0c10b6a29b249865ee42e','addForeignKeyConstraint baseTableName=patient_identifier, constraintName=defines_identifier_type, referencedTableName=patient_identifier_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-649','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',647,'EXECUTED','9:c34b87280c14bb296b7d34f121792755','addForeignKeyConstraint baseTableName=concept_description, constraintName=description_for_concept, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-650','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',648,'EXECUTED','9:2d6f5efc66eb0cdf897f645f5be631a3','addForeignKeyConstraint baseTableName=diagnosis_attribute, constraintName=diagnosis_attribute_attribute_type_id_fk, referencedTableName=diagnosis_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-651','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',649,'EXECUTED','9:3e23480a5b6ed6a77402e6fb97c9fe5e','addForeignKeyConstraint baseTableName=diagnosis_attribute, constraintName=diagnosis_attribute_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-652','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',650,'EXECUTED','9:8ad7ad977563799d0d20245f7c02dc3f','addForeignKeyConstraint baseTableName=diagnosis_attribute, constraintName=diagnosis_attribute_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-653','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',651,'EXECUTED','9:276bd1dff667d1c570cf140d4f551bf1','addForeignKeyConstraint baseTableName=diagnosis_attribute, constraintName=diagnosis_attribute_diagnosis_fk, referencedTableName=encounter_diagnosis','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-654','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',652,'EXECUTED','9:b2c802b8ae1df70c4078c226d04e3771','addForeignKeyConstraint baseTableName=diagnosis_attribute_type, constraintName=diagnosis_attribute_type_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-655','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',653,'EXECUTED','9:f98dddfe616f123d6882131e028d3f5c','addForeignKeyConstraint baseTableName=diagnosis_attribute_type, constraintName=diagnosis_attribute_type_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-656','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',654,'EXECUTED','9:44e42416de42860a082d639655ed22dc','addForeignKeyConstraint baseTableName=diagnosis_attribute_type, constraintName=diagnosis_attribute_type_retired_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-657','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',655,'EXECUTED','9:7cdc9e4e84d0b692f0b22e5111877cfa','addForeignKeyConstraint baseTableName=diagnosis_attribute, constraintName=diagnosis_attribute_voided_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-658','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',656,'EXECUTED','9:131d8f0f1e18d1d67f86f55368a98def','addForeignKeyConstraint baseTableName=orders, constraintName=discontinued_because, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-659','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',657,'EXECUTED','9:3ddf42195da357681b659619bfc0ba13','addForeignKeyConstraint baseTableName=drug, constraintName=dosage_form_concept, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-660','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',658,'EXECUTED','9:a7cc3b482b35e09edabe01cdca994115','addForeignKeyConstraint baseTableName=drug, constraintName=drug_changed_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-661','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',659,'EXECUTED','9:200ca1b6be25c78981cde9f1de9242e1','addForeignKeyConstraint baseTableName=drug, constraintName=drug_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-662','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',660,'EXECUTED','9:9474c5a2206bbd6fe9321695f067ae0a','addForeignKeyConstraint baseTableName=drug, constraintName=drug_dose_limit_units_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-663','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',661,'EXECUTED','9:bb1fe84d5d5d21eb049f60f640378c53','addForeignKeyConstraint baseTableName=drug_reference_map, constraintName=drug_for_drug_reference_map, referencedTableName=drug','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-664','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',662,'EXECUTED','9:a96944bc49acf503e7b4edc2a9d553a5','addForeignKeyConstraint baseTableName=drug_ingredient, constraintName=drug_ingredient_drug_id_fk, referencedTableName=drug','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-665','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',663,'EXECUTED','9:cfe767f73caf69b3277c58fc2ff825e9','addForeignKeyConstraint baseTableName=drug_ingredient, constraintName=drug_ingredient_ingredient_id_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-666','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',664,'EXECUTED','9:86edee9ad0807cca983f31c59012d060','addForeignKeyConstraint baseTableName=drug_ingredient, constraintName=drug_ingredient_units_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-667','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',665,'EXECUTED','9:4acc45a25124f8799340f705ac74b8c0','addForeignKeyConstraint baseTableName=drug_order, constraintName=drug_order_dose_units, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-668','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',666,'EXECUTED','9:191fe62cb056690b590bf85cf089bbbd','addForeignKeyConstraint baseTableName=drug_order, constraintName=drug_order_duration_units_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-669','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',667,'EXECUTED','9:8465eaf2bbaff74b5185bb57b6deac28','addForeignKeyConstraint baseTableName=drug_order, constraintName=drug_order_frequency_fk, referencedTableName=order_frequency','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-670','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',668,'EXECUTED','9:9efab37733181f6e64f8d865a143cac8','addForeignKeyConstraint baseTableName=drug_order, constraintName=drug_order_quantity_units, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-671','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',669,'EXECUTED','9:cb2e5845b9841dad33cf2f83fdeb0443','addForeignKeyConstraint baseTableName=drug_order, constraintName=drug_order_route_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-672','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',670,'EXECUTED','9:43a663284277cb95d9665d83c139e5fa','addForeignKeyConstraint baseTableName=drug_reference_map, constraintName=drug_reference_map_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-673','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',671,'EXECUTED','9:41e886ab883d538fd7ffcb8c43368842','addForeignKeyConstraint baseTableName=drug, constraintName=drug_retired_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-674','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',672,'EXECUTED','9:1aeb90f26ca770d438675bc09365384b','addForeignKeyConstraint baseTableName=encounter, constraintName=encounter_changed_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-675','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',673,'EXECUTED','9:6a7eb6965746417ea6ae7b32d68e517e','addForeignKeyConstraint baseTableName=encounter_diagnosis, constraintName=encounter_diagnosis_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-676','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',674,'EXECUTED','9:42c357770b86f6573ac5ed3556ca5a87','addForeignKeyConstraint baseTableName=encounter_diagnosis, constraintName=encounter_diagnosis_coded_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-677','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',675,'EXECUTED','9:71a162d05566d53a116f561b7f837080','addForeignKeyConstraint baseTableName=encounter_diagnosis, constraintName=encounter_diagnosis_coded_name_fk, referencedTableName=concept_name','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-678','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',676,'EXECUTED','9:e71feeb14353d890061edb92d2a1cb37','addForeignKeyConstraint baseTableName=encounter_diagnosis, constraintName=encounter_diagnosis_condition_id_fk, referencedTableName=conditions','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-679','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',677,'EXECUTED','9:108db7b544ec78b9aa28478832998d80','addForeignKeyConstraint baseTableName=encounter_diagnosis, constraintName=encounter_diagnosis_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-680','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',678,'EXECUTED','9:eb5dd85646ff2b7b572a14cecc7e173b','addForeignKeyConstraint baseTableName=encounter_diagnosis, constraintName=encounter_diagnosis_encounter_id_fk, referencedTableName=encounter','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-681','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',679,'EXECUTED','9:476a1a444ced38906c8008702ff7323f','addForeignKeyConstraint baseTableName=encounter_diagnosis, constraintName=encounter_diagnosis_patient_fk, referencedTableName=patient','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-682','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',680,'EXECUTED','9:6ba06f63d15ec14ec1558d22a7fabd86','addForeignKeyConstraint baseTableName=encounter_diagnosis, constraintName=encounter_diagnosis_voided_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-683','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',681,'EXECUTED','9:b6969def5024d831b09b0bb6ef6b8e87','addForeignKeyConstraint baseTableName=concept_proposal, constraintName=encounter_for_proposal, referencedTableName=encounter','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-684','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',682,'EXECUTED','9:38178bee6ebe396ea6ebbd9a44d8d38c','addForeignKeyConstraint baseTableName=encounter, constraintName=encounter_form, referencedTableName=form','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-685','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:27',683,'EXECUTED','9:2983bddfcdb30b0a8d2a96129b3d7730','addForeignKeyConstraint baseTableName=encounter, constraintName=encounter_ibfk_1, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-686','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',684,'EXECUTED','9:f3d7c0450da2d6b89093435cbb22dc93','addForeignKeyConstraint baseTableName=encounter_provider, constraintName=encounter_id_fk, referencedTableName=encounter','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-687','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',685,'EXECUTED','9:b4b203e5f43791a0178356f9ea8a4321','addForeignKeyConstraint baseTableName=encounter, constraintName=encounter_location, referencedTableName=location','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-688','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',686,'EXECUTED','9:96a43204006ea359847a619d3e8b0106','addForeignKeyConstraint baseTableName=note, constraintName=encounter_note, referencedTableName=encounter','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-689','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',687,'EXECUTED','9:721e3a8ba2f56e2dbfac74ff842288d6','addForeignKeyConstraint baseTableName=obs, constraintName=encounter_observations, referencedTableName=encounter','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-690','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',688,'EXECUTED','9:d3ad1e6a4eafb83c48229a86bdc8d68d','addForeignKeyConstraint baseTableName=encounter, constraintName=encounter_patient, referencedTableName=patient','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-691','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',689,'EXECUTED','9:94a404c0b405c04f3940f569b8d91d13','addForeignKeyConstraint baseTableName=encounter_provider, constraintName=encounter_provider_changed_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-692','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',690,'EXECUTED','9:f79f358bdca5bb7a8ce452675226eb1f','addForeignKeyConstraint baseTableName=encounter_provider, constraintName=encounter_provider_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-693','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',691,'EXECUTED','9:ed14086ced1f4447c7f905e39f98399d','addForeignKeyConstraint baseTableName=encounter_provider, constraintName=encounter_provider_voided_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-694','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',692,'EXECUTED','9:29c8c36ef046858949687ba3693c549a','addForeignKeyConstraint baseTableName=encounter_role, constraintName=encounter_role_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-695','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',693,'EXECUTED','9:92480d2b01f888d7a19b8515d1a66552','addForeignKeyConstraint baseTableName=encounter_role, constraintName=encounter_role_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-696','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',694,'EXECUTED','9:ddd77b1c0ffa439cb1df6cc84c95f1b6','addForeignKeyConstraint baseTableName=encounter_provider, constraintName=encounter_role_id_fk, referencedTableName=encounter_role','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-697','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',695,'EXECUTED','9:20c4027ef7f7f4e7049d03b9a0f79f4d','addForeignKeyConstraint baseTableName=encounter_role, constraintName=encounter_role_retired_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-698','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',696,'EXECUTED','9:e1a2e82b5ccd0d2006c8246789a7b072','addForeignKeyConstraint baseTableName=encounter_type, constraintName=encounter_type_changed_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-699','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',697,'EXECUTED','9:493eb86008bf8e9f235dc99ad2dc7fdb','addForeignKeyConstraint baseTableName=encounter, constraintName=encounter_type_id, referencedTableName=encounter_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-700','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',698,'EXECUTED','9:8c04f5384ba345226cbff90fce448b39','addForeignKeyConstraint baseTableName=encounter, constraintName=encounter_visit_id_fk, referencedTableName=visit','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-701','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',699,'EXECUTED','9:6a427d3a4a796678d32973c0084eb643','addForeignKeyConstraint baseTableName=drug_order, constraintName=extends_order, referencedTableName=orders','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-702','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',700,'EXECUTED','9:f36059459cddd590ba2ae5038ba617e8','addForeignKeyConstraint baseTableName=field_answer, constraintName=field_answer_concept, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-703','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',701,'EXECUTED','9:d88a5ffcb87fe7ee8b530e4cb5388a68','addForeignKeyConstraint baseTableName=form_field, constraintName=field_within_form, referencedTableName=field','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-704','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',702,'EXECUTED','9:8a0367fd8af4b5f1d17f7ebfd92f2e49','addForeignKeyConstraint baseTableName=concept_reference_range, constraintName=fk_concept_numeric_reference_range, referencedTableName=concept_numeric','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-705','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',703,'EXECUTED','9:3a1d7e1412c533e61e3b37bd521c2b11','addForeignKeyConstraint baseTableName=obs_reference_range, constraintName=fk_obs_reference_range, referencedTableName=obs','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-706','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',704,'EXECUTED','9:12f418a9c4ba36d2533df4dee57f32ba','addForeignKeyConstraint baseTableName=order_type_class_map, constraintName=fk_order_type_class_map_concept_class_concept_class_id, referencedTableName=concept_class','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-707','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',705,'EXECUTED','9:7dedf9b1caecb7a2c8edd59f853b0109','addForeignKeyConstraint baseTableName=order_type_class_map, constraintName=fk_order_type_order_type_id, referencedTableName=order_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-708','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',706,'EXECUTED','9:e66c99babaa353f776195268b3facb5b','addForeignKeyConstraint baseTableName=orders, constraintName=fk_orderer_provider, referencedTableName=provider','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-709','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',707,'EXECUTED','9:c68a6e25c93788b49f58ef5bcb1b23e4','addForeignKeyConstraint baseTableName=patient_identifier, constraintName=fk_patient_id_patient_identifier, referencedTableName=patient','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-710','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',708,'EXECUTED','9:659afdbad03a157ce1aa31e5b634f367','addForeignKeyConstraint baseTableName=form_field, constraintName=form_containing_field, referencedTableName=form','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-711','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',709,'EXECUTED','9:c59bce2c3a22033c0e88ad8dfb8bed1c','addForeignKeyConstraint baseTableName=form, constraintName=form_encounter_type, referencedTableName=encounter_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-712','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',710,'EXECUTED','9:4c459e507daeddf22a3fc432b764db50','addForeignKeyConstraint baseTableName=form_field, constraintName=form_field_hierarchy, referencedTableName=form_field','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-713','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',711,'EXECUTED','9:b9ed0d02de829ff67b35bfa0131837e2','addForeignKeyConstraint baseTableName=form_resource, constraintName=form_resource_changed_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-714','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',712,'EXECUTED','9:04b506ed7044a48830de508f9c94b949','addForeignKeyConstraint baseTableName=form_resource, constraintName=form_resource_form_fk, referencedTableName=form','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-715','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',713,'EXECUTED','9:d26c789375cceb86b7b709ea135c424c','addForeignKeyConstraint baseTableName=global_property, constraintName=global_property_changed_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-716','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',714,'EXECUTED','9:5437594a49a4dce162d9511b0ea32ffb','addForeignKeyConstraint baseTableName=global_property, constraintName=global_property_delete_privilege_fk, referencedTableName=privilege','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-717','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',715,'EXECUTED','9:79a8e4e2595c1915ee047941e6360979','addForeignKeyConstraint baseTableName=global_property, constraintName=global_property_edit_privilege_fk, referencedTableName=privilege','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-718','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',716,'EXECUTED','9:436f76b736ff53bdd347b6221099396f','addForeignKeyConstraint baseTableName=global_property, constraintName=global_property_view_privilege_fk, referencedTableName=privilege','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-719','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',717,'EXECUTED','9:9695dc209465fe028bf07f3bcf29621f','addForeignKeyConstraint baseTableName=concept_set, constraintName=has_a, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-720','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',718,'EXECUTED','9:1af54dd44c4196d90f5cc7a08f24ae72','addForeignKeyConstraint baseTableName=hl7_in_queue, constraintName=hl7_source_with_queue, referencedTableName=hl7_source','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-721','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',719,'EXECUTED','9:1e176ddf924dadc829021eecd4fd2a81','addForeignKeyConstraint baseTableName=notification_alert_recipient, constraintName=id_of_alert, referencedTableName=notification_alert','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-722','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',720,'EXECUTED','9:c1fef11484eb89bd74de4111d017dab8','addForeignKeyConstraint baseTableName=patient_identifier, constraintName=identifier_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-723','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',721,'EXECUTED','9:ba6779ebe1cae1d46b09fa8995d182a6','addForeignKeyConstraint baseTableName=patient_identifier, constraintName=identifier_voider, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-724','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',722,'EXECUTED','9:7cf658caa9cf33ee3f507d2e09cdc76e','addForeignKeyConstraint baseTableName=person_attribute, constraintName=identifies_person, referencedTableName=person','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-725','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',723,'EXECUTED','9:8560247b3e7be6e286af5b58665a8bd6','addForeignKeyConstraint baseTableName=role_role, constraintName=inherited_role, referencedTableName=role','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-726','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',724,'EXECUTED','9:eb82ce2c39ddf1fe61e276601e22be4e','addForeignKeyConstraint baseTableName=drug_order, constraintName=inventory_item, referencedTableName=drug','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-727','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',725,'EXECUTED','9:350ff03c78a71fc37fee1ddb33eb6f7b','addForeignKeyConstraint baseTableName=location_attribute, constraintName=location_attribute_attribute_type_id_fk, referencedTableName=location_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-728','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',726,'EXECUTED','9:cd4dd02af012ed75e115a0b17c297334','addForeignKeyConstraint baseTableName=location_attribute, constraintName=location_attribute_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-729','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',727,'EXECUTED','9:d9ff89c764d7e51ef3ef9e08b15df67e','addForeignKeyConstraint baseTableName=location_attribute, constraintName=location_attribute_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-730','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',728,'EXECUTED','9:eca9e0b1daf13d7afb572b78a22cc929','addForeignKeyConstraint baseTableName=location_attribute, constraintName=location_attribute_location_fk, referencedTableName=location','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-731','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',729,'EXECUTED','9:6d0fd15d82703f9074486a9027106862','addForeignKeyConstraint baseTableName=location_attribute_type, constraintName=location_attribute_type_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-732','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',730,'EXECUTED','9:e908cc2567bf06b9fe362ebe4ca29f10','addForeignKeyConstraint baseTableName=location_attribute_type, constraintName=location_attribute_type_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-733','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',731,'EXECUTED','9:7348040bdc9cf88b9d5a26f415f147c8','addForeignKeyConstraint baseTableName=location_attribute_type, constraintName=location_attribute_type_retired_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-734','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',732,'EXECUTED','9:b08dc846e0028b7c405840507a7614b9','addForeignKeyConstraint baseTableName=location_attribute, constraintName=location_attribute_voided_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-735','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',733,'EXECUTED','9:5a8ead49d7db4040a89579e99c15c23a','addForeignKeyConstraint baseTableName=location, constraintName=location_changed_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-736','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',734,'EXECUTED','9:2ee2a6c559f411bd7706b1c842af42b8','addForeignKeyConstraint baseTableName=location_tag, constraintName=location_tag_changed_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-737','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',735,'EXECUTED','9:15170d3ffbb020934d734c6ce42833d3','addForeignKeyConstraint baseTableName=location_tag, constraintName=location_tag_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-738','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',736,'EXECUTED','9:4bdbc45cab9c938d0dbde0079d60f5ea','addForeignKeyConstraint baseTableName=location_tag_map, constraintName=location_tag_map_location, referencedTableName=location','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-739','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',737,'EXECUTED','9:fb67e47e1c91e506623db2ea198f49b4','addForeignKeyConstraint baseTableName=location_tag_map, constraintName=location_tag_map_tag, referencedTableName=location_tag','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-740','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',738,'EXECUTED','9:603af7fa9d962ff441eaa15a7a1620b4','addForeignKeyConstraint baseTableName=location_tag, constraintName=location_tag_retired_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-741','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',739,'EXECUTED','9:b4795753e44c7a03c3bbdc0adaeae315','addForeignKeyConstraint baseTableName=location, constraintName=location_type_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-742','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:28',740,'EXECUTED','9:83e7f3d4a4689c8891970e3afb719f6e','addForeignKeyConstraint baseTableName=concept_reference_map, constraintName=map_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-743','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',741,'EXECUTED','9:432ce2af6b373ff23d985b93344101f9','addForeignKeyConstraint baseTableName=concept_reference_map, constraintName=map_for_concept, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-744','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',742,'EXECUTED','9:718aa27be5115a98e6c7fcadfdd6110c','addForeignKeyConstraint baseTableName=concept_reference_map, constraintName=mapped_concept_map_type, referencedTableName=concept_map_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-745','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',743,'EXECUTED','9:b10d1f8d7d5573ab62b23c09d4bfe102','addForeignKeyConstraint baseTableName=concept_reference_term_map, constraintName=mapped_concept_map_type_ref_term_map, referencedTableName=concept_map_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-746','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',744,'EXECUTED','9:a7a93bbbb82ef8964c9f86bf502e3f16','addForeignKeyConstraint baseTableName=concept_name_tag_map, constraintName=mapped_concept_name, referencedTableName=concept_name','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-747','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',745,'EXECUTED','9:ac7615347babe60cd21233a5256fca74','addForeignKeyConstraint baseTableName=concept_name_tag_map, constraintName=mapped_concept_name_tag, referencedTableName=concept_name_tag','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-748','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',746,'EXECUTED','9:320fcaa56f2c2cf328c9f076520e80ba','addForeignKeyConstraint baseTableName=concept_proposal_tag_map, constraintName=mapped_concept_proposal, referencedTableName=concept_proposal','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-749','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',747,'EXECUTED','9:f7ba7e74e560de73d51a34ff6a2bb951','addForeignKeyConstraint baseTableName=concept_proposal_tag_map, constraintName=mapped_concept_proposal_tag, referencedTableName=concept_name_tag','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-750','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',748,'EXECUTED','9:126826d37c79e9714dc58b21dc86e549','addForeignKeyConstraint baseTableName=concept_reference_map, constraintName=mapped_concept_reference_term, referencedTableName=concept_reference_term','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-751','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',749,'EXECUTED','9:e2bd9529a02eaacec31af67d2b6615fb','addForeignKeyConstraint baseTableName=concept_reference_term, constraintName=mapped_concept_source, referencedTableName=concept_reference_source','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-752','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',750,'EXECUTED','9:0cff7f7fdb8bddc7b0d68ffdf81cca3a','addForeignKeyConstraint baseTableName=concept_reference_term_map, constraintName=mapped_term_a, referencedTableName=concept_reference_term','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-753','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',751,'EXECUTED','9:d7e9d95c1ee525a183a6e40c0b122d66','addForeignKeyConstraint baseTableName=concept_reference_term_map, constraintName=mapped_term_b, referencedTableName=concept_reference_term','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-754','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',752,'EXECUTED','9:837de381a3715ab884dcd3fc0f27da37','addForeignKeyConstraint baseTableName=concept_reference_term, constraintName=mapped_user_changed, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-755','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',753,'EXECUTED','9:80470d34493a1f58b4ad62488805f414','addForeignKeyConstraint baseTableName=concept_map_type, constraintName=mapped_user_changed_concept_map_type, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-756','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',754,'EXECUTED','9:e38f056802604c10eea8e0b0b6339f6a','addForeignKeyConstraint baseTableName=concept_reference_map, constraintName=mapped_user_changed_ref_term, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-757','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',755,'EXECUTED','9:6b0d6efcbd563e949bcc964a16f19ef9','addForeignKeyConstraint baseTableName=concept_reference_term_map, constraintName=mapped_user_changed_ref_term_map, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-758','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',756,'EXECUTED','9:8ff025c9fd5cf7bc7e91ec3744f4fd65','addForeignKeyConstraint baseTableName=concept_reference_term, constraintName=mapped_user_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-759','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',757,'EXECUTED','9:fc41c02911fac025ed7d995b4ce7d399','addForeignKeyConstraint baseTableName=concept_map_type, constraintName=mapped_user_creator_concept_map_type, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-760','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',758,'EXECUTED','9:450779aeda808a9c546ff913201b6abf','addForeignKeyConstraint baseTableName=concept_reference_term_map, constraintName=mapped_user_creator_ref_term_map, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-761','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',759,'EXECUTED','9:5405f8d24b62f6bf5a06d4fa67918282','addForeignKeyConstraint baseTableName=concept_reference_term, constraintName=mapped_user_retired, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-762','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',760,'EXECUTED','9:63dbd2ef70f9977c31c95c13fb265569','addForeignKeyConstraint baseTableName=concept_map_type, constraintName=mapped_user_retired_concept_map_type, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-763','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',761,'EXECUTED','9:e05c7d54d592daccc2782637a9d02ff5','addForeignKeyConstraint baseTableName=medication_dispense, constraintName=medication_dispense_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-764','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',762,'EXECUTED','9:fe788a869a619cec6d93bab455c01d2c','addForeignKeyConstraint baseTableName=medication_dispense, constraintName=medication_dispense_concept_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-765','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',763,'EXECUTED','9:9325397d35d8d12f6eb48865219c08f2','addForeignKeyConstraint baseTableName=medication_dispense, constraintName=medication_dispense_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-766','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',764,'EXECUTED','9:b6ccc0d4532bef0c39bd24ac3b81114f','addForeignKeyConstraint baseTableName=medication_dispense, constraintName=medication_dispense_dispenser_fk, referencedTableName=provider','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-767','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',765,'EXECUTED','9:b7d12cab6c7872e26d8776ec0079c824','addForeignKeyConstraint baseTableName=medication_dispense, constraintName=medication_dispense_dose_units_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-768','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',766,'EXECUTED','9:bc1832342084e56d26d4c5e26ae2f2b8','addForeignKeyConstraint baseTableName=medication_dispense, constraintName=medication_dispense_drug_fk, referencedTableName=drug','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-769','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',767,'EXECUTED','9:a04c0a58a655c789b082e005976d39fa','addForeignKeyConstraint baseTableName=medication_dispense, constraintName=medication_dispense_drug_order_fk, referencedTableName=drug_order','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-770','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',768,'EXECUTED','9:92224496bedc7b07ec268971233b109c','addForeignKeyConstraint baseTableName=medication_dispense, constraintName=medication_dispense_encounter_fk, referencedTableName=encounter','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-771','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',769,'EXECUTED','9:4a70fa08a66fe3dfac8a2282ea54ea22','addForeignKeyConstraint baseTableName=medication_dispense, constraintName=medication_dispense_frequency_fk, referencedTableName=order_frequency','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-772','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',770,'EXECUTED','9:7f26e3e1bcba8f03cee6eb0b46818865','addForeignKeyConstraint baseTableName=medication_dispense, constraintName=medication_dispense_location_fk, referencedTableName=location','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-773','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',771,'EXECUTED','9:59b6fb9358dd6fb4ec2efd303b0b7ee3','addForeignKeyConstraint baseTableName=medication_dispense, constraintName=medication_dispense_patient_fk, referencedTableName=patient','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-774','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',772,'EXECUTED','9:aa38a9287b6f8ac3377a14776fdf0f73','addForeignKeyConstraint baseTableName=medication_dispense, constraintName=medication_dispense_quantity_units_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-775','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',773,'EXECUTED','9:f4310c096da4ad22dd3951c4cfa8288a','addForeignKeyConstraint baseTableName=medication_dispense, constraintName=medication_dispense_route_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-776','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',774,'EXECUTED','9:8cff875c1c20d6552fd0e486a68779e1','addForeignKeyConstraint baseTableName=medication_dispense, constraintName=medication_dispense_status_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-777','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',775,'EXECUTED','9:20a9c800fd0e06149093df026ef64365','addForeignKeyConstraint baseTableName=medication_dispense, constraintName=medication_dispense_status_reason_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-778','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',776,'EXECUTED','9:5777d8eac88bc38287a83594cb91da63','addForeignKeyConstraint baseTableName=medication_dispense, constraintName=medication_dispense_substitution_reason_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-779','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',777,'EXECUTED','9:7e8b0f786e94b73bd37764de5198b56f','addForeignKeyConstraint baseTableName=medication_dispense, constraintName=medication_dispense_substitution_type_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-780','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',778,'EXECUTED','9:0e782e9bde059fa32d7e2608de40d3c2','addForeignKeyConstraint baseTableName=medication_dispense, constraintName=medication_dispense_type_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-781','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',779,'EXECUTED','9:065bc50958d561a7f621256e525f5e09','addForeignKeyConstraint baseTableName=medication_dispense, constraintName=medication_dispense_voided_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-782','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',780,'EXECUTED','9:c0062a59b9414af6c82b7f923e0557aa','addForeignKeyConstraint baseTableName=cohort_member, constraintName=member_patient, referencedTableName=patient','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-783','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:29',781,'EXECUTED','9:399e0c530cfc42d96f9de98789c4df29','addForeignKeyConstraint baseTableName=concept_name, constraintName=name_for_concept, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-784','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',782,'EXECUTED','9:08e407ca6b2cdb3197f688f7c1cb236a','addForeignKeyConstraint baseTableName=person_name, constraintName=name_for_person, referencedTableName=person','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-785','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',783,'EXECUTED','9:2fbe5b5f37aa68c520c65fab93e2a8f7','addForeignKeyConstraint baseTableName=note, constraintName=note_hierarchy, referencedTableName=note','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-786','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',784,'EXECUTED','9:ef6d1fe68de7741711ca3e90f8d79988','addForeignKeyConstraint baseTableName=concept_numeric, constraintName=numeric_attributes, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-787','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',785,'EXECUTED','9:b16b146dc25bc8d9c5387de8929723a2','addForeignKeyConstraint baseTableName=obs, constraintName=obs_concept, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-788','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',786,'EXECUTED','9:28fa0238d66c5ddbdc46d7ecdf2bd438','addForeignKeyConstraint baseTableName=obs, constraintName=obs_enterer, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-789','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',787,'EXECUTED','9:f8a0d53ae7607447301634333c6736f8','addForeignKeyConstraint baseTableName=obs, constraintName=obs_grouping_id, referencedTableName=obs','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-790','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',788,'EXECUTED','9:c4570e757bc55af88ddb1e096f1d3531','addForeignKeyConstraint baseTableName=obs, constraintName=obs_location, referencedTableName=location','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-791','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',789,'EXECUTED','9:e246b45d3d47b572358757fc01e42a80','addForeignKeyConstraint baseTableName=obs, constraintName=obs_name_of_coded_value, referencedTableName=concept_name','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-792','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',790,'EXECUTED','9:db8876085b4e9edc356a7bdeb3899fda','addForeignKeyConstraint baseTableName=note, constraintName=obs_note, referencedTableName=obs','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-793','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',791,'EXECUTED','9:304c981c44c2972c62f03aa9ef914706','addForeignKeyConstraint baseTableName=obs, constraintName=obs_order, referencedTableName=orders','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-794','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',792,'EXECUTED','9:0cc51c03f79e62ecb948a4439e944797','addForeignKeyConstraint baseTableName=order_attribute, constraintName=order_attribute_attribute_type_id_fk, referencedTableName=order_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-795','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',793,'EXECUTED','9:32fd66c7925cf4278b9298d9e5b1da98','addForeignKeyConstraint baseTableName=order_attribute, constraintName=order_attribute_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-796','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',794,'EXECUTED','9:7631b32ecb1efbba0fc92c3575be92e0','addForeignKeyConstraint baseTableName=order_attribute, constraintName=order_attribute_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-797','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',795,'EXECUTED','9:c71d3629e51b068133cf9c2806085916','addForeignKeyConstraint baseTableName=order_attribute, constraintName=order_attribute_order_fk, referencedTableName=orders','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-798','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',796,'EXECUTED','9:493ea7cd91beb9b8e78d12c9b6cef379','addForeignKeyConstraint baseTableName=order_attribute_type, constraintName=order_attribute_type_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-799','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',797,'EXECUTED','9:11545cfadf0deb55ca79e44744896290','addForeignKeyConstraint baseTableName=order_attribute_type, constraintName=order_attribute_type_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-800','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',798,'EXECUTED','9:6d10ee9c81b65654922bd4a1a14c5585','addForeignKeyConstraint baseTableName=order_attribute_type, constraintName=order_attribute_type_retired_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-801','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',799,'EXECUTED','9:3498ce476c89403f7669d7e2dbf04fb6','addForeignKeyConstraint baseTableName=order_attribute, constraintName=order_attribute_voided_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-802','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',800,'EXECUTED','9:868b50c17fe1e06461a621a31a982201','addForeignKeyConstraint baseTableName=orders, constraintName=order_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-803','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',801,'EXECUTED','9:26471d3ebe02cc0f6a9b41348c1784a1','addForeignKeyConstraint baseTableName=orders, constraintName=order_for_patient, referencedTableName=patient','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-804','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',802,'EXECUTED','9:26d7475bae898ea039124337e0627284','addForeignKeyConstraint baseTableName=order_frequency, constraintName=order_frequency_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-805','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',803,'EXECUTED','9:efcd08896c722eee372ba7c790f9042b','addForeignKeyConstraint baseTableName=order_frequency, constraintName=order_frequency_concept_id_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-806','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',804,'EXECUTED','9:2e647e5c8c633e842bb1945956f821c0','addForeignKeyConstraint baseTableName=order_frequency, constraintName=order_frequency_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-807','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',805,'EXECUTED','9:e346de2c24bd703ed717b553c678d17c','addForeignKeyConstraint baseTableName=order_frequency, constraintName=order_frequency_retired_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-808','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',806,'EXECUTED','9:12e8aaa5af3632b766381cff2e4907b9','addForeignKeyConstraint baseTableName=order_group_attribute, constraintName=order_group_attribute_attribute_type_id_fk, referencedTableName=order_group_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-809','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',807,'EXECUTED','9:f7fbd7ee9de18eaf5ae07ce39b50f811','addForeignKeyConstraint baseTableName=order_group_attribute, constraintName=order_group_attribute_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-810','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',808,'EXECUTED','9:a795a36fdd4fb226a25f3c381bc38b5c','addForeignKeyConstraint baseTableName=order_group_attribute, constraintName=order_group_attribute_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-811','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',809,'EXECUTED','9:831442ebe566030197d444e2772c80c6','addForeignKeyConstraint baseTableName=order_group_attribute, constraintName=order_group_attribute_order_group_fk, referencedTableName=order_group','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-812','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',810,'EXECUTED','9:3b3271ba9058d9e3018a37ea7bc38e2b','addForeignKeyConstraint baseTableName=order_group_attribute_type, constraintName=order_group_attribute_type_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-813','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',811,'EXECUTED','9:9a349fa5ce1b9e65243918a398b087b2','addForeignKeyConstraint baseTableName=order_group_attribute_type, constraintName=order_group_attribute_type_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-814','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',812,'EXECUTED','9:f9ac94858d77c07b937f0a60ba7bb9bb','addForeignKeyConstraint baseTableName=order_group_attribute_type, constraintName=order_group_attribute_type_retired_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-815','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',813,'EXECUTED','9:7e7ed92081ccddce55736071c4df75cc','addForeignKeyConstraint baseTableName=order_group_attribute, constraintName=order_group_attribute_voided_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-816','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',814,'EXECUTED','9:5a298af4b0f56dcf25983209fd368068','addForeignKeyConstraint baseTableName=order_group, constraintName=order_group_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-817','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',815,'EXECUTED','9:392b8217e31a5045e52f6b773e6d2e10','addForeignKeyConstraint baseTableName=order_group, constraintName=order_group_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-818','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',816,'EXECUTED','9:f9ce8d160095bcef6f0e8ee6b52229ae','addForeignKeyConstraint baseTableName=order_group, constraintName=order_group_encounter_id_fk, referencedTableName=encounter','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-819','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',817,'EXECUTED','9:aff56651cec2eff63380457c924afa70','addForeignKeyConstraint baseTableName=order_group, constraintName=order_group_order_group_reason_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-820','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',818,'EXECUTED','9:2e3321ae01d6a673d65ece71e05d7843','addForeignKeyConstraint baseTableName=order_group, constraintName=order_group_parent_order_group_fk, referencedTableName=order_group','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-821','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',819,'EXECUTED','9:7825a93fae41847a1d8dba57f26885ed','addForeignKeyConstraint baseTableName=order_group, constraintName=order_group_patient_id_fk, referencedTableName=patient','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-822','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',820,'EXECUTED','9:90792aa179902bdcb01db73adb91c9d4','addForeignKeyConstraint baseTableName=order_group, constraintName=order_group_previous_order_group_fk, referencedTableName=order_group','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-823','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',821,'EXECUTED','9:6a75879945458a9e06a188e73b29d1e7','addForeignKeyConstraint baseTableName=order_group, constraintName=order_group_set_id_fk, referencedTableName=order_set','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-824','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',822,'EXECUTED','9:2c9e2f65f2ac00f4504bf98dd3829a25','addForeignKeyConstraint baseTableName=order_group, constraintName=order_group_voided_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-825','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',823,'EXECUTED','9:c2bff97899810f7679a774007ec4ee74','addForeignKeyConstraint baseTableName=order_set_attribute, constraintName=order_set_attribute_attribute_type_id_fk, referencedTableName=order_set_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-826','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',824,'EXECUTED','9:cbe97a027071b6330cee79408baa2962','addForeignKeyConstraint baseTableName=order_set_attribute, constraintName=order_set_attribute_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-827','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',825,'EXECUTED','9:bfc9af5942008d5b3c5d2039ae401eb7','addForeignKeyConstraint baseTableName=order_set_attribute, constraintName=order_set_attribute_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-828','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',826,'EXECUTED','9:68f273e77d8efce90539b0afd63fac8e','addForeignKeyConstraint baseTableName=order_set_attribute, constraintName=order_set_attribute_order_set_fk, referencedTableName=order_set','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-829','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',827,'EXECUTED','9:6ab806341dd81fef2a595e22e7d9688d','addForeignKeyConstraint baseTableName=order_set_attribute_type, constraintName=order_set_attribute_type_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-830','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',828,'EXECUTED','9:5e338f8e5b888a9dbc525acd2d96d57e','addForeignKeyConstraint baseTableName=order_set_attribute_type, constraintName=order_set_attribute_type_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-831','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',829,'EXECUTED','9:3e69f062129aa1986d5fa9d39691e61d','addForeignKeyConstraint baseTableName=order_set_attribute_type, constraintName=order_set_attribute_type_retired_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-832','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',830,'EXECUTED','9:267986239cc775268d944f3c670da407','addForeignKeyConstraint baseTableName=order_set_attribute, constraintName=order_set_attribute_voided_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-833','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:30',831,'EXECUTED','9:5389aeb836a22c26f41bdf046f71d8a4','addForeignKeyConstraint baseTableName=order_set, constraintName=order_set_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-834','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',832,'EXECUTED','9:0253f929cda5908cc268fc3a0b9b0bdf','addForeignKeyConstraint baseTableName=order_set, constraintName=order_set_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-835','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',833,'EXECUTED','9:33cdacadec882046abb835e25e88e347','addForeignKeyConstraint baseTableName=order_set_member, constraintName=order_set_member_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-836','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',834,'EXECUTED','9:2712ceb3f0d0b827b656b323d4a8c9e6','addForeignKeyConstraint baseTableName=order_set_member, constraintName=order_set_member_concept_id_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-837','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',835,'EXECUTED','9:cdec188c983739d97c14f5b092697991','addForeignKeyConstraint baseTableName=order_set_member, constraintName=order_set_member_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-838','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',836,'EXECUTED','9:4fc7f11667c69b31115c004f274cda07','addForeignKeyConstraint baseTableName=order_set_member, constraintName=order_set_member_order_set_id_fk, referencedTableName=order_set','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-839','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',837,'EXECUTED','9:5826e64383b36f3f46509067d9487a7d','addForeignKeyConstraint baseTableName=order_set_member, constraintName=order_set_member_order_type_fk, referencedTableName=order_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-840','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',838,'EXECUTED','9:a3dcaae0432bb0edb9f6688d2e29a191','addForeignKeyConstraint baseTableName=order_set_member, constraintName=order_set_member_retired_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-841','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',839,'EXECUTED','9:0df2b7cbce26bcac47469d3fdbfd37aa','addForeignKeyConstraint baseTableName=order_set, constraintName=order_set_retired_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-842','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',840,'EXECUTED','9:86da38cac99a9d1a73caba8894a422ca','addForeignKeyConstraint baseTableName=order_type, constraintName=order_type_changed_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-843','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',841,'EXECUTED','9:48fb2d232956c923757a071f7cea02a0','addForeignKeyConstraint baseTableName=order_type, constraintName=order_type_parent_order_type, referencedTableName=order_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-844','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',842,'EXECUTED','9:bdefcb52ec55229cb0f38df0f8e1e7af','addForeignKeyConstraint baseTableName=orders, constraintName=orders_care_setting, referencedTableName=care_setting','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-845','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',843,'EXECUTED','9:63226f2f80ecfad57f5e977fa345fbca','addForeignKeyConstraint baseTableName=orders, constraintName=orders_in_encounter, referencedTableName=encounter','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-846','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',844,'EXECUTED','9:b74b4c9ceda2a42e84f6ee431d651753','addForeignKeyConstraint baseTableName=orders, constraintName=orders_order_group_id_fk, referencedTableName=order_group','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-847','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',845,'EXECUTED','9:70079b88efc6f4de0535011bdb604bf2','addForeignKeyConstraint baseTableName=cohort_member, constraintName=parent_cohort, referencedTableName=cohort','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-848','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',846,'EXECUTED','9:af72ec28dc335245a6f6ed24948b3274','addForeignKeyConstraint baseTableName=location, constraintName=parent_location, referencedTableName=location','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-849','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',847,'EXECUTED','9:4d512696502223f67b3adaef70c10140','addForeignKeyConstraint baseTableName=role_role, constraintName=parent_role, referencedTableName=role','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-850','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',848,'EXECUTED','9:629a48c8fd323b24c97922f531842035','addForeignKeyConstraint baseTableName=person_address, constraintName=patient_address_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-851','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',849,'EXECUTED','9:e255d2098b59b43f3af1b8936a18c71b','addForeignKeyConstraint baseTableName=person_address, constraintName=patient_address_void, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-852','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',850,'EXECUTED','9:096d9e0f2240fb364c4a0903501c1316','addForeignKeyConstraint baseTableName=patient_identifier, constraintName=patient_identifier_changed_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-853','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',851,'EXECUTED','9:987dcc70dd79f43a5dae8f262f76a571','addForeignKeyConstraint baseTableName=patient_identifier, constraintName=patient_identifier_ibfk_2, referencedTableName=location','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-854','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',852,'EXECUTED','9:1b93410027c482dfc3f01cdfc64e9c00','addForeignKeyConstraint baseTableName=patient_identifier, constraintName=patient_identifier_program_id_fk, referencedTableName=patient_program','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-855','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',853,'EXECUTED','9:6e551fd671a8359d35b31c8c76a27d72','addForeignKeyConstraint baseTableName=patient_identifier_type, constraintName=patient_identifier_type_changed_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-856','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',854,'EXECUTED','9:3d6a1df790772d19572424fb5e40e76c','addForeignKeyConstraint baseTableName=patient_program, constraintName=patient_in_program, referencedTableName=patient','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-857','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',855,'EXECUTED','9:31e9cf52fe6f8bba01f1f25ae13d2c5a','addForeignKeyConstraint baseTableName=note, constraintName=patient_note, referencedTableName=patient','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-858','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',856,'EXECUTED','9:f81226af5bc7e48aa960f3755d1d4146','addForeignKeyConstraint baseTableName=patient_program_attribute, constraintName=patient_program_attribute_attributetype_fk, referencedTableName=program_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-859','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',857,'EXECUTED','9:8edac22bd35bd0d1905c2a404e6d4a0a','addForeignKeyConstraint baseTableName=patient_program_attribute, constraintName=patient_program_attribute_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-860','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',858,'EXECUTED','9:b7b3a12c3ee1ba254cb1e3752419ce67','addForeignKeyConstraint baseTableName=patient_program_attribute, constraintName=patient_program_attribute_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-861','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',859,'EXECUTED','9:e7ce1c9c03513b481970f55a7189b53c','addForeignKeyConstraint baseTableName=patient_program_attribute, constraintName=patient_program_attribute_programid_fk, referencedTableName=patient_program','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-862','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',860,'EXECUTED','9:0bcac39e9558282c9296c2537bc995a9','addForeignKeyConstraint baseTableName=patient_program_attribute, constraintName=patient_program_attribute_voided_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-863','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',861,'EXECUTED','9:8cc69e62eed7325e1b8b8aa46ae3cf9f','addForeignKeyConstraint baseTableName=patient_program, constraintName=patient_program_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-864','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',862,'EXECUTED','9:7d9173df0ac5e0b85c61de91f3b3c3be','addForeignKeyConstraint baseTableName=patient_state, constraintName=patient_program_for_state, referencedTableName=patient_program','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-865','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',863,'EXECUTED','9:09ae62be7415b60b64d91cd4c7726b45','addForeignKeyConstraint baseTableName=patient_program, constraintName=patient_program_location_id, referencedTableName=location','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-866','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',864,'EXECUTED','9:3f48e8b97449adce885249f0a86343cb','addForeignKeyConstraint baseTableName=patient_program, constraintName=patient_program_outcome_concept_id_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-867','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',865,'EXECUTED','9:3e700dcf811b62f78b421106d306d749','addForeignKeyConstraint baseTableName=patient_state, constraintName=patient_state_changer, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-868','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',866,'EXECUTED','9:1f43c835407880e8282feb0d241fe82b','addForeignKeyConstraint baseTableName=patient_state, constraintName=patient_state_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-869','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',867,'EXECUTED','9:8ed7e6e664bc01d0171644578a4b1424','addForeignKeyConstraint baseTableName=patient_state, constraintName=patient_state_encounter_id_fk, referencedTableName=encounter','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-870','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',868,'EXECUTED','9:dd5d8d9c204a495a5458807b2aeb3b83','addForeignKeyConstraint baseTableName=patient_state, constraintName=patient_state_voider, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-871','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',869,'EXECUTED','9:61bf586b812b6103e15c402fc92ca835','addForeignKeyConstraint baseTableName=relationship, constraintName=person_a_is_person, referencedTableName=person','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-872','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',870,'EXECUTED','9:196a8f88686082b7071bf581ca5cbca7','addForeignKeyConstraint baseTableName=person_address, constraintName=person_address_changed_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-873','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',871,'EXECUTED','9:8291c7d272cda2caf1941834e12db961','addForeignKeyConstraint baseTableName=relationship, constraintName=person_b_is_person, referencedTableName=person','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-874','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',872,'EXECUTED','9:89c57cf4b0354dd70195fe748dc88874','addForeignKeyConstraint baseTableName=person, constraintName=person_died_because, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-875','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',873,'EXECUTED','9:5eb35596dfc5fcbe94a1e87032b4a12b','addForeignKeyConstraint baseTableName=patient, constraintName=person_id_for_patient, referencedTableName=person','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-876','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',874,'EXECUTED','9:b54dd330f72e94456d67ce2ad411968e','addForeignKeyConstraint baseTableName=users, constraintName=person_id_for_user, referencedTableName=person','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-877','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',875,'EXECUTED','9:26a9e050259ca5c77f82a0654e0884d7','addForeignKeyConstraint baseTableName=person_merge_log, constraintName=person_merge_log_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-878','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',876,'EXECUTED','9:244a79b30d4c720b1dc683aeee5c42fd','addForeignKeyConstraint baseTableName=person_merge_log, constraintName=person_merge_log_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-879','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',877,'EXECUTED','9:eae3b28a6a3267b68d7ff572ff1c2410','addForeignKeyConstraint baseTableName=person_merge_log, constraintName=person_merge_log_loser, referencedTableName=person','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-880','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:31',878,'EXECUTED','9:2b27af33fe5b8e55ba5a46e39d7e22ba','addForeignKeyConstraint baseTableName=person_merge_log, constraintName=person_merge_log_voided_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-881','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',879,'EXECUTED','9:6d8bfb4d6882603c25cd4dd0f6a820eb','addForeignKeyConstraint baseTableName=person_merge_log, constraintName=person_merge_log_winner, referencedTableName=person','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-882','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',880,'EXECUTED','9:2893f469ef8af4d9a32d951382d5d4d1','addForeignKeyConstraint baseTableName=obs, constraintName=person_obs, referencedTableName=person','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-883','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',881,'EXECUTED','9:c498524d4155600e151579a57a41ab7b','addForeignKeyConstraint baseTableName=orders, constraintName=previous_order_id_order_id, referencedTableName=orders','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-884','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',882,'EXECUTED','9:4f3a53304bfb387437327940e02b4f5e','addForeignKeyConstraint baseTableName=obs, constraintName=previous_version, referencedTableName=obs','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-885','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',883,'EXECUTED','9:97be35ce3823b77fa3e7180531accc6f','addForeignKeyConstraint baseTableName=drug, constraintName=primary_drug_concept, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-886','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',884,'EXECUTED','9:78f16b6a93930ac1b878e15394f0355c','addForeignKeyConstraint baseTableName=role_privilege, constraintName=privilege_definitions, referencedTableName=privilege','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-887','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',885,'EXECUTED','9:8a91ac5fcbc1b9aca624f05adda1c0cb','addForeignKeyConstraint baseTableName=person_attribute_type, constraintName=privilege_which_can_edit, referencedTableName=privilege','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-888','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',886,'EXECUTED','9:d614db7dcd6d02447c3d73d1bd21bdc6','addForeignKeyConstraint baseTableName=encounter_type, constraintName=privilege_which_can_edit_encounter_type, referencedTableName=privilege','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-889','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',887,'EXECUTED','9:44f8a1a5513d4db4e28a295dba303662','addForeignKeyConstraint baseTableName=encounter_type, constraintName=privilege_which_can_view_encounter_type, referencedTableName=privilege','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-890','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',888,'EXECUTED','9:d5fdaaf0c008885ca9f6f9e613569234','addForeignKeyConstraint baseTableName=program_attribute_type, constraintName=program_attribute_type_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-891','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',889,'EXECUTED','9:8a66495faffd20b920efb47b45ecec35','addForeignKeyConstraint baseTableName=program_attribute_type, constraintName=program_attribute_type_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-892','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',890,'EXECUTED','9:211ff2a44a1211ec7edb38da821ca32d','addForeignKeyConstraint baseTableName=program_attribute_type, constraintName=program_attribute_type_retired_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-893','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',891,'EXECUTED','9:aed86be92711429932e68abd8d7f6a4f','addForeignKeyConstraint baseTableName=program, constraintName=program_concept, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-894','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',892,'EXECUTED','9:c82314b285a46d146d70a295add075ff','addForeignKeyConstraint baseTableName=program, constraintName=program_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-895','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',893,'EXECUTED','9:5d4ca5420858cebfc51511cb50749c1f','addForeignKeyConstraint baseTableName=patient_program, constraintName=program_for_patient, referencedTableName=program','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-896','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',894,'EXECUTED','9:74d49b55375086394e1b86a10229c828','addForeignKeyConstraint baseTableName=program_workflow, constraintName=program_for_workflow, referencedTableName=program','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-897','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',895,'EXECUTED','9:a35afc918f01f6e8fab57d3e30966237','addForeignKeyConstraint baseTableName=program, constraintName=program_outcomes_concept_id_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-898','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',896,'EXECUTED','9:2b62ce80880c8172f9236038d4c3a24b','addForeignKeyConstraint baseTableName=concept_proposal, constraintName=proposal_obs_concept_id, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-899','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',897,'EXECUTED','9:29f4596f983e2b59fa8ded0548a6b675','addForeignKeyConstraint baseTableName=concept_proposal, constraintName=proposal_obs_id, referencedTableName=obs','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-900','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',898,'EXECUTED','9:092c97595c46784c9ae0ce0ad38a231c','addForeignKeyConstraint baseTableName=provider_attribute, constraintName=provider_attribute_attribute_type_id_fk, referencedTableName=provider_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-901','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',899,'EXECUTED','9:af3bb57a5bdd8b81f4b2ca8ed4921499','addForeignKeyConstraint baseTableName=provider_attribute, constraintName=provider_attribute_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-902','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',900,'EXECUTED','9:91022d273880913f0930fa75cbb81b7d','addForeignKeyConstraint baseTableName=provider_attribute, constraintName=provider_attribute_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-903','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',901,'EXECUTED','9:010ee752cd6373559eb9d0ddaa488039','addForeignKeyConstraint baseTableName=provider_attribute, constraintName=provider_attribute_provider_fk, referencedTableName=provider','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-904','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',902,'EXECUTED','9:452fc8a681ab965622e3d404ed7ce9da','addForeignKeyConstraint baseTableName=provider_attribute_type, constraintName=provider_attribute_type_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-905','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',903,'EXECUTED','9:2bf95ad890326bd0d5caf16bacd3a597','addForeignKeyConstraint baseTableName=provider_attribute_type, constraintName=provider_attribute_type_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-906','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',904,'EXECUTED','9:2caf70812b02c6c121fc64f3e8b6596e','addForeignKeyConstraint baseTableName=provider_attribute_type, constraintName=provider_attribute_type_retired_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-907','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',905,'EXECUTED','9:c354b9be7f0e300d2acbd991eb8fc715','addForeignKeyConstraint baseTableName=provider_attribute, constraintName=provider_attribute_voided_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-908','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',906,'EXECUTED','9:c00bf45d160e66cf5acde8f172135b93','addForeignKeyConstraint baseTableName=provider, constraintName=provider_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-909','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',907,'EXECUTED','9:b37a457343d9281a23aa0c66c39cad90','addForeignKeyConstraint baseTableName=provider, constraintName=provider_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-910','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',908,'EXECUTED','9:92e9418e6d2bdad2c8114d85ec0ced9e','addForeignKeyConstraint baseTableName=encounter_provider, constraintName=provider_id_fk, referencedTableName=provider','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-911','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',909,'EXECUTED','9:3d76cd211a39f0876de023a02d69b150','addForeignKeyConstraint baseTableName=provider, constraintName=provider_person_id_fk, referencedTableName=person','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-912','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',910,'EXECUTED','9:f7192440236d6a7523b36898f599cbda','addForeignKeyConstraint baseTableName=provider, constraintName=provider_retired_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-913','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',911,'EXECUTED','9:cd91be7da0d55e1799a90c2515ce1b44','addForeignKeyConstraint baseTableName=provider, constraintName=provider_role_id_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-914','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',912,'EXECUTED','9:254b210a16237320248e11785cc1c3ee','addForeignKeyConstraint baseTableName=provider, constraintName=provider_speciality_id_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-915','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',913,'EXECUTED','9:b3234e7f412a123fcc4a5901e5e40213','addForeignKeyConstraint baseTableName=referral_order, constraintName=referral_order_frequency_fk, referencedTableName=order_frequency','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-916','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',914,'EXECUTED','9:9e91ea1614a96ae2daa43efb1e53f48c','addForeignKeyConstraint baseTableName=referral_order, constraintName=referral_order_location_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-917','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',915,'EXECUTED','9:4a29f2ecfe566e65cf338beb456b3ea3','addForeignKeyConstraint baseTableName=referral_order, constraintName=referral_order_order_id_fk, referencedTableName=orders','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-918','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',916,'EXECUTED','9:f96ea5fe24a38bed2d2c2bf687d0f7d7','addForeignKeyConstraint baseTableName=referral_order, constraintName=referral_order_specimen_source_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-919','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',917,'EXECUTED','9:ece80bd81547e2f1d2e76347a162e824','addForeignKeyConstraint baseTableName=relationship, constraintName=relation_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-920','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',918,'EXECUTED','9:30f8b2556c3e2bf23d837c1ff8c2d582','addForeignKeyConstraint baseTableName=relationship, constraintName=relation_voider, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-921','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',919,'EXECUTED','9:dcaed67a1e3766b3b6bea23fd41a9e98','addForeignKeyConstraint baseTableName=relationship, constraintName=relationship_changed_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-922','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',920,'EXECUTED','9:856bc63fffdd1b986d019b9f0310fd0e','addForeignKeyConstraint baseTableName=relationship_type, constraintName=relationship_type_changed_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-923','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',921,'EXECUTED','9:2320706ed1b06bfb7f4c9d28ebbe8994','addForeignKeyConstraint baseTableName=relationship, constraintName=relationship_type_id, referencedTableName=relationship_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-924','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',922,'EXECUTED','9:39ed06ec848162f0d99998f583f34ef3','addForeignKeyConstraint baseTableName=report_object, constraintName=report_object_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-925','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',923,'EXECUTED','9:5792723999976e14cfb4922dd14c90a6','addForeignKeyConstraint baseTableName=user_role, constraintName=role_definitions, referencedTableName=role','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-926','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',924,'EXECUTED','9:9e392cb3c5730b58bb758aaebd4f8ce5','addForeignKeyConstraint baseTableName=role_privilege, constraintName=role_privilege_to_role, referencedTableName=role','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-927','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',925,'EXECUTED','9:e41a563e6bbf0070ef60ae7d91dcb6e8','addForeignKeyConstraint baseTableName=drug, constraintName=route_concept, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-928','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',926,'EXECUTED','9:e8ce88da8a77d3fe8c7fccd5c2d9d925','addForeignKeyConstraint baseTableName=scheduler_task_config, constraintName=scheduler_changer, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-929','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',927,'EXECUTED','9:ae5077520b04cd4dd3ab2ff689fa22d0','addForeignKeyConstraint baseTableName=scheduler_task_config, constraintName=scheduler_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-930','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',928,'EXECUTED','9:e9d094c50a35119177081bebcdc05ccb','addForeignKeyConstraint baseTableName=serialized_object, constraintName=serialized_object_changed_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-931','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',929,'EXECUTED','9:a156a5f3ad0e4550a4c421da344ef100','addForeignKeyConstraint baseTableName=serialized_object, constraintName=serialized_object_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-932','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',930,'EXECUTED','9:3b630993a735310dbfb6fcd64fc2fbd0','addForeignKeyConstraint baseTableName=serialized_object, constraintName=serialized_object_retired_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-933','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',931,'EXECUTED','9:6d846224ca7ff9a9117890032f3721d8','addForeignKeyConstraint baseTableName=program_workflow_state, constraintName=state_changed_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-934','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',932,'EXECUTED','9:9f884344c7a370286427d3ac012f411e','addForeignKeyConstraint baseTableName=program_workflow_state, constraintName=state_concept, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-935','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',933,'EXECUTED','9:4ee1a57b3f7a8ebd3cd746e948839cbf','addForeignKeyConstraint baseTableName=program_workflow_state, constraintName=state_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-936','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',934,'EXECUTED','9:2fb5b99cb0cdba5df02d824e6ab71dca','addForeignKeyConstraint baseTableName=patient_state, constraintName=state_for_patient, referencedTableName=program_workflow_state','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-937','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',935,'EXECUTED','9:1520594878f66f9568c5d19fa0ff99cc','addForeignKeyConstraint baseTableName=scheduler_task_config_property, constraintName=task_config_for_property, referencedTableName=scheduler_task_config','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-938','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',936,'EXECUTED','9:b90787c42874ac1f63119ee904401867','addForeignKeyConstraint baseTableName=test_order, constraintName=test_order_frequency_fk, referencedTableName=order_frequency','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-939','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:32',937,'EXECUTED','9:bf7929d682764ce313659aa132b58025','addForeignKeyConstraint baseTableName=test_order, constraintName=test_order_location_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-940','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:33',938,'EXECUTED','9:a282ac2357bf4c5c50edf937a8f4b5ea','addForeignKeyConstraint baseTableName=test_order, constraintName=test_order_order_id_fk, referencedTableName=orders','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-941','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:33',939,'EXECUTED','9:cc1bdf5dfe4787e52d9a478fb57d4db4','addForeignKeyConstraint baseTableName=test_order, constraintName=test_order_specimen_source_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-942','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:33',940,'EXECUTED','9:40ea941e47d150161d6192d84c4322c3','addForeignKeyConstraint baseTableName=order_type, constraintName=type_created_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-943','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:33',941,'EXECUTED','9:082931b2cfb777306e66c52ddf06a1e8','addForeignKeyConstraint baseTableName=patient_identifier_type, constraintName=type_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-944','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:33',942,'EXECUTED','9:9c78312f4f5cfec662ea4216feeca0e4','addForeignKeyConstraint baseTableName=field, constraintName=type_of_field, referencedTableName=field_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-945','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:33',943,'EXECUTED','9:10225095afdf91a96e6dfb4d85898e7c','addForeignKeyConstraint baseTableName=orders, constraintName=type_of_order, referencedTableName=order_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-946','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:33',944,'EXECUTED','9:3df79a90e639652dd8b0d248079c2af7','addForeignKeyConstraint baseTableName=users, constraintName=user_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-947','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:33',945,'EXECUTED','9:27db397523cdc486d5ec1d336d8ec2c4','addForeignKeyConstraint baseTableName=user_property, constraintName=user_property_to_users, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-948','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:33',946,'EXECUTED','9:bf879bf806a3477739374c26a13eea0b','addForeignKeyConstraint baseTableName=user_role, constraintName=user_role_to_users, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-949','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:33',947,'EXECUTED','9:819d342b091d93c3d2431bf06184bdec','addForeignKeyConstraint baseTableName=patient_program, constraintName=user_who_changed, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-950','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:33',948,'EXECUTED','9:f1fc0522947c3309a31c0179095b5b48','addForeignKeyConstraint baseTableName=notification_alert, constraintName=user_who_changed_alert, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-951','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:33',949,'EXECUTED','9:1b522f938fb4effc982c428046bef062','addForeignKeyConstraint baseTableName=cohort, constraintName=user_who_changed_cohort, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-952','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:33',950,'EXECUTED','9:f435491a62dddfd0afe95b2696b50792','addForeignKeyConstraint baseTableName=concept, constraintName=user_who_changed_concept, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-953','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:33',951,'EXECUTED','9:3e71aa22405cc94f3b07102cdf1be24d','addForeignKeyConstraint baseTableName=concept_description, constraintName=user_who_changed_description, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-954','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:33',952,'EXECUTED','9:74e8b92c84c75be8f781b26b69e232e4','addForeignKeyConstraint baseTableName=drug_reference_map, constraintName=user_who_changed_drug_reference_map, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-955','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:33',953,'EXECUTED','9:f6668bd5cba8078ad8f77a700e4cbb75','addForeignKeyConstraint baseTableName=field, constraintName=user_who_changed_field, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-956','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:34',954,'EXECUTED','9:385e35d4175b1f05f3117adb6704f191','addForeignKeyConstraint baseTableName=note, constraintName=user_who_changed_note, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-957','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:34',955,'EXECUTED','9:c65cb91c3e459c08d92913e096042fc5','addForeignKeyConstraint baseTableName=patient, constraintName=user_who_changed_pat, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-958','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:34',956,'EXECUTED','9:a6d159b64e89578173dd62549ce48908','addForeignKeyConstraint baseTableName=person, constraintName=user_who_changed_person, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-959','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:34',957,'EXECUTED','9:d63a0d79445bd4290750e5dccc921dc7','addForeignKeyConstraint baseTableName=program, constraintName=user_who_changed_program, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-960','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:34',958,'EXECUTED','9:1a3ece478698c7a6f0374459a829f636','addForeignKeyConstraint baseTableName=concept_proposal, constraintName=user_who_changed_proposal, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-961','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:34',959,'EXECUTED','9:b7ebd5217475957f1bb86c084bbfe356','addForeignKeyConstraint baseTableName=report_object, constraintName=user_who_changed_report_object, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-962','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:34',960,'EXECUTED','9:144fddff16c321901177d2883114903a','addForeignKeyConstraint baseTableName=users, constraintName=user_who_changed_user, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-963','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:34',961,'EXECUTED','9:0bfdd12c38672f62b9169d5a6f830c47','addForeignKeyConstraint baseTableName=concept_set, constraintName=user_who_created, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-964','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:34',962,'EXECUTED','9:8878fd12bf77f5f8c15407d9fa5844db','addForeignKeyConstraint baseTableName=concept_description, constraintName=user_who_created_description, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-965','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:34',963,'EXECUTED','9:c8c152806c65178f850b6351ab86618d','addForeignKeyConstraint baseTableName=field, constraintName=user_who_created_field, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-966','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:34',964,'EXECUTED','9:1108d9ddc4b140838fdb6757bad33c56','addForeignKeyConstraint baseTableName=field_answer, constraintName=user_who_created_field_answer, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-967','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:34',965,'EXECUTED','9:cb606a7e7a4a69c8cd0976ae72e01a25','addForeignKeyConstraint baseTableName=field_type, constraintName=user_who_created_field_type, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-968','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:34',966,'EXECUTED','9:a0f4f7b29f607d179219a52847a598a0','addForeignKeyConstraint baseTableName=form, constraintName=user_who_created_form, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-969','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:34',967,'EXECUTED','9:1f51b4fb689cf34c92c8e707c6951433','addForeignKeyConstraint baseTableName=form_field, constraintName=user_who_created_form_field, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-970','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:35',968,'EXECUTED','9:2a3c1deba38383f954d6bf8d11152cfa','addForeignKeyConstraint baseTableName=hl7_source, constraintName=user_who_created_hl7_source, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-971','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:35',969,'EXECUTED','9:060e9440d2578ff3a8880b45d523b54d','addForeignKeyConstraint baseTableName=location, constraintName=user_who_created_location, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-972','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:35',970,'EXECUTED','9:80ddb9c487444631c9a3ae1519da4638','addForeignKeyConstraint baseTableName=concept_name, constraintName=user_who_created_name, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-973','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:35',971,'EXECUTED','9:9aa6d39f73632173a55687118c4963ed','addForeignKeyConstraint baseTableName=note, constraintName=user_who_created_note, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-974','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:35',972,'EXECUTED','9:11fe1ee8c1234cea6b714c88639d841b','addForeignKeyConstraint baseTableName=patient, constraintName=user_who_created_patient, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-975','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:35',973,'EXECUTED','9:df4f8d5b3ab74367a7ceec7d6cb28514','addForeignKeyConstraint baseTableName=person, constraintName=user_who_created_person, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-976','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:35',974,'EXECUTED','9:4cc3493b678c8a797771f089c763b132','addForeignKeyConstraint baseTableName=concept_proposal, constraintName=user_who_created_proposal, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-977','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:35',975,'EXECUTED','9:b6de5c1ac3a0353081264990921bd787','addForeignKeyConstraint baseTableName=relationship_type, constraintName=user_who_created_rel, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-978','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:35',976,'EXECUTED','9:15d886f00115fab050ab1c76dc363f1a','addForeignKeyConstraint baseTableName=encounter_type, constraintName=user_who_created_type, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-979','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:35',977,'EXECUTED','9:9258318cbf6824874db06c29514718c7','addForeignKeyConstraint baseTableName=form, constraintName=user_who_last_changed_form, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-980','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:35',978,'EXECUTED','9:2cf3732cbba036a4239bc7f1510299f3','addForeignKeyConstraint baseTableName=form_field, constraintName=user_who_last_changed_form_field, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-981','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:35',979,'EXECUTED','9:a1748c5fa9dba00637d02181cb2bc889','addForeignKeyConstraint baseTableName=person_name, constraintName=user_who_made_name, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-982','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:35',980,'EXECUTED','9:37428862cc9755fe595d955df0b6f703','addForeignKeyConstraint baseTableName=concept, constraintName=user_who_retired_concept, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-983','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:35',981,'EXECUTED','9:dde95cd99e683023487d585807cc50ef','addForeignKeyConstraint baseTableName=concept_class, constraintName=user_who_retired_concept_class, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-984','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:35',982,'EXECUTED','9:7edc9c951a2faaf23a96555d2b7dcb93','addForeignKeyConstraint baseTableName=concept_datatype, constraintName=user_who_retired_concept_datatype, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-985','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:35',983,'EXECUTED','9:01afa3e71878bbc1fc53bc12d7b82ca6','addForeignKeyConstraint baseTableName=concept_reference_source, constraintName=user_who_retired_concept_source, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-986','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:36',984,'EXECUTED','9:7d4706b1ae47bd8f8f4005a01d503b9b','addForeignKeyConstraint baseTableName=drug_reference_map, constraintName=user_who_retired_drug_reference_map, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-987','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:36',985,'EXECUTED','9:1fb7409639c0cfb6b8d3e7a6d94f66ed','addForeignKeyConstraint baseTableName=encounter_type, constraintName=user_who_retired_encounter_type, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-988','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:36',986,'EXECUTED','9:10c97940279a5c7b494d66f0353404c8','addForeignKeyConstraint baseTableName=field, constraintName=user_who_retired_field, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-989','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:36',987,'EXECUTED','9:dd32e3d03d665dd0d1b7f616f543516d','addForeignKeyConstraint baseTableName=form, constraintName=user_who_retired_form, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-990','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:36',988,'EXECUTED','9:4474d2e7fe997002ea8ff884fe0ecb6a','addForeignKeyConstraint baseTableName=location, constraintName=user_who_retired_location, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-991','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:36',989,'EXECUTED','9:0c4a138741cbd4da36885d38e264019d','addForeignKeyConstraint baseTableName=order_type, constraintName=user_who_retired_order_type, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-992','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:36',990,'EXECUTED','9:d7dec4230d24361c101a5331434ac22c','addForeignKeyConstraint baseTableName=patient_identifier_type, constraintName=user_who_retired_patient_identifier_type, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-993','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:36',991,'EXECUTED','9:70705908559b0f2f0d8ff28a1a3f1a04','addForeignKeyConstraint baseTableName=person_attribute_type, constraintName=user_who_retired_person_attribute_type, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-994','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:36',992,'EXECUTED','9:e54184804549ab53a2bdbaea3a6c1ff7','addForeignKeyConstraint baseTableName=relationship_type, constraintName=user_who_retired_relationship_type, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-995','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:36',993,'EXECUTED','9:163b86598cf590eb67e2ee24124ce33e','addForeignKeyConstraint baseTableName=users, constraintName=user_who_retired_this_user, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-996','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:36',994,'EXECUTED','9:f0027ae9776d4972db22fa466760e5d5','addForeignKeyConstraint baseTableName=cohort, constraintName=user_who_voided_cohort, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-997','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:36',995,'EXECUTED','9:90dc4e7b29d0733678ad1bd2a413c909','addForeignKeyConstraint baseTableName=encounter, constraintName=user_who_voided_encounter, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-998','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:36',996,'EXECUTED','9:c71a95954861059ad8e83f856c22c448','addForeignKeyConstraint baseTableName=person_name, constraintName=user_who_voided_name, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-999','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:36',997,'EXECUTED','9:684b22fabeef520a7ccab4f2f35c5e97','addForeignKeyConstraint baseTableName=obs, constraintName=user_who_voided_obs, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1000','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:36',998,'EXECUTED','9:f85126da4b7a428670501b83681fa077','addForeignKeyConstraint baseTableName=orders, constraintName=user_who_voided_order, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1001','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:36',999,'EXECUTED','9:61b213fd515199ca2e7b5d4ed737ad39','addForeignKeyConstraint baseTableName=patient, constraintName=user_who_voided_patient, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1002','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:36',1000,'EXECUTED','9:bc0fcc6dfa938dc3ac65f2300217953c','addForeignKeyConstraint baseTableName=patient_program, constraintName=user_who_voided_patient_program, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1003','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:36',1001,'EXECUTED','9:426078ddab9ddec2bf719ae14bf49527','addForeignKeyConstraint baseTableName=person, constraintName=user_who_voided_person, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1004','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:36',1002,'EXECUTED','9:4fec692763923ee9587d15295d6196fd','addForeignKeyConstraint baseTableName=report_object, constraintName=user_who_voided_report_object, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1005','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:36',1003,'EXECUTED','9:4605c7241783645f77365306763e3abf','addForeignKeyConstraint baseTableName=concept_name, constraintName=user_who_voided_this_name, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1006','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:36',1004,'EXECUTED','9:4c81b9ab71d6b216d15d93a8102cb2b2','addForeignKeyConstraint baseTableName=visit_attribute, constraintName=visit_attribute_attribute_type_id_fk, referencedTableName=visit_attribute_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1007','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:36',1005,'EXECUTED','9:be6ef05ac4b73fb61a109c9b1298d707','addForeignKeyConstraint baseTableName=visit_attribute, constraintName=visit_attribute_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1008','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:36',1006,'EXECUTED','9:09ed7119f43828abf2615f2a98ff2f0c','addForeignKeyConstraint baseTableName=visit_attribute, constraintName=visit_attribute_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1009','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:37',1007,'EXECUTED','9:9d58564a9faf37584be50b375b0c517e','addForeignKeyConstraint baseTableName=visit_attribute_type, constraintName=visit_attribute_type_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1010','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:37',1008,'EXECUTED','9:2a9c08dea3aaeab8c7f7e999a59a825f','addForeignKeyConstraint baseTableName=visit_attribute_type, constraintName=visit_attribute_type_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1011','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:37',1009,'EXECUTED','9:e615d4224ab73d6b75496181ed47ed82','addForeignKeyConstraint baseTableName=visit_attribute_type, constraintName=visit_attribute_type_retired_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1012','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:37',1010,'EXECUTED','9:8339423533ff428d91a4e95a92e71301','addForeignKeyConstraint baseTableName=visit_attribute, constraintName=visit_attribute_visit_fk, referencedTableName=visit','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1013','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:37',1011,'EXECUTED','9:851884f37221f9c966ad6f10920c44fe','addForeignKeyConstraint baseTableName=visit_attribute, constraintName=visit_attribute_voided_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1014','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:37',1012,'EXECUTED','9:c7e920386564ee379b600131b7f4417e','addForeignKeyConstraint baseTableName=visit, constraintName=visit_changed_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1015','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:37',1013,'EXECUTED','9:3045caa1009f116c2d26831211bad452','addForeignKeyConstraint baseTableName=visit, constraintName=visit_creator_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1016','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:37',1014,'EXECUTED','9:3ced9bb4d6e784c88d88090c55f8368a','addForeignKeyConstraint baseTableName=visit, constraintName=visit_indication_concept_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1017','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:37',1015,'EXECUTED','9:7b9aaccc3040f9640b37e7dc45cac2fd','addForeignKeyConstraint baseTableName=visit, constraintName=visit_location_fk, referencedTableName=location','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1018','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:37',1016,'EXECUTED','9:8cd540263f009b633772fc334e43bae1','addForeignKeyConstraint baseTableName=visit, constraintName=visit_patient_fk, referencedTableName=patient','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1019','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:37',1017,'EXECUTED','9:b1bf16ab712062238da5004cb29cc038','addForeignKeyConstraint baseTableName=visit_type, constraintName=visit_type_changed_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1020','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:37',1018,'EXECUTED','9:a5a7576862849e2888afcc14ab11bd85','addForeignKeyConstraint baseTableName=visit_type, constraintName=visit_type_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1021','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:37',1019,'EXECUTED','9:b1c1177fd6f6998e7ad26a9b68c2d397','addForeignKeyConstraint baseTableName=visit, constraintName=visit_type_fk, referencedTableName=visit_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1022','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:37',1020,'EXECUTED','9:2b4b46341e441210afa72ca7a17eaf48','addForeignKeyConstraint baseTableName=visit_type, constraintName=visit_type_retired_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1023','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:37',1021,'EXECUTED','9:3131114e61bd0434a1d35924433b90bd','addForeignKeyConstraint baseTableName=visit, constraintName=visit_voided_by_fk, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1024','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:37',1022,'EXECUTED','9:8d32ba48d3f675e951d2214546c61b79','addForeignKeyConstraint baseTableName=program_workflow, constraintName=workflow_changed_by, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1025','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:37',1023,'EXECUTED','9:107db5843883b0f3cbd680491422e704','addForeignKeyConstraint baseTableName=program_workflow, constraintName=workflow_concept, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1026','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:37',1024,'EXECUTED','9:a8d65b596c67706afe34f05131a87e70','addForeignKeyConstraint baseTableName=program_workflow, constraintName=workflow_creator, referencedTableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466200030-1027','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/schema-only/liquibase-schema-only-2.7.x.xml','2025-05-15 15:43:37',1025,'EXECUTED','9:9b26a93701512fa4c004ad3f59372bc4','addForeignKeyConstraint baseTableName=program_workflow_state, constraintName=workflow_for_state, referencedTableName=program_workflow','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466205145-17','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/core-data/liquibase-core-data-2.7.x.xml','2025-05-15 15:43:37',1026,'EXECUTED','9:91337ee665a72c40a7cb1e78f3132758','insert tableName=person','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466205145-27','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/core-data/liquibase-core-data-2.7.x.xml','2025-05-15 15:43:37',1027,'EXECUTED','9:bbd223ddad88760a4020f95fbaab1092','insert tableName=users; insert tableName=users','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466205145-1','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/core-data/liquibase-core-data-2.7.x.xml','2025-05-15 15:43:37',1028,'EXECUTED','9:75c2bc185f07cbf784a97deb257fc3f8','insert tableName=care_setting; insert tableName=care_setting','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466205145-3','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/core-data/liquibase-core-data-2.7.x.xml','2025-05-15 15:43:37',1029,'EXECUTED','9:90bc35b65f2e795637ebaedf046d7682','insert tableName=concept_class; insert tableName=concept_class; insert tableName=concept_class; insert tableName=concept_class; insert tableName=concept_class; insert tableName=concept_class; insert tableName=concept_class; insert tableName=concep...','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466205145-4','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/core-data/liquibase-core-data-2.7.x.xml','2025-05-15 15:43:37',1030,'EXECUTED','9:58653aec090087a790bd608a5db1792f','insert tableName=concept_datatype; insert tableName=concept_datatype; insert tableName=concept_datatype; insert tableName=concept_datatype; insert tableName=concept_datatype; insert tableName=concept_datatype; insert tableName=concept_datatype; in...','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466205145-2','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/core-data/liquibase-core-data-2.7.x.xml','2025-05-15 15:43:37',1031,'EXECUTED','9:bb5c4e84f55951d0c480cb17e587752c','insert tableName=concept; insert tableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466205145-5','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/core-data/liquibase-core-data-2.7.x.xml','2025-05-15 15:43:37',1032,'EXECUTED','9:4c7158897365e2977721bbeaaf43294d','insert tableName=concept_map_type; insert tableName=concept_map_type; insert tableName=concept_map_type; insert tableName=concept_map_type; insert tableName=concept_map_type; insert tableName=concept_map_type; insert tableName=concept_map_type; in...','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466205145-6','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/core-data/liquibase-core-data-2.7.x.xml','2025-05-15 15:43:37',1033,'EXECUTED','9:16120de277b14815df57d950e5b3ff38','insert tableName=concept_name; insert tableName=concept_name; insert tableName=concept_name; insert tableName=concept_name; insert tableName=concept_name; insert tableName=concept_name; insert tableName=concept_name; insert tableName=concept_name;...','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466205145-7','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/core-data/liquibase-core-data-2.7.x.xml','2025-05-15 15:43:37',1034,'EXECUTED','9:1afdba553cc8d0a7835722c33a46e721','insert tableName=concept_stop_word; insert tableName=concept_stop_word; insert tableName=concept_stop_word; insert tableName=concept_stop_word; insert tableName=concept_stop_word; insert tableName=concept_stop_word; insert tableName=concept_stop_w...','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466205145-8','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/core-data/liquibase-core-data-2.7.x.xml','2025-05-15 15:43:37',1035,'EXECUTED','9:6f2b62d1e91baa5fe1d45dca5f970544','insert tableName=encounter_role','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466205145-9','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/core-data/liquibase-core-data-2.7.x.xml','2025-05-15 15:43:37',1036,'EXECUTED','9:fd45f370f47c1fd03a84df45d0aa1995','insert tableName=field_type; insert tableName=field_type; insert tableName=field_type; insert tableName=field_type; insert tableName=field_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466205145-10','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/core-data/liquibase-core-data-2.7.x.xml','2025-05-15 15:43:37',1037,'EXECUTED','9:56ef66adab513665a6bb63bbdd139ce1','insert tableName=global_property; insert tableName=global_property; insert tableName=global_property; insert tableName=global_property; insert tableName=global_property; insert tableName=global_property; insert tableName=global_property; insert ta...','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466205145-11','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/core-data/liquibase-core-data-2.7.x.xml','2025-05-15 15:43:37',1038,'EXECUTED','9:2e7aa990318090f71043e5a462280a06','insert tableName=hl7_source','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466205145-14','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/core-data/liquibase-core-data-2.7.x.xml','2025-05-15 15:43:37',1039,'EXECUTED','9:c194d886f87f3625b322c986923012c2','insert tableName=location','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466205145-15','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/core-data/liquibase-core-data-2.7.x.xml','2025-05-15 15:43:37',1040,'EXECUTED','9:f7a6d6c80d69a1951a67267b037eabd6','insert tableName=order_type; insert tableName=order_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466205145-16','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/core-data/liquibase-core-data-2.7.x.xml','2025-05-15 15:43:37',1041,'EXECUTED','9:0245c2da51e5e635d437a68d077b06d6','insert tableName=patient_identifier_type; insert tableName=patient_identifier_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466205145-18','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/core-data/liquibase-core-data-2.7.x.xml','2025-05-15 15:43:37',1042,'EXECUTED','9:726717da4ab0e410377418c8023891c9','insert tableName=person_attribute_type; insert tableName=person_attribute_type; insert tableName=person_attribute_type; insert tableName=person_attribute_type; insert tableName=person_attribute_type; insert tableName=person_attribute_type; insert ...','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466205145-19','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/core-data/liquibase-core-data-2.7.x.xml','2025-05-15 15:43:37',1043,'EXECUTED','9:1ef7d14470369ed40c12e61e7ee8174c','insert tableName=person_name','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466205145-20','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/core-data/liquibase-core-data-2.7.x.xml','2025-05-15 15:43:37',1044,'EXECUTED','9:6fe3461faae9f63a905424128c962218','insert tableName=privilege; insert tableName=privilege; insert tableName=privilege; insert tableName=privilege; insert tableName=privilege; insert tableName=privilege; insert tableName=privilege; insert tableName=privilege; insert tableName=privil...','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466205145-21','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/core-data/liquibase-core-data-2.7.x.xml','2025-05-15 15:43:37',1045,'EXECUTED','9:4547a60c60f73d437bc0fd0213004854','insert tableName=relationship_type; insert tableName=relationship_type; insert tableName=relationship_type; insert tableName=relationship_type','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466205145-22','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/core-data/liquibase-core-data-2.7.x.xml','2025-05-15 15:43:37',1046,'EXECUTED','9:8185596dd14577a3bbf31e5d84f898f1','insert tableName=role; insert tableName=role; insert tableName=role; insert tableName=role','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466205145-23','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/core-data/liquibase-core-data-2.7.x.xml','2025-05-15 15:43:37',1047,'EXECUTED','9:acd0fd853b1f948cebabfdf390805fb7','insert tableName=role_privilege; insert tableName=role_privilege; insert tableName=role_privilege; insert tableName=role_privilege; insert tableName=role_privilege; insert tableName=role_privilege; insert tableName=role_privilege; insert tableName...','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466205145-24','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/core-data/liquibase-core-data-2.7.x.xml','2025-05-15 15:43:37',1048,'EXECUTED','9:6f64b23540e9b7639340bfd00f5690fa','insert tableName=scheduler_task_config','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466205145-25','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/core-data/liquibase-core-data-2.7.x.xml','2025-05-15 15:43:37',1049,'EXECUTED','9:5505bd316403662ef2ddfb7d8d46cfcc','insert tableName=user_property; insert tableName=user_property; insert tableName=user_property; insert tableName=user_property','',NULL,'4.31.1',NULL,NULL,'7312998417'),('1740466205145-26','Wikum Weerakutti (generated)','org/openmrs/liquibase/snapshots/core-data/liquibase-core-data-2.7.x.xml','2025-05-15 15:43:37',1050,'EXECUTED','9:5c44ca951b9fbd5fb8e53661300ad913','insert tableName=user_role; insert tableName=user_role','',NULL,'4.31.1',NULL,NULL,'7312998417'),('42ddb873-f064-4418-a6c0-6c09426c4832','wschlegel','org/openmrs/liquibase/updates/liquibase-update-to-latest-2.8.x.xml','2025-05-15 15:43:38',1051,'EXECUTED','9:d41d8cd98f00b204e9800998ecf8427e','empty','Empty change set for integration tests.',NULL,'4.31.1',NULL,NULL,'7312998417'),('add_fhir_concept_source_20200105','ibacher','liquibase.xml','2025-05-15 15:43:51',1052,'EXECUTED','9:5e85980db8058f735fe0d5d1ed4ae12d','createTable tableName=fhir_concept_source; addForeignKeyConstraint baseTableName=fhir_concept_source, constraintName=fhir_concept_source_concept_reference_source_fk, referencedTableName=concept_reference_source; addForeignKeyConstraint baseTableNa...','',NULL,'4.31.1',NULL,NULL,'7312998417'),('add_loinc_fhir_concept_source_20200221','ibacher','liquibase.xml','2025-05-15 15:43:51',1053,'EXECUTED','9:94265991ceb67c7ccd0852727e9565b3','sql','',NULL,'4.31.1',NULL,NULL,'7312998417'),('add_ciel_fhir_concept_source_20200221','ibacher','liquibase.xml','2025-05-15 15:43:51',1054,'EXECUTED','9:45cee219c21cb2c03709a4bf9b40ac5c','sql','',NULL,'4.31.1',NULL,NULL,'7312998417'),('change_ciel_url_fhir_concept_source_20200820','ibacher','liquibase.xml','2025-05-15 15:43:51',1055,'EXECUTED','9:b6fe57c255a6f5a5c069122aba13adef','sql','',NULL,'4.31.1',NULL,NULL,'7312998417'),('add_fhir_task_20200311','pmanko','liquibase.xml','2025-05-15 15:43:51',1056,'EXECUTED','9:1010d9e2f268cc47ce077377d852cf16','createTable tableName=fhir_task; addForeignKeyConstraint baseTableName=fhir_task, constraintName=task_creator, referencedTableName=users; addForeignKeyConstraint baseTableName=fhir_task, constraintName=task_changed_by, referencedTableName=users; a...','Create Task table for the Task FHIR resource',NULL,'4.31.1',NULL,NULL,'7312998417'),('add_fhir_reference_20200311','pmanko','liquibase.xml','2025-05-15 15:43:51',1057,'EXECUTED','9:c1e04909b433f5b61f607a80110c8678','createTable tableName=fhir_reference; addForeignKeyConstraint baseTableName=fhir_reference, constraintName=fhir_reference_creator_fk, referencedTableName=users; addForeignKeyConstraint baseTableName=fhir_reference, constraintName=fhir_reference_ch...','',NULL,'4.31.1',NULL,NULL,'7312998417'),('add_based_on_reference_join_table_20200311','pmanko','liquibase.xml','2025-05-15 15:43:51',1058,'EXECUTED','9:87370a97f776069e24bb668164d84b90','createTable tableName=fhir_task_based_on_reference; addForeignKeyConstraint baseTableName=fhir_task_based_on_reference, constraintName=task_based_on_fk, referencedTableName=fhir_task; addForeignKeyConstraint baseTableName=fhir_task_based_on_refere...','',NULL,'4.31.1',NULL,NULL,'7312998417'),('add_fhir_task_output_20200311','pmanko','liquibase.xml','2025-05-15 15:43:51',1059,'EXECUTED','9:bb7106ba6d0dccb1019b8905c679e5a8','createTable tableName=fhir_task_output; addForeignKeyConstraint baseTableName=fhir_task_output, constraintName=fhir_task_output_creator_fk, referencedTableName=users; addForeignKeyConstraint baseTableName=fhir_task_output, constraintName=fhir_task...','',NULL,'4.31.1',NULL,NULL,'7312998417'),('add_fhir_task_input_20200308','pmanko','liquibase.xml','2025-05-15 15:43:51',1060,'EXECUTED','9:5bc2509f1e739f6c0ecd60609a477f1b','createTable tableName=fhir_task_input; addForeignKeyConstraint baseTableName=fhir_task_input, constraintName=fhir_task_input_creator_fk, referencedTableName=users; addForeignKeyConstraint baseTableName=fhir_task_input, constraintName=fhir_task_inp...','',NULL,'4.31.1',NULL,NULL,'7312998417'),('add_target_uuid_to_fhir_reference_202020917','ibacher','liquibase.xml','2025-05-15 15:43:51',1061,'EXECUTED','9:ea7ce75dd63c4ca6649b45ed6b10610a','addColumn tableName=fhir_reference; sql','',NULL,'4.31.1',NULL,NULL,'7312998417'),('add_fhir_diagnostic_report_20200917','ibacher','liquibase.xml','2025-05-15 15:43:51',1062,'EXECUTED','9:41fe3a98d853ef3ffa30b1edebafb330','createTable tableName=fhir_diagnostic_report; addForeignKeyConstraint baseTableName=fhir_diagnostic_report, constraintName=fhir_diagnostic_report_creator, referencedTableName=users; addForeignKeyConstraint baseTableName=fhir_diagnostic_report, con...','Create the table for storing Diagnostic Reports',NULL,'4.31.1',NULL,NULL,'7312998417'),('add_fhir_diagnostic_report_performers_20200917','ibacher','liquibase.xml','2025-05-15 15:43:51',1063,'EXECUTED','9:37a328004e0a1622edc8488769d83601','createTable tableName=fhir_diagnostic_report_performers; addForeignKeyConstraint baseTableName=fhir_diagnostic_report_performers, constraintName=fhir_diagnostic_report_performers_diagnostic_report, referencedTableName=fhir_diagnostic_report; addFo...','',NULL,'4.31.1',NULL,NULL,'7312998417'),('add_fhir_diagnostic_report_results_20201020','ibacher','liquibase.xml','2025-05-15 15:43:51',1064,'EXECUTED','9:3505434a703073fddee94fa4dd393d63','createTable tableName=fhir_diagnostic_report_results; addForeignKeyConstraint baseTableName=fhir_diagnostic_report_results, constraintName=fhir_diagnostic_report_results_diagnostic_report, referencedTableName=fhir_diagnostic_report; addForeignKeyC...','',NULL,'4.31.1',NULL,NULL,'7312998417'),('add_fhir_encounter_class_map_20200930','ibacher','liquibase.xml','2025-05-15 15:43:51',1065,'EXECUTED','9:306385ab621e9344db08629ff7822038','createTable tableName=fhir_encounter_class_map; addForeignKeyConstraint baseTableName=fhir_encounter_class_map, constraintName=fhir_encounter_class_map_creator, referencedTableName=users; addForeignKeyConstraint baseTableName=fhir_encounter_class_...','',NULL,'4.31.1',NULL,NULL,'7312998417'),('add_fhir_observation_category_map_20200930','ibacher','liquibase.xml','2025-05-15 15:43:51',1066,'EXECUTED','9:724b74d316210a1d32d9dbd90cbb54c9','createTable tableName=fhir_observation_category_map; addForeignKeyConstraint baseTableName=fhir_observation_category_map, constraintName=fhir_observation_category_map_creator, referencedTableName=users; addForeignKeyConstraint baseTableName=fhir_o...','',NULL,'4.31.1',NULL,NULL,'7312998417'),('add_default_observation_categories_20200930','ibacher','liquibase.xml','2025-05-15 15:43:51',1067,'EXECUTED','9:1b44ad2b76442c2ddabae4fddf3bafa5','sql; sql; sql','',NULL,'4.31.1',NULL,NULL,'7312998417'),('add_fhir_duration_unit_map_20200930','ibacher','liquibase.xml','2025-05-15 15:43:52',1068,'EXECUTED','9:e04f54e6aadefd7d5ff2f05591c11756','createTable tableName=fhir_duration_unit_map; addForeignKeyConstraint baseTableName=fhir_duration_unit_map, constraintName=fhir_duration_unit_map_creator, referencedTableName=users; addForeignKeyConstraint baseTableName=fhir_duration_unit_map, con...','',NULL,'4.31.1',NULL,NULL,'7312998417'),('add_default_duration_unit_20200930','ibacher','liquibase.xml','2025-05-15 15:43:52',1069,'EXECUTED','9:a33dee22c7b73447448973ba5f547496','sql; sql; sql; sql; sql; sql; sql','',NULL,'4.31.1',NULL,NULL,'7312998417'),('add_fhir_patient_identifier_system_20210507','Medhavi','liquibase.xml','2025-05-15 15:43:52',1070,'EXECUTED','9:39742e49f31ebfda26b4fab33438cf74','createTable tableName=fhir_patient_identifier_system; addForeignKeyConstraint baseTableName=fhir_patient_identifier_system, constraintName=fhir_patient_identifier_system_patient_identifier_type_fk, referencedTableName=patient_identifier_type; addF...','',NULL,'4.31.1',NULL,NULL,'7312998417'),('fix_target_uuid_column','moses_mutesa','liquibase.xml','2025-05-15 15:43:52',1071,'EXECUTED','9:9a3678da1b2e83fcfb3de679673511b4','modifyDataType columnName=target_uuid, tableName=fhir_reference; dropUniqueConstraint constraintName=target_uuid, tableName=fhir_reference','',NULL,'4.31.1',NULL,NULL,'7312998417'),('drop_fhir_duration_unit_map_20220412','mseaton','liquibase.xml','2025-05-15 15:43:52',1072,'EXECUTED','9:09bd2bbd65f235168c38d05adfdf2b13','dropTable tableName=fhir_duration_unit_map','',NULL,'4.31.1',NULL,NULL,'7312998417'),('update_fhir_diagnostic_report_table_20220511','moses_mutesa','liquibase.xml','2025-05-15 15:43:52',1073,'EXECUTED','9:a3855b8182ebb3fb1ecaf817fd97a692','addColumn tableName=fhir_diagnostic_report; dropColumn columnName=name, tableName=fhir_diagnostic_report','',NULL,'4.31.1',NULL,NULL,'7312998417'),('add_task_location_reference_20221121','moses_mutesa','liquibase.xml','2025-05-15 15:43:52',1074,'EXECUTED','9:ab8721edec11fcb0c15767cefbf89558','addColumn tableName=fhir_task; addForeignKeyConstraint baseTableName=fhir_task, constraintName=task_location_reference_fk, referencedTableName=fhir_reference','',NULL,'4.31.1',NULL,NULL,'7312998417'),('add_fhir_contact_point_map_20230730','mherman22','liquibase.xml','2025-05-15 15:43:52',1075,'EXECUTED','9:edbff8f1910f8c24d1171906f92a7126','createTable tableName=fhir_contact_point_map; addForeignKeyConstraint baseTableName=fhir_contact_point_map, constraintName=fhir_contact_point_map_creator_fk, referencedTableName=users; addForeignKeyConstraint baseTableName=fhir_contact_point_map, ...','',NULL,'4.31.1',NULL,NULL,'7312998417'),('alter_fhir_task_20230903','r.kalai','liquibase.xml','2025-05-15 15:43:52',1076,'EXECUTED','9:9c259cbb574d33afe954bed9934d58cf','addColumn tableName=fhir_task; addForeignKeyConstraint baseTableName=fhir_task, constraintName=task_code_fk, referencedTableName=concept','',NULL,'4.31.1',NULL,NULL,'7312998417'),('add_part_of_reference_join_table_20200311','r.kalai','liquibase.xml','2025-05-15 15:43:52',1077,'EXECUTED','9:33245528ae229b3295bf8436504aba97','createTable tableName=fhir_task_part_of_reference; addForeignKeyConstraint baseTableName=fhir_task_part_of_reference, constraintName=task_part_of_fk, referencedTableName=fhir_task; addForeignKeyConstraint baseTableName=fhir_task_part_of_reference,...','',NULL,'4.31.1',NULL,NULL,'7312998417');
/*!40000 ALTER TABLE `liquibasechangelog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `liquibasechangeloglock`
--

DROP TABLE IF EXISTS `liquibasechangeloglock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `liquibasechangeloglock` (
  `ID` int NOT NULL,
  `LOCKED` tinyint(1) NOT NULL,
  `LOCKGRANTED` datetime DEFAULT NULL,
  `LOCKEDBY` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `liquibasechangeloglock`
--

LOCK TABLES `liquibasechangeloglock` WRITE;
/*!40000 ALTER TABLE `liquibasechangeloglock` DISABLE KEYS */;
INSERT INTO `liquibasechangeloglock` VALUES (1,0,NULL,NULL);
/*!40000 ALTER TABLE `liquibasechangeloglock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location` (
  `location_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city_village` varchar(255) DEFAULT NULL,
  `state_province` varchar(255) DEFAULT NULL,
  `postal_code` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `latitude` varchar(50) DEFAULT NULL,
  `longitude` varchar(50) DEFAULT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `county_district` varchar(255) DEFAULT NULL,
  `address3` varchar(255) DEFAULT NULL,
  `address4` varchar(255) DEFAULT NULL,
  `address5` varchar(255) DEFAULT NULL,
  `address6` varchar(255) DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `parent_location` int DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `address7` varchar(255) DEFAULT NULL,
  `address8` varchar(255) DEFAULT NULL,
  `address9` varchar(255) DEFAULT NULL,
  `address10` varchar(255) DEFAULT NULL,
  `address11` varchar(255) DEFAULT NULL,
  `address12` varchar(255) DEFAULT NULL,
  `address13` varchar(255) DEFAULT NULL,
  `address14` varchar(255) DEFAULT NULL,
  `address15` varchar(255) DEFAULT NULL,
  `location_type_concept_id` int DEFAULT NULL,
  PRIMARY KEY (`location_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `location_changed_by` (`changed_by`),
  KEY `location_retired_status` (`retired`),
  KEY `location_type_fk` (`location_type_concept_id`),
  KEY `name_of_location` (`name`),
  KEY `parent_location` (`parent_location`),
  KEY `user_who_created_location` (`creator`),
  KEY `user_who_retired_location` (`retired_by`),
  CONSTRAINT `location_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `location_type_fk` FOREIGN KEY (`location_type_concept_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `parent_location` FOREIGN KEY (`parent_location`) REFERENCES `location` (`location_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_created_location` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_retired_location` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES (1,'Unknown Location',NULL,'','','','','','',NULL,NULL,1,'2005-09-22 00:00:00',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'8d6c993e-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_attribute`
--

DROP TABLE IF EXISTS `location_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location_attribute` (
  `location_attribute_id` int NOT NULL AUTO_INCREMENT,
  `location_id` int NOT NULL,
  `attribute_type_id` int NOT NULL,
  `value_reference` text NOT NULL,
  `uuid` char(38) NOT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`location_attribute_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `location_attribute_attribute_type_id_fk` (`attribute_type_id`),
  KEY `location_attribute_changed_by_fk` (`changed_by`),
  KEY `location_attribute_creator_fk` (`creator`),
  KEY `location_attribute_location_fk` (`location_id`),
  KEY `location_attribute_voided_by_fk` (`voided_by`),
  CONSTRAINT `location_attribute_attribute_type_id_fk` FOREIGN KEY (`attribute_type_id`) REFERENCES `location_attribute_type` (`location_attribute_type_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `location_attribute_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `location_attribute_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `location_attribute_location_fk` FOREIGN KEY (`location_id`) REFERENCES `location` (`location_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `location_attribute_voided_by_fk` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_attribute`
--

LOCK TABLES `location_attribute` WRITE;
/*!40000 ALTER TABLE `location_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `location_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_attribute_type`
--

DROP TABLE IF EXISTS `location_attribute_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location_attribute_type` (
  `location_attribute_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `datatype` varchar(255) DEFAULT NULL,
  `datatype_config` text,
  `preferred_handler` varchar(255) DEFAULT NULL,
  `handler_config` text,
  `min_occurs` int NOT NULL,
  `max_occurs` int DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`location_attribute_type_id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `location_attribute_type_changed_by_fk` (`changed_by`),
  KEY `location_attribute_type_creator_fk` (`creator`),
  KEY `location_attribute_type_retired_by_fk` (`retired_by`),
  CONSTRAINT `location_attribute_type_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `location_attribute_type_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `location_attribute_type_retired_by_fk` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_attribute_type`
--

LOCK TABLES `location_attribute_type` WRITE;
/*!40000 ALTER TABLE `location_attribute_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `location_attribute_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_tag`
--

DROP TABLE IF EXISTS `location_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location_tag` (
  `location_tag_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  PRIMARY KEY (`location_tag_id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `location_tag_changed_by` (`changed_by`),
  KEY `location_tag_creator` (`creator`),
  KEY `location_tag_retired_by` (`retired_by`),
  CONSTRAINT `location_tag_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `location_tag_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `location_tag_retired_by` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_tag`
--

LOCK TABLES `location_tag` WRITE;
/*!40000 ALTER TABLE `location_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `location_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_tag_map`
--

DROP TABLE IF EXISTS `location_tag_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location_tag_map` (
  `location_id` int NOT NULL,
  `location_tag_id` int NOT NULL,
  PRIMARY KEY (`location_id`,`location_tag_id`),
  KEY `location_tag_map_tag` (`location_tag_id`),
  CONSTRAINT `location_tag_map_location` FOREIGN KEY (`location_id`) REFERENCES `location` (`location_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `location_tag_map_tag` FOREIGN KEY (`location_tag_id`) REFERENCES `location_tag` (`location_tag_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_tag_map`
--

LOCK TABLES `location_tag_map` WRITE;
/*!40000 ALTER TABLE `location_tag_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `location_tag_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medication_dispense`
--

DROP TABLE IF EXISTS `medication_dispense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medication_dispense` (
  `medication_dispense_id` int NOT NULL AUTO_INCREMENT,
  `uuid` char(38) NOT NULL,
  `patient_id` int NOT NULL,
  `encounter_id` int DEFAULT NULL,
  `concept` int NOT NULL,
  `drug_id` int DEFAULT NULL,
  `location_id` int DEFAULT NULL,
  `dispenser` int DEFAULT NULL,
  `drug_order_id` int DEFAULT NULL,
  `status` int NOT NULL,
  `status_reason` int DEFAULT NULL,
  `type` int DEFAULT NULL,
  `quantity` double DEFAULT NULL,
  `quantity_units` int DEFAULT NULL,
  `dose` double DEFAULT NULL,
  `dose_units` int DEFAULT NULL,
  `route` int DEFAULT NULL,
  `frequency` int DEFAULT NULL,
  `as_needed` tinyint(1) DEFAULT NULL,
  `dosing_instructions` text,
  `date_prepared` datetime DEFAULT NULL,
  `date_handed_over` datetime DEFAULT NULL,
  `was_substituted` tinyint(1) DEFAULT NULL,
  `substitution_type` int DEFAULT NULL,
  `substitution_reason` int DEFAULT NULL,
  `form_namespace_and_path` varchar(255) DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`medication_dispense_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `medication_dispense_changed_by_fk` (`changed_by`),
  KEY `medication_dispense_concept_fk` (`concept`),
  KEY `medication_dispense_creator_fk` (`creator`),
  KEY `medication_dispense_dispenser_fk` (`dispenser`),
  KEY `medication_dispense_dose_units_fk` (`dose_units`),
  KEY `medication_dispense_drug_fk` (`drug_id`),
  KEY `medication_dispense_drug_order_fk` (`drug_order_id`),
  KEY `medication_dispense_encounter_fk` (`encounter_id`),
  KEY `medication_dispense_frequency_fk` (`frequency`),
  KEY `medication_dispense_location_fk` (`location_id`),
  KEY `medication_dispense_patient_fk` (`patient_id`),
  KEY `medication_dispense_quantity_units_fk` (`quantity_units`),
  KEY `medication_dispense_route_fk` (`route`),
  KEY `medication_dispense_status_fk` (`status`),
  KEY `medication_dispense_status_reason_fk` (`status_reason`),
  KEY `medication_dispense_substitution_reason_fk` (`substitution_reason`),
  KEY `medication_dispense_substitution_type_fk` (`substitution_type`),
  KEY `medication_dispense_type_fk` (`type`),
  KEY `medication_dispense_voided_by_fk` (`voided_by`),
  CONSTRAINT `medication_dispense_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `medication_dispense_concept_fk` FOREIGN KEY (`concept`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `medication_dispense_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `medication_dispense_dispenser_fk` FOREIGN KEY (`dispenser`) REFERENCES `provider` (`provider_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `medication_dispense_dose_units_fk` FOREIGN KEY (`dose_units`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `medication_dispense_drug_fk` FOREIGN KEY (`drug_id`) REFERENCES `drug` (`drug_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `medication_dispense_drug_order_fk` FOREIGN KEY (`drug_order_id`) REFERENCES `drug_order` (`order_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `medication_dispense_encounter_fk` FOREIGN KEY (`encounter_id`) REFERENCES `encounter` (`encounter_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `medication_dispense_frequency_fk` FOREIGN KEY (`frequency`) REFERENCES `order_frequency` (`order_frequency_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `medication_dispense_location_fk` FOREIGN KEY (`location_id`) REFERENCES `location` (`location_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `medication_dispense_patient_fk` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `medication_dispense_quantity_units_fk` FOREIGN KEY (`quantity_units`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `medication_dispense_route_fk` FOREIGN KEY (`route`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `medication_dispense_status_fk` FOREIGN KEY (`status`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `medication_dispense_status_reason_fk` FOREIGN KEY (`status_reason`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `medication_dispense_substitution_reason_fk` FOREIGN KEY (`substitution_reason`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `medication_dispense_substitution_type_fk` FOREIGN KEY (`substitution_type`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `medication_dispense_type_fk` FOREIGN KEY (`type`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `medication_dispense_voided_by_fk` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medication_dispense`
--

LOCK TABLES `medication_dispense` WRITE;
/*!40000 ALTER TABLE `medication_dispense` DISABLE KEYS */;
/*!40000 ALTER TABLE `medication_dispense` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note`
--

DROP TABLE IF EXISTS `note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note` (
  `note_id` int NOT NULL DEFAULT '0',
  `note_type` varchar(50) DEFAULT NULL,
  `patient_id` int DEFAULT NULL,
  `obs_id` int DEFAULT NULL,
  `encounter_id` int DEFAULT NULL,
  `text` text NOT NULL,
  `priority` int DEFAULT NULL,
  `parent` int DEFAULT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`note_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `encounter_note` (`encounter_id`),
  KEY `note_hierarchy` (`parent`),
  KEY `obs_note` (`obs_id`),
  KEY `patient_note` (`patient_id`),
  KEY `user_who_changed_note` (`changed_by`),
  KEY `user_who_created_note` (`creator`),
  CONSTRAINT `encounter_note` FOREIGN KEY (`encounter_id`) REFERENCES `encounter` (`encounter_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `note_hierarchy` FOREIGN KEY (`parent`) REFERENCES `note` (`note_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `obs_note` FOREIGN KEY (`obs_id`) REFERENCES `obs` (`obs_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `patient_note` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `user_who_changed_note` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_created_note` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note`
--

LOCK TABLES `note` WRITE;
/*!40000 ALTER TABLE `note` DISABLE KEYS */;
/*!40000 ALTER TABLE `note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_alert`
--

DROP TABLE IF EXISTS `notification_alert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_alert` (
  `alert_id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(512) NOT NULL,
  `satisfied_by_any` tinyint(1) NOT NULL DEFAULT '0',
  `alert_read` tinyint(1) NOT NULL DEFAULT '0',
  `date_to_expire` datetime DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`alert_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `alert_creator` (`creator`),
  KEY `alert_date_to_expire_idx` (`date_to_expire`),
  KEY `user_who_changed_alert` (`changed_by`),
  CONSTRAINT `alert_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_changed_alert` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_alert`
--

LOCK TABLES `notification_alert` WRITE;
/*!40000 ALTER TABLE `notification_alert` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_alert` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_alert_recipient`
--

DROP TABLE IF EXISTS `notification_alert_recipient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_alert_recipient` (
  `alert_id` int NOT NULL,
  `user_id` int NOT NULL,
  `alert_read` tinyint(1) NOT NULL DEFAULT '0',
  `date_changed` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`alert_id`,`user_id`),
  KEY `alert_read_by_user` (`user_id`),
  CONSTRAINT `alert_read_by_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `id_of_alert` FOREIGN KEY (`alert_id`) REFERENCES `notification_alert` (`alert_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_alert_recipient`
--

LOCK TABLES `notification_alert_recipient` WRITE;
/*!40000 ALTER TABLE `notification_alert_recipient` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_alert_recipient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_template`
--

DROP TABLE IF EXISTS `notification_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_template` (
  `template_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `template` text,
  `subject` varchar(100) DEFAULT NULL,
  `sender` varchar(255) DEFAULT NULL,
  `recipients` varchar(512) DEFAULT NULL,
  `ordinal` int DEFAULT '0',
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`template_id`),
  UNIQUE KEY `uuid` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_template`
--

LOCK TABLES `notification_template` WRITE;
/*!40000 ALTER TABLE `notification_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `obs`
--

DROP TABLE IF EXISTS `obs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `obs` (
  `obs_id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `concept_id` int NOT NULL DEFAULT '0',
  `encounter_id` int DEFAULT NULL,
  `order_id` int DEFAULT NULL,
  `obs_datetime` datetime NOT NULL,
  `location_id` int DEFAULT NULL,
  `obs_group_id` int DEFAULT NULL,
  `accession_number` varchar(255) DEFAULT NULL,
  `value_group_id` int DEFAULT NULL,
  `value_coded` int DEFAULT NULL,
  `value_coded_name_id` int DEFAULT NULL,
  `value_drug` int DEFAULT NULL,
  `value_datetime` datetime DEFAULT NULL,
  `value_numeric` double DEFAULT NULL,
  `value_modifier` varchar(2) DEFAULT NULL,
  `value_text` text,
  `value_complex` varchar(1000) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  `previous_version` int DEFAULT NULL,
  `form_namespace_and_path` varchar(255) DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'FINAL',
  `interpretation` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`obs_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `answer_concept` (`value_coded`),
  KEY `answer_concept_drug` (`value_drug`),
  KEY `encounter_observations` (`encounter_id`),
  KEY `obs_concept` (`concept_id`),
  KEY `obs_datetime_idx` (`obs_datetime`),
  KEY `obs_enterer` (`creator`),
  KEY `obs_grouping_id` (`obs_group_id`),
  KEY `obs_location` (`location_id`),
  KEY `obs_name_of_coded_value` (`value_coded_name_id`),
  KEY `obs_order` (`order_id`),
  KEY `person_obs` (`person_id`),
  KEY `previous_version` (`previous_version`),
  KEY `user_who_voided_obs` (`voided_by`),
  CONSTRAINT `answer_concept` FOREIGN KEY (`value_coded`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `answer_concept_drug` FOREIGN KEY (`value_drug`) REFERENCES `drug` (`drug_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `encounter_observations` FOREIGN KEY (`encounter_id`) REFERENCES `encounter` (`encounter_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `obs_concept` FOREIGN KEY (`concept_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `obs_enterer` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `obs_grouping_id` FOREIGN KEY (`obs_group_id`) REFERENCES `obs` (`obs_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `obs_location` FOREIGN KEY (`location_id`) REFERENCES `location` (`location_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `obs_name_of_coded_value` FOREIGN KEY (`value_coded_name_id`) REFERENCES `concept_name` (`concept_name_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `obs_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `person_obs` FOREIGN KEY (`person_id`) REFERENCES `person` (`person_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `previous_version` FOREIGN KEY (`previous_version`) REFERENCES `obs` (`obs_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_voided_obs` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `obs`
--

LOCK TABLES `obs` WRITE;
/*!40000 ALTER TABLE `obs` DISABLE KEYS */;
/*!40000 ALTER TABLE `obs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `obs_reference_range`
--

DROP TABLE IF EXISTS `obs_reference_range`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `obs_reference_range` (
  `obs_reference_range_id` int NOT NULL AUTO_INCREMENT,
  `obs_id` int NOT NULL,
  `hi_absolute` double DEFAULT NULL,
  `hi_critical` double DEFAULT NULL,
  `hi_normal` double DEFAULT NULL,
  `low_absolute` double DEFAULT NULL,
  `low_critical` double DEFAULT NULL,
  `low_normal` double DEFAULT NULL,
  `uuid` char(38) DEFAULT NULL,
  PRIMARY KEY (`obs_reference_range_id`),
  UNIQUE KEY `obs_id` (`obs_id`),
  UNIQUE KEY `uuid` (`uuid`),
  CONSTRAINT `fk_obs_reference_range` FOREIGN KEY (`obs_id`) REFERENCES `obs` (`obs_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `obs_reference_range`
--

LOCK TABLES `obs_reference_range` WRITE;
/*!40000 ALTER TABLE `obs_reference_range` DISABLE KEYS */;
/*!40000 ALTER TABLE `obs_reference_range` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_attribute`
--

DROP TABLE IF EXISTS `order_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_attribute` (
  `order_attribute_id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `attribute_type_id` int NOT NULL,
  `value_reference` text NOT NULL,
  `uuid` char(38) NOT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`order_attribute_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `order_attribute_attribute_type_id_fk` (`attribute_type_id`),
  KEY `order_attribute_changed_by_fk` (`changed_by`),
  KEY `order_attribute_creator_fk` (`creator`),
  KEY `order_attribute_order_fk` (`order_id`),
  KEY `order_attribute_voided_by_fk` (`voided_by`),
  CONSTRAINT `order_attribute_attribute_type_id_fk` FOREIGN KEY (`attribute_type_id`) REFERENCES `order_attribute_type` (`order_attribute_type_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_attribute_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_attribute_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_attribute_order_fk` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_attribute_voided_by_fk` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_attribute`
--

LOCK TABLES `order_attribute` WRITE;
/*!40000 ALTER TABLE `order_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_attribute_type`
--

DROP TABLE IF EXISTS `order_attribute_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_attribute_type` (
  `order_attribute_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `datatype` varchar(255) DEFAULT NULL,
  `datatype_config` text,
  `preferred_handler` varchar(255) DEFAULT NULL,
  `handler_config` text,
  `min_occurs` int NOT NULL,
  `max_occurs` int DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`order_attribute_type_id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `order_attribute_type_changed_by_fk` (`changed_by`),
  KEY `order_attribute_type_creator_fk` (`creator`),
  KEY `order_attribute_type_retired_by_fk` (`retired_by`),
  CONSTRAINT `order_attribute_type_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_attribute_type_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_attribute_type_retired_by_fk` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_attribute_type`
--

LOCK TABLES `order_attribute_type` WRITE;
/*!40000 ALTER TABLE `order_attribute_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_attribute_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_frequency`
--

DROP TABLE IF EXISTS `order_frequency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_frequency` (
  `order_frequency_id` int NOT NULL AUTO_INCREMENT,
  `concept_id` int NOT NULL,
  `frequency_per_day` double DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`order_frequency_id`),
  UNIQUE KEY `concept_id` (`concept_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `order_frequency_changed_by_fk` (`changed_by`),
  KEY `order_frequency_creator_fk` (`creator`),
  KEY `order_frequency_retired_by_fk` (`retired_by`),
  CONSTRAINT `order_frequency_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_frequency_concept_id_fk` FOREIGN KEY (`concept_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_frequency_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_frequency_retired_by_fk` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_frequency`
--

LOCK TABLES `order_frequency` WRITE;
/*!40000 ALTER TABLE `order_frequency` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_frequency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_group`
--

DROP TABLE IF EXISTS `order_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_group` (
  `order_group_id` int NOT NULL AUTO_INCREMENT,
  `order_set_id` int DEFAULT NULL,
  `patient_id` int NOT NULL,
  `encounter_id` int NOT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  `order_group_reason` int DEFAULT NULL,
  `parent_order_group` int DEFAULT NULL,
  `previous_order_group` int DEFAULT NULL,
  PRIMARY KEY (`order_group_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `order_group_changed_by_fk` (`changed_by`),
  KEY `order_group_creator_fk` (`creator`),
  KEY `order_group_encounter_id_fk` (`encounter_id`),
  KEY `order_group_order_group_reason_fk` (`order_group_reason`),
  KEY `order_group_parent_order_group_fk` (`parent_order_group`),
  KEY `order_group_patient_id_fk` (`patient_id`),
  KEY `order_group_previous_order_group_fk` (`previous_order_group`),
  KEY `order_group_set_id_fk` (`order_set_id`),
  KEY `order_group_voided_by_fk` (`voided_by`),
  CONSTRAINT `order_group_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_group_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_group_encounter_id_fk` FOREIGN KEY (`encounter_id`) REFERENCES `encounter` (`encounter_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_group_order_group_reason_fk` FOREIGN KEY (`order_group_reason`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_group_parent_order_group_fk` FOREIGN KEY (`parent_order_group`) REFERENCES `order_group` (`order_group_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_group_patient_id_fk` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_group_previous_order_group_fk` FOREIGN KEY (`previous_order_group`) REFERENCES `order_group` (`order_group_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_group_set_id_fk` FOREIGN KEY (`order_set_id`) REFERENCES `order_set` (`order_set_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_group_voided_by_fk` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_group`
--

LOCK TABLES `order_group` WRITE;
/*!40000 ALTER TABLE `order_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_group_attribute`
--

DROP TABLE IF EXISTS `order_group_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_group_attribute` (
  `order_group_attribute_id` int NOT NULL AUTO_INCREMENT,
  `order_group_id` int NOT NULL,
  `attribute_type_id` int NOT NULL,
  `value_reference` text NOT NULL,
  `uuid` char(38) NOT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`order_group_attribute_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `order_group_attribute_attribute_type_id_fk` (`attribute_type_id`),
  KEY `order_group_attribute_changed_by_fk` (`changed_by`),
  KEY `order_group_attribute_creator_fk` (`creator`),
  KEY `order_group_attribute_order_group_fk` (`order_group_id`),
  KEY `order_group_attribute_voided_by_fk` (`voided_by`),
  CONSTRAINT `order_group_attribute_attribute_type_id_fk` FOREIGN KEY (`attribute_type_id`) REFERENCES `order_group_attribute_type` (`order_group_attribute_type_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_group_attribute_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_group_attribute_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_group_attribute_order_group_fk` FOREIGN KEY (`order_group_id`) REFERENCES `order_group` (`order_group_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_group_attribute_voided_by_fk` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_group_attribute`
--

LOCK TABLES `order_group_attribute` WRITE;
/*!40000 ALTER TABLE `order_group_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_group_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_group_attribute_type`
--

DROP TABLE IF EXISTS `order_group_attribute_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_group_attribute_type` (
  `order_group_attribute_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `datatype` varchar(255) DEFAULT NULL,
  `datatype_config` text,
  `preferred_handler` varchar(255) DEFAULT NULL,
  `handler_config` text,
  `min_occurs` int NOT NULL,
  `max_occurs` int DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`order_group_attribute_type_id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `order_group_attribute_type_changed_by_fk` (`changed_by`),
  KEY `order_group_attribute_type_creator_fk` (`creator`),
  KEY `order_group_attribute_type_retired_by_fk` (`retired_by`),
  CONSTRAINT `order_group_attribute_type_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_group_attribute_type_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_group_attribute_type_retired_by_fk` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_group_attribute_type`
--

LOCK TABLES `order_group_attribute_type` WRITE;
/*!40000 ALTER TABLE `order_group_attribute_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_group_attribute_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_set`
--

DROP TABLE IF EXISTS `order_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_set` (
  `order_set_id` int NOT NULL AUTO_INCREMENT,
  `operator` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  `category` int DEFAULT NULL,
  PRIMARY KEY (`order_set_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `category_order_set_fk` (`category`),
  KEY `order_set_changed_by_fk` (`changed_by`),
  KEY `order_set_creator_fk` (`creator`),
  KEY `order_set_retired_by_fk` (`retired_by`),
  CONSTRAINT `category_order_set_fk` FOREIGN KEY (`category`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_set_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_set_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_set_retired_by_fk` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_set`
--

LOCK TABLES `order_set` WRITE;
/*!40000 ALTER TABLE `order_set` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_set_attribute`
--

DROP TABLE IF EXISTS `order_set_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_set_attribute` (
  `order_set_attribute_id` int NOT NULL AUTO_INCREMENT,
  `order_set_id` int NOT NULL,
  `attribute_type_id` int NOT NULL,
  `value_reference` text NOT NULL,
  `uuid` char(38) NOT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`order_set_attribute_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `order_set_attribute_attribute_type_id_fk` (`attribute_type_id`),
  KEY `order_set_attribute_changed_by_fk` (`changed_by`),
  KEY `order_set_attribute_creator_fk` (`creator`),
  KEY `order_set_attribute_order_set_fk` (`order_set_id`),
  KEY `order_set_attribute_voided_by_fk` (`voided_by`),
  CONSTRAINT `order_set_attribute_attribute_type_id_fk` FOREIGN KEY (`attribute_type_id`) REFERENCES `order_set_attribute_type` (`order_set_attribute_type_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_set_attribute_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_set_attribute_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_set_attribute_order_set_fk` FOREIGN KEY (`order_set_id`) REFERENCES `order_set` (`order_set_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_set_attribute_voided_by_fk` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_set_attribute`
--

LOCK TABLES `order_set_attribute` WRITE;
/*!40000 ALTER TABLE `order_set_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_set_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_set_attribute_type`
--

DROP TABLE IF EXISTS `order_set_attribute_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_set_attribute_type` (
  `order_set_attribute_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `datatype` varchar(255) DEFAULT NULL,
  `datatype_config` text,
  `preferred_handler` varchar(255) DEFAULT NULL,
  `handler_config` text,
  `min_occurs` int NOT NULL,
  `max_occurs` int DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`order_set_attribute_type_id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `order_set_attribute_type_changed_by_fk` (`changed_by`),
  KEY `order_set_attribute_type_creator_fk` (`creator`),
  KEY `order_set_attribute_type_retired_by_fk` (`retired_by`),
  CONSTRAINT `order_set_attribute_type_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_set_attribute_type_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_set_attribute_type_retired_by_fk` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_set_attribute_type`
--

LOCK TABLES `order_set_attribute_type` WRITE;
/*!40000 ALTER TABLE `order_set_attribute_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_set_attribute_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_set_member`
--

DROP TABLE IF EXISTS `order_set_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_set_member` (
  `order_set_member_id` int NOT NULL AUTO_INCREMENT,
  `order_type` int NOT NULL,
  `order_template` text,
  `order_template_type` varchar(1024) DEFAULT NULL,
  `order_set_id` int NOT NULL,
  `sequence_number` int NOT NULL,
  `concept_id` int NOT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`order_set_member_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `order_set_member_changed_by_fk` (`changed_by`),
  KEY `order_set_member_concept_id_fk` (`concept_id`),
  KEY `order_set_member_creator_fk` (`creator`),
  KEY `order_set_member_order_set_id_fk` (`order_set_id`),
  KEY `order_set_member_order_type_fk` (`order_type`),
  KEY `order_set_member_retired_by_fk` (`retired_by`),
  CONSTRAINT `order_set_member_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_set_member_concept_id_fk` FOREIGN KEY (`concept_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_set_member_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_set_member_order_set_id_fk` FOREIGN KEY (`order_set_id`) REFERENCES `order_set` (`order_set_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_set_member_order_type_fk` FOREIGN KEY (`order_type`) REFERENCES `order_type` (`order_type_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_set_member_retired_by_fk` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_set_member`
--

LOCK TABLES `order_set_member` WRITE;
/*!40000 ALTER TABLE `order_set_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_set_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_type`
--

DROP TABLE IF EXISTS `order_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_type` (
  `order_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  `java_class_name` varchar(255) NOT NULL,
  `parent` int DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  PRIMARY KEY (`order_type_id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `order_type_changed_by` (`changed_by`),
  KEY `order_type_parent_order_type` (`parent`),
  KEY `order_type_retired_status` (`retired`),
  KEY `type_created_by` (`creator`),
  KEY `user_who_retired_order_type` (`retired_by`),
  CONSTRAINT `order_type_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_type_parent_order_type` FOREIGN KEY (`parent`) REFERENCES `order_type` (`order_type_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `type_created_by` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_retired_order_type` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_type`
--

LOCK TABLES `order_type` WRITE;
/*!40000 ALTER TABLE `order_type` DISABLE KEYS */;
INSERT INTO `order_type` VALUES (2,'Drug Order','An order for a medication to be given to the patient',1,'2010-05-12 00:00:00',0,NULL,NULL,NULL,'131168f4-15f5-102d-96e4-000c29c2a5d7','org.openmrs.DrugOrder',NULL,NULL,NULL),(3,'Test Order','Order type for test orders',1,'2014-03-09 00:00:00',0,NULL,NULL,NULL,'52a447d3-a64a-11e3-9aeb-50e549534c5e','org.openmrs.TestOrder',NULL,NULL,NULL);
/*!40000 ALTER TABLE `order_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_type_class_map`
--

DROP TABLE IF EXISTS `order_type_class_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_type_class_map` (
  `order_type_id` int NOT NULL,
  `concept_class_id` int NOT NULL,
  PRIMARY KEY (`order_type_id`,`concept_class_id`),
  UNIQUE KEY `concept_class_id` (`concept_class_id`),
  CONSTRAINT `fk_order_type_class_map_concept_class_concept_class_id` FOREIGN KEY (`concept_class_id`) REFERENCES `concept_class` (`concept_class_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_order_type_order_type_id` FOREIGN KEY (`order_type_id`) REFERENCES `order_type` (`order_type_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_type_class_map`
--

LOCK TABLES `order_type_class_map` WRITE;
/*!40000 ALTER TABLE `order_type_class_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_type_class_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `order_id` int NOT NULL AUTO_INCREMENT,
  `order_type_id` int NOT NULL DEFAULT '0',
  `concept_id` int NOT NULL DEFAULT '0',
  `orderer` int NOT NULL,
  `encounter_id` int NOT NULL,
  `instructions` text,
  `date_activated` datetime DEFAULT NULL,
  `auto_expire_date` datetime DEFAULT NULL,
  `date_stopped` datetime DEFAULT NULL,
  `order_reason` int DEFAULT NULL,
  `order_reason_non_coded` varchar(255) DEFAULT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `patient_id` int NOT NULL,
  `accession_number` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  `urgency` varchar(50) NOT NULL DEFAULT 'ROUTINE',
  `order_number` varchar(50) NOT NULL,
  `previous_order_id` int DEFAULT NULL,
  `order_action` varchar(50) NOT NULL,
  `comment_to_fulfiller` varchar(1024) DEFAULT NULL,
  `care_setting` int NOT NULL,
  `scheduled_date` datetime DEFAULT NULL,
  `order_group_id` int DEFAULT NULL,
  `sort_weight` double DEFAULT NULL,
  `fulfiller_comment` varchar(1024) DEFAULT NULL,
  `fulfiller_status` varchar(50) DEFAULT NULL,
  `form_namespace_and_path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `discontinued_because` (`order_reason`),
  KEY `fk_orderer_provider` (`orderer`),
  KEY `order_creator` (`creator`),
  KEY `order_for_patient` (`patient_id`),
  KEY `orders_accession_number` (`accession_number`),
  KEY `orders_care_setting` (`care_setting`),
  KEY `orders_in_encounter` (`encounter_id`),
  KEY `orders_order_group_id_fk` (`order_group_id`),
  KEY `orders_order_number` (`order_number`),
  KEY `previous_order_id_order_id` (`previous_order_id`),
  KEY `type_of_order` (`order_type_id`),
  KEY `user_who_voided_order` (`voided_by`),
  CONSTRAINT `discontinued_because` FOREIGN KEY (`order_reason`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_orderer_provider` FOREIGN KEY (`orderer`) REFERENCES `provider` (`provider_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_for_patient` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `orders_care_setting` FOREIGN KEY (`care_setting`) REFERENCES `care_setting` (`care_setting_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `orders_in_encounter` FOREIGN KEY (`encounter_id`) REFERENCES `encounter` (`encounter_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `orders_order_group_id_fk` FOREIGN KEY (`order_group_id`) REFERENCES `order_group` (`order_group_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `previous_order_id_order_id` FOREIGN KEY (`previous_order_id`) REFERENCES `orders` (`order_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `type_of_order` FOREIGN KEY (`order_type_id`) REFERENCES `order_type` (`order_type_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_voided_order` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient` (
  `patient_id` int NOT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `allergy_status` varchar(50) NOT NULL DEFAULT 'Unknown',
  PRIMARY KEY (`patient_id`),
  KEY `user_who_changed_pat` (`changed_by`),
  KEY `user_who_created_patient` (`creator`),
  KEY `user_who_voided_patient` (`voided_by`),
  CONSTRAINT `person_id_for_patient` FOREIGN KEY (`patient_id`) REFERENCES `person` (`person_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `user_who_changed_pat` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_created_patient` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_voided_patient` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient`
--

LOCK TABLES `patient` WRITE;
/*!40000 ALTER TABLE `patient` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_identifier`
--

DROP TABLE IF EXISTS `patient_identifier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_identifier` (
  `patient_identifier_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NOT NULL DEFAULT '0',
  `identifier` varchar(50) NOT NULL DEFAULT '',
  `identifier_type` int NOT NULL DEFAULT '0',
  `preferred` tinyint(1) NOT NULL DEFAULT '0',
  `location_id` int DEFAULT '0',
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `date_changed` datetime DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  `patient_program_id` int DEFAULT NULL,
  PRIMARY KEY (`patient_identifier_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `defines_identifier_type` (`identifier_type`),
  KEY `identifier_creator` (`creator`),
  KEY `identifier_name` (`identifier`),
  KEY `identifier_voider` (`voided_by`),
  KEY `idx_patient_identifier_patient` (`patient_id`),
  KEY `patient_identifier_changed_by` (`changed_by`),
  KEY `patient_identifier_ibfk_2` (`location_id`),
  KEY `patient_identifier_program_id_fk` (`patient_program_id`),
  CONSTRAINT `defines_identifier_type` FOREIGN KEY (`identifier_type`) REFERENCES `patient_identifier_type` (`patient_identifier_type_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_patient_id_patient_identifier` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `identifier_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `identifier_voider` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `patient_identifier_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `patient_identifier_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `location` (`location_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `patient_identifier_program_id_fk` FOREIGN KEY (`patient_program_id`) REFERENCES `patient_program` (`patient_program_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_identifier`
--

LOCK TABLES `patient_identifier` WRITE;
/*!40000 ALTER TABLE `patient_identifier` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_identifier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_identifier_type`
--

DROP TABLE IF EXISTS `patient_identifier_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_identifier_type` (
  `patient_identifier_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` text,
  `format` varchar(255) DEFAULT NULL,
  `check_digit` tinyint(1) NOT NULL DEFAULT '0',
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `format_description` varchar(255) DEFAULT NULL,
  `validator` varchar(200) DEFAULT NULL,
  `location_behavior` varchar(50) DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  `uniqueness_behavior` varchar(50) DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  PRIMARY KEY (`patient_identifier_type_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `patient_identifier_type_changed_by` (`changed_by`),
  KEY `patient_identifier_type_retired_status` (`retired`),
  KEY `type_creator` (`creator`),
  KEY `user_who_retired_patient_identifier_type` (`retired_by`),
  CONSTRAINT `patient_identifier_type_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `type_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_retired_patient_identifier_type` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_identifier_type`
--

LOCK TABLES `patient_identifier_type` WRITE;
/*!40000 ALTER TABLE `patient_identifier_type` DISABLE KEYS */;
INSERT INTO `patient_identifier_type` VALUES (1,'OpenMRS Identification Number','Unique number used in OpenMRS','',1,1,'2005-09-22 00:00:00',0,NULL,'org.openmrs.patient.impl.LuhnIdentifierValidator',NULL,0,NULL,NULL,NULL,'8d793bee-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL,NULL),(2,'Old Identification Number','Number given out prior to the OpenMRS system (No check digit)','',0,1,'2005-09-22 00:00:00',0,NULL,NULL,NULL,0,NULL,NULL,NULL,'8d79403a-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL,NULL);
/*!40000 ALTER TABLE `patient_identifier_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_program`
--

DROP TABLE IF EXISTS `patient_program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_program` (
  `patient_program_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NOT NULL DEFAULT '0',
  `program_id` int NOT NULL DEFAULT '0',
  `date_enrolled` datetime DEFAULT NULL,
  `date_completed` datetime DEFAULT NULL,
  `location_id` int DEFAULT NULL,
  `outcome_concept_id` int DEFAULT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`patient_program_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `patient_in_program` (`patient_id`),
  KEY `patient_program_creator` (`creator`),
  KEY `patient_program_location_id` (`location_id`),
  KEY `patient_program_outcome_concept_id_fk` (`outcome_concept_id`),
  KEY `program_for_patient` (`program_id`),
  KEY `user_who_changed` (`changed_by`),
  KEY `user_who_voided_patient_program` (`voided_by`),
  CONSTRAINT `patient_in_program` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `patient_program_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `patient_program_location_id` FOREIGN KEY (`location_id`) REFERENCES `location` (`location_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `patient_program_outcome_concept_id_fk` FOREIGN KEY (`outcome_concept_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `program_for_patient` FOREIGN KEY (`program_id`) REFERENCES `program` (`program_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_changed` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_voided_patient_program` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_program`
--

LOCK TABLES `patient_program` WRITE;
/*!40000 ALTER TABLE `patient_program` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_program` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_program_attribute`
--

DROP TABLE IF EXISTS `patient_program_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_program_attribute` (
  `patient_program_attribute_id` int NOT NULL AUTO_INCREMENT,
  `patient_program_id` int NOT NULL,
  `attribute_type_id` int NOT NULL,
  `value_reference` text NOT NULL,
  `uuid` char(38) NOT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`patient_program_attribute_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `patient_program_attribute_attributetype_fk` (`attribute_type_id`),
  KEY `patient_program_attribute_changed_by_fk` (`changed_by`),
  KEY `patient_program_attribute_creator_fk` (`creator`),
  KEY `patient_program_attribute_programid_fk` (`patient_program_id`),
  KEY `patient_program_attribute_voided_by_fk` (`voided_by`),
  CONSTRAINT `patient_program_attribute_attributetype_fk` FOREIGN KEY (`attribute_type_id`) REFERENCES `program_attribute_type` (`program_attribute_type_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `patient_program_attribute_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `patient_program_attribute_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `patient_program_attribute_programid_fk` FOREIGN KEY (`patient_program_id`) REFERENCES `patient_program` (`patient_program_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `patient_program_attribute_voided_by_fk` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_program_attribute`
--

LOCK TABLES `patient_program_attribute` WRITE;
/*!40000 ALTER TABLE `patient_program_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_program_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_state`
--

DROP TABLE IF EXISTS `patient_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_state` (
  `patient_state_id` int NOT NULL AUTO_INCREMENT,
  `patient_program_id` int NOT NULL DEFAULT '0',
  `state` int NOT NULL DEFAULT '0',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  `form_namespace_and_path` varchar(255) DEFAULT NULL,
  `encounter_id` int DEFAULT NULL,
  PRIMARY KEY (`patient_state_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `patient_program_for_state` (`patient_program_id`),
  KEY `patient_state_changer` (`changed_by`),
  KEY `patient_state_creator` (`creator`),
  KEY `patient_state_encounter_id_fk` (`encounter_id`),
  KEY `patient_state_voider` (`voided_by`),
  KEY `state_for_patient` (`state`),
  CONSTRAINT `patient_program_for_state` FOREIGN KEY (`patient_program_id`) REFERENCES `patient_program` (`patient_program_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `patient_state_changer` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `patient_state_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `patient_state_encounter_id_fk` FOREIGN KEY (`encounter_id`) REFERENCES `encounter` (`encounter_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `patient_state_voider` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `state_for_patient` FOREIGN KEY (`state`) REFERENCES `program_workflow_state` (`program_workflow_state_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_state`
--

LOCK TABLES `patient_state` WRITE;
/*!40000 ALTER TABLE `patient_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `person`
--

DROP TABLE IF EXISTS `person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `person` (
  `person_id` int NOT NULL AUTO_INCREMENT,
  `gender` varchar(50) DEFAULT '',
  `birthdate` date DEFAULT NULL,
  `birthdate_estimated` tinyint(1) NOT NULL DEFAULT '0',
  `dead` tinyint(1) NOT NULL DEFAULT '0',
  `death_date` datetime DEFAULT NULL,
  `cause_of_death` int DEFAULT NULL,
  `creator` int DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  `deathdate_estimated` tinyint(1) NOT NULL DEFAULT '0',
  `birthtime` time DEFAULT NULL,
  `cause_of_death_non_coded` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`person_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `person_birthdate` (`birthdate`),
  KEY `person_death_date` (`death_date`),
  KEY `person_died_because` (`cause_of_death`),
  KEY `user_who_changed_person` (`changed_by`),
  KEY `user_who_created_person` (`creator`),
  KEY `user_who_voided_person` (`voided_by`),
  CONSTRAINT `person_died_because` FOREIGN KEY (`cause_of_death`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_changed_person` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_created_person` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_voided_person` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person`
--

LOCK TABLES `person` WRITE;
/*!40000 ALTER TABLE `person` DISABLE KEYS */;
INSERT INTO `person` VALUES (1,'M',NULL,0,0,NULL,NULL,NULL,'2005-01-01 00:00:00',NULL,NULL,0,NULL,NULL,NULL,'5f87c042-6814-11e8-923f-e9a88dcb533f',0,NULL,NULL);
/*!40000 ALTER TABLE `person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `person_address`
--

DROP TABLE IF EXISTS `person_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `person_address` (
  `person_address_id` int NOT NULL AUTO_INCREMENT,
  `person_id` int DEFAULT NULL,
  `preferred` tinyint(1) NOT NULL DEFAULT '0',
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city_village` varchar(255) DEFAULT NULL,
  `state_province` varchar(255) DEFAULT NULL,
  `postal_code` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `latitude` varchar(50) DEFAULT NULL,
  `longitude` varchar(50) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `county_district` varchar(255) DEFAULT NULL,
  `address3` varchar(255) DEFAULT NULL,
  `address4` varchar(255) DEFAULT NULL,
  `address5` varchar(255) DEFAULT NULL,
  `address6` varchar(255) DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  `address7` varchar(255) DEFAULT NULL,
  `address8` varchar(255) DEFAULT NULL,
  `address9` varchar(255) DEFAULT NULL,
  `address10` varchar(255) DEFAULT NULL,
  `address11` varchar(255) DEFAULT NULL,
  `address12` varchar(255) DEFAULT NULL,
  `address13` varchar(255) DEFAULT NULL,
  `address14` varchar(255) DEFAULT NULL,
  `address15` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`person_address_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `address_for_person` (`person_id`),
  KEY `patient_address_creator` (`creator`),
  KEY `patient_address_void` (`voided_by`),
  KEY `person_address_changed_by` (`changed_by`),
  CONSTRAINT `address_for_person` FOREIGN KEY (`person_id`) REFERENCES `person` (`person_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `patient_address_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `patient_address_void` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `person_address_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person_address`
--

LOCK TABLES `person_address` WRITE;
/*!40000 ALTER TABLE `person_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `person_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `person_attribute`
--

DROP TABLE IF EXISTS `person_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `person_attribute` (
  `person_attribute_id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL DEFAULT '0',
  `value` varchar(50) NOT NULL DEFAULT '',
  `person_attribute_type_id` int NOT NULL DEFAULT '0',
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`person_attribute_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `attribute_changer` (`changed_by`),
  KEY `attribute_creator` (`creator`),
  KEY `attribute_voider` (`voided_by`),
  KEY `defines_attribute_type` (`person_attribute_type_id`),
  KEY `identifies_person` (`person_id`),
  CONSTRAINT `attribute_changer` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `attribute_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `attribute_voider` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `defines_attribute_type` FOREIGN KEY (`person_attribute_type_id`) REFERENCES `person_attribute_type` (`person_attribute_type_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `identifies_person` FOREIGN KEY (`person_id`) REFERENCES `person` (`person_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person_attribute`
--

LOCK TABLES `person_attribute` WRITE;
/*!40000 ALTER TABLE `person_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `person_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `person_attribute_type`
--

DROP TABLE IF EXISTS `person_attribute_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `person_attribute_type` (
  `person_attribute_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` text,
  `format` varchar(50) DEFAULT NULL,
  `foreign_key` int DEFAULT NULL,
  `searchable` tinyint(1) NOT NULL DEFAULT '0',
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `edit_privilege` varchar(255) DEFAULT NULL,
  `sort_weight` double DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`person_attribute_type_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `attribute_is_searchable` (`searchable`),
  KEY `attribute_type_changer` (`changed_by`),
  KEY `attribute_type_creator` (`creator`),
  KEY `name_of_attribute` (`name`),
  KEY `person_attribute_type_retired_status` (`retired`),
  KEY `privilege_which_can_edit` (`edit_privilege`),
  KEY `user_who_retired_person_attribute_type` (`retired_by`),
  CONSTRAINT `attribute_type_changer` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `attribute_type_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `privilege_which_can_edit` FOREIGN KEY (`edit_privilege`) REFERENCES `privilege` (`privilege`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_retired_person_attribute_type` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person_attribute_type`
--

LOCK TABLES `person_attribute_type` WRITE;
/*!40000 ALTER TABLE `person_attribute_type` DISABLE KEYS */;
INSERT INTO `person_attribute_type` VALUES (1,'Race','Group of persons related by common descent or heredity','java.lang.String',0,0,1,'2007-05-04 00:00:00',NULL,NULL,0,NULL,NULL,NULL,NULL,6,'8d871386-c2cc-11de-8d13-0010c6dffd0f'),(2,'Birthplace','Location of persons birth','java.lang.String',0,0,1,'2007-05-04 00:00:00',NULL,NULL,0,NULL,NULL,NULL,NULL,0,'8d8718c2-c2cc-11de-8d13-0010c6dffd0f'),(3,'Citizenship','Country of which this person is a member','java.lang.String',0,0,1,'2007-05-04 00:00:00',NULL,NULL,0,NULL,NULL,NULL,NULL,1,'8d871afc-c2cc-11de-8d13-0010c6dffd0f'),(4,'Mother\'s Name','First or last name of this person\'s mother','java.lang.String',0,0,1,'2007-05-04 00:00:00',NULL,NULL,0,NULL,NULL,NULL,NULL,5,'8d871d18-c2cc-11de-8d13-0010c6dffd0f'),(5,'Civil Status','Marriage status of this person','org.openmrs.Concept',1054,0,1,'2007-05-04 00:00:00',NULL,NULL,0,NULL,NULL,NULL,NULL,2,'8d871f2a-c2cc-11de-8d13-0010c6dffd0f'),(6,'Health District','District/region in which this patient\' home health center resides','java.lang.String',0,0,1,'2007-05-04 00:00:00',NULL,NULL,0,NULL,NULL,NULL,NULL,4,'8d872150-c2cc-11de-8d13-0010c6dffd0f'),(7,'Health Center','Specific Location of this person\'s home health center.','org.openmrs.Location',0,0,1,'2007-05-04 00:00:00',NULL,NULL,0,NULL,NULL,NULL,NULL,3,'8d87236c-c2cc-11de-8d13-0010c6dffd0f');
/*!40000 ALTER TABLE `person_attribute_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `person_merge_log`
--

DROP TABLE IF EXISTS `person_merge_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `person_merge_log` (
  `person_merge_log_id` int NOT NULL AUTO_INCREMENT,
  `winner_person_id` int NOT NULL,
  `loser_person_id` int NOT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `merged_data` text NOT NULL,
  `uuid` char(38) NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`person_merge_log_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `person_merge_log_changed_by_fk` (`changed_by`),
  KEY `person_merge_log_creator` (`creator`),
  KEY `person_merge_log_loser` (`loser_person_id`),
  KEY `person_merge_log_voided_by_fk` (`voided_by`),
  KEY `person_merge_log_winner` (`winner_person_id`),
  CONSTRAINT `person_merge_log_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `person_merge_log_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `person_merge_log_loser` FOREIGN KEY (`loser_person_id`) REFERENCES `person` (`person_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `person_merge_log_voided_by_fk` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `person_merge_log_winner` FOREIGN KEY (`winner_person_id`) REFERENCES `person` (`person_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person_merge_log`
--

LOCK TABLES `person_merge_log` WRITE;
/*!40000 ALTER TABLE `person_merge_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `person_merge_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `person_name`
--

DROP TABLE IF EXISTS `person_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `person_name` (
  `person_name_id` int NOT NULL AUTO_INCREMENT,
  `preferred` tinyint(1) NOT NULL DEFAULT '0',
  `person_id` int NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `given_name` varchar(50) DEFAULT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `family_name_prefix` varchar(50) DEFAULT NULL,
  `family_name` varchar(50) DEFAULT NULL,
  `family_name2` varchar(50) DEFAULT NULL,
  `family_name_suffix` varchar(50) DEFAULT NULL,
  `degree` varchar(50) DEFAULT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`person_name_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `family_name2` (`family_name2`),
  KEY `first_name` (`given_name`),
  KEY `last_name` (`family_name`),
  KEY `middle_name` (`middle_name`),
  KEY `name_for_person` (`person_id`),
  KEY `user_who_made_name` (`creator`),
  KEY `user_who_voided_name` (`voided_by`),
  CONSTRAINT `name_for_person` FOREIGN KEY (`person_id`) REFERENCES `person` (`person_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `user_who_made_name` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_voided_name` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person_name`
--

LOCK TABLES `person_name` WRITE;
/*!40000 ALTER TABLE `person_name` DISABLE KEYS */;
INSERT INTO `person_name` VALUES (1,1,1,NULL,'Super','',NULL,'User',NULL,NULL,NULL,1,'2005-01-01 00:00:00',0,NULL,NULL,NULL,NULL,NULL,'5f897a68-6814-11e8-923f-e9a88dcb533f');
/*!40000 ALTER TABLE `person_name` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `privilege`
--

DROP TABLE IF EXISTS `privilege`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `privilege` (
  `privilege` varchar(255) NOT NULL,
  `description` text,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`privilege`),
  UNIQUE KEY `uuid` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `privilege`
--

LOCK TABLES `privilege` WRITE;
/*!40000 ALTER TABLE `privilege` DISABLE KEYS */;
INSERT INTO `privilege` VALUES ('Add Allergies','Add allergies','8d04fc61-45de-4d16-a2f7-39ccbda88739'),('Add Cohorts','Able to add a cohort to the system','5f8a2896-6814-11e8-923f-e9a88dcb533f'),('Add Concept Proposals','Able to add concept proposals to the system','5f8a2a1c-6814-11e8-923f-e9a88dcb533f'),('Add Encounters','Able to add patient encounters','5f8a2a8a-6814-11e8-923f-e9a88dcb533f'),('Add HL7 Inbound Archive','Able to add an HL7 archive item','3192b2c9-3844-42f7-8e8e-f8964768ca26'),('Add HL7 Inbound Exception','Able to add an HL7 error item','e41c644c-1866-4572-a78d-6bfe36dd6a4b'),('Add HL7 Inbound Queue','Able to add an HL7 Queue item','b20ee658-9faa-4c6a-bc95-b5a9a4bfa4c2'),('Add HL7 Source','Able to add an HL7 Source','b8a2625f-3130-4b15-a3ba-907600d1bb03'),('Add Observations','Able to add patient observations','5f8a2ada-6814-11e8-923f-e9a88dcb533f'),('Add Orders','Able to add orders','5f8a2b7a-6814-11e8-923f-e9a88dcb533f'),('Add Patient Identifiers','Able to add patient identifiers','5f8a2bc0-6814-11e8-923f-e9a88dcb533f'),('Add Patient Programs','Able to add patients to programs','5f8a2c10-6814-11e8-923f-e9a88dcb533f'),('Add Patients','Able to add patients','5f8a2c56-6814-11e8-923f-e9a88dcb533f'),('Add People','Able to add person objects','5f8a2c92-6814-11e8-923f-e9a88dcb533f'),('Add Problems','Add problems','2f6d256a-1f73-4776-ad5b-f94c80f7beea'),('Add Relationships','Able to add relationships','5f8a2cce-6814-11e8-923f-e9a88dcb533f'),('Add Report Objects','Able to add report objects','5f8a2cf6-6814-11e8-923f-e9a88dcb533f'),('Add Reports','Able to add reports','5f8a2d32-6814-11e8-923f-e9a88dcb533f'),('Add Users','Able to add users to OpenMRS','5f8a2d5a-6814-11e8-923f-e9a88dcb533f'),('Add Visits','Able to add visits','65d14b28-3989-11e6-899a-a4d646d86a8a'),('Assign System Developer Role','Able to assign System Developer role','09cbaabc-ae63-44ed-9d4d-34ec6610e0a5'),('Configure Visits','Able to choose encounter visit handler and enable/disable encounter visits','d7899df6-68d7-49f1-bc3a-a1a64be157d6'),('Delete Cohorts','Able to add a cohort to the system','5f8a2d8c-6814-11e8-923f-e9a88dcb533f'),('Delete Concept Proposals','Able to delete concept proposals from the system','5f8a2dbe-6814-11e8-923f-e9a88dcb533f'),('Delete Conditions','Able to delete conditions','ef725ffa-2d14-41d8-b655-2d2430963b21'),('Delete Diagnoses','Able to delete diagnoses','a7882352-41b4-4da7-b422-84470ede7052'),('Delete Encounters','Able to delete patient encounters','5f8a2de6-6814-11e8-923f-e9a88dcb533f'),('Delete HL7 Inbound Archive','Able to delete/retire an HL7 archive item','7cd1f479-4e6a-422d-8b4d-7a7e5758d253'),('Delete HL7 Inbound Exception','Able to delete an HL7 archive item','25109fd5-edd1-4d11-84fe-a50b4001b50b'),('Delete HL7 Inbound Queue','Able to delete an HL7 Queue item','0e39bf44-a08b-4d61-9d20-08d2cc0ab51e'),('Delete Medication Dispense','Able to delete Medication Dispenses','edd99c3a-6005-4fa1-8a81-1ace0afd6e04'),('Delete Notes','Able to delete patient notes','ff39bade-4ea2-463b-8a66-ff4b26f85f25'),('Delete Observations','Able to delete patient observations','5f8a2e18-6814-11e8-923f-e9a88dcb533f'),('Delete Orders','Able to delete orders','5f8a2e40-6814-11e8-923f-e9a88dcb533f'),('Delete Patient Identifiers','Able to delete patient identifiers','5f8a2e72-6814-11e8-923f-e9a88dcb533f'),('Delete Patient Programs','Able to delete patients from programs','5f8a2ea4-6814-11e8-923f-e9a88dcb533f'),('Delete Patients','Able to delete patients','5f8a2ecc-6814-11e8-923f-e9a88dcb533f'),('Delete People','Able to delete objects','5f8a2efe-6814-11e8-923f-e9a88dcb533f'),('Delete Relationships','Able to delete relationships','5f8a2f26-6814-11e8-923f-e9a88dcb533f'),('Delete Report Objects','Able to delete report objects','5f8a2f58-6814-11e8-923f-e9a88dcb533f'),('Delete Reports','Able to delete reports','5f8a2f8a-6814-11e8-923f-e9a88dcb533f'),('Delete Users','Able to delete users in OpenMRS','5f8a2fb2-6814-11e8-923f-e9a88dcb533f'),('Delete Visits','Able to delete visits','02d02051-931b-4325-88d9-bf1a6cc85f5d'),('Edit Allergies','Able to edit allergies','507e9f66-ee25-4113-a55a-4b050022f55a'),('Edit Cohorts','Able to add a cohort to the system','5f8a2fe4-6814-11e8-923f-e9a88dcb533f'),('Edit Concept Proposals','Able to edit concept proposals in the system','5f8a300c-6814-11e8-923f-e9a88dcb533f'),('Edit Conditions','Able to edit conditions','910ec2ec-a87b-4528-ad5c-02c500068bf0'),('Edit Diagnoses','Able to edit diagnoses','107f5169-77a2-48d3-9f69-9f2ca9b419ca'),('Edit Encounters','Able to edit patient encounters','5f8a303e-6814-11e8-923f-e9a88dcb533f'),('Edit Medication Dispense','Able to edit Medication Dispenses','e6db2e08-3826-4220-9b85-8a6b2d2a96ce'),('Edit Notes','Able to edit patient notes','888fe070-549c-429a-9784-edbaf42e3229'),('Edit Observations','Able to edit patient observations','5f8a3066-6814-11e8-923f-e9a88dcb533f'),('Edit Orders','Able to edit orders','5f8a308e-6814-11e8-923f-e9a88dcb533f'),('Edit Patient Identifiers','Able to edit patient identifiers','5f8a30c0-6814-11e8-923f-e9a88dcb533f'),('Edit Patient Programs','Able to edit patients in programs','5f8a30e8-6814-11e8-923f-e9a88dcb533f'),('Edit Patients','Able to edit patients','5f8a311a-6814-11e8-923f-e9a88dcb533f'),('Edit People','Able to edit person objects','5f8a3142-6814-11e8-923f-e9a88dcb533f'),('Edit Problems','Able to edit problems','5131daf7-2c4d-4c2b-8f6e-bf7cf8290444'),('Edit Relationships','Able to edit relationships','5f8a3174-6814-11e8-923f-e9a88dcb533f'),('Edit Report Objects','Able to edit report objects','5f8a319c-6814-11e8-923f-e9a88dcb533f'),('Edit Reports','Able to edit reports','5f8a31ce-6814-11e8-923f-e9a88dcb533f'),('Edit User Passwords','Able to change the passwords of users in OpenMRS','5f8a31f6-6814-11e8-923f-e9a88dcb533f'),('Edit Users','Able to edit users in OpenMRS','5f8a3228-6814-11e8-923f-e9a88dcb533f'),('Edit Visits','Able to edit visits','14f4da3c-d1e1-4571-b379-0b533496f5b7'),('Form Entry','Allows user to access Form Entry pages/functions','5f8a3250-6814-11e8-923f-e9a88dcb533f'),('Get Allergies','Able to get allergies','d05118c6-2490-4d78-a41a-390e3596a220'),('Get Care Settings','Able to get Care Settings','1ab26030-a207-4a22-be52-b40be3e401dd'),('Get Concept Attribute Types','Able to get concept attribute types','498317ea-e55f-4488-9e87-0db1349c3d11'),('Get Concept Classes','Able to get concept classes','d05118c6-2490-4d78-a41a-390e3596a238'),('Get Concept Datatypes','Able to get concept datatypes','d05118c6-2490-4d78-a41a-390e3596a237'),('Get Concept Map Types','Able to get concept map types','d05118c6-2490-4d78-a41a-390e3596a230'),('Get Concept Proposals','Able to get concept proposals to the system','d05118c6-2490-4d78-a41a-390e3596a250'),('Get Concept Reference Terms','Able to get concept reference terms','d05118c6-2490-4d78-a41a-390e3596a229'),('Get Concept Sources','Able to get concept sources','d05118c6-2490-4d78-a41a-390e3596a231'),('Get Concepts','Able to get concept entries','d05118c6-2490-4d78-a41a-390e3596a251'),('Get Conditions','Able to get conditions','6b470c18-04e8-42c5-bc34-0ac871a0beb6'),('Get Database Changes','Able to get database changes from the admin screen','d05118c6-2490-4d78-a41a-390e3596a222'),('Get Diagnoses','Able to get diagnoses','77b0b402-c928-4811-b084-f0ef7087a49c'),('Get Diagnoses Attribute Types','Able to get diagnoses attribute types','e2b4b047-e595-4456-8ae1-8c16c4f23adc'),('Get Encounter Roles','Able to get encounter roles','d05118c6-2490-4d78-a41a-390e3596a210'),('Get Encounter Types','Able to get encounter types','d05118c6-2490-4d78-a41a-390e3596a247'),('Get Encounters','Able to get patient encounters','d05118c6-2490-4d78-a41a-390e3596a248'),('Get Field Types','Able to get field types','d05118c6-2490-4d78-a41a-390e3596a234'),('Get Forms','Able to get forms','d05118c6-2490-4d78-a41a-390e3596a240'),('Get Global Properties','Able to get global properties on the administration screen','d05118c6-2490-4d78-a41a-390e3596a226'),('Get HL7 Inbound Archive','Able to get an HL7 archive item','d05118c6-2490-4d78-a41a-390e3596a217'),('Get HL7 Inbound Exception','Able to get an HL7 error item','d05118c6-2490-4d78-a41a-390e3596a216'),('Get HL7 Inbound Queue','Able to get an HL7 Queue item','d05118c6-2490-4d78-a41a-390e3596a218'),('Get HL7 Source','Able to get an HL7 Source','d05118c6-2490-4d78-a41a-390e3596a219'),('Get Identifier Types','Able to get patient identifier types','d05118c6-2490-4d78-a41a-390e3596a239'),('Get Location Attribute Types','Able to get location attribute types','d05118c6-2490-4d78-a41a-390e3596a212'),('Get Locations','Able to get locations','d05118c6-2490-4d78-a41a-390e3596a246'),('Get Medication Dispense','Able to get Medication Dispenses','c70eb395-f857-4693-b6c8-18ff8d9759da'),('Get Notes','Able to get patient notes','dcd11774-e77c-48d5-8f34-685741dec359'),('Get Observations','Able to get patient observations','d05118c6-2490-4d78-a41a-390e3596a245'),('Get Order Frequencies','Able to get Order Frequencies','c78007dd-c641-400b-9aac-04420aecc5b6'),('Get Order Set Attribute Types','Able to get order set attribute types','bfc2eca6-fa0a-4700-b5ba-3bbe5a44413d'),('Get Order Sets','Able to get order sets','e52af909-2baf-4ab6-9862-8a6848448ec0'),('Get Order Types','Able to get order types','d05118c6-2490-4d78-a41a-390e3596a233'),('Get Orders','Able to get orders','d05118c6-2490-4d78-a41a-390e3596a241'),('Get Patient Cohorts','Able to get patient cohorts','d05118c6-2490-4d78-a41a-390e3596a242'),('Get Patient Identifiers','Able to get patient identifiers','d05118c6-2490-4d78-a41a-390e3596a243'),('Get Patient Programs','Able to get which programs that patients are in','d05118c6-2490-4d78-a41a-390e3596a227'),('Get Patients','Able to get patients','d05118c6-2490-4d78-a41a-390e3596a244'),('Get People','Able to get person objects','d05118c6-2490-4d78-a41a-390e3596a224'),('Get Person Attribute Types','Able to get person attribute types','d05118c6-2490-4d78-a41a-390e3596a225'),('Get Privileges','Able to get user privileges','d05118c6-2490-4d78-a41a-390e3596a236'),('Get Problems','Able to get problems','d05118c6-2490-4d78-a41a-390e3596a221'),('Get Programs','Able to get patient programs','d05118c6-2490-4d78-a41a-390e3596a228'),('Get Provider Attribute Types','Able to get provider attribute types','78b973c7-d051-4bb7-9eca-c18f8c61398a'),('Get Providers','Able to get Providers','d05118c6-2490-4d78-a41a-390e3596a211'),('Get Relationship Types','Able to get relationship types','d05118c6-2490-4d78-a41a-390e3596a232'),('Get Relationships','Able to get relationships','d05118c6-2490-4d78-a41a-390e3596a223'),('Get Roles','Able to get user roles','d05118c6-2490-4d78-a41a-390e3596a235'),('Get Users','Able to get users in OpenMRS','d05118c6-2490-4d78-a41a-390e3596a249'),('Get Visit Attribute Types','Able to get visit attribute types','d05118c6-2490-4d78-a41a-390e3596a213'),('Get Visit Types','Able to get visit types','d05118c6-2490-4d78-a41a-390e3596a215'),('Get Visits','Able to get visits','d05118c6-2490-4d78-a41a-390e3596a214'),('Manage Address Templates','Able to add/edit/delete address templates','fb21b9ee-fd8a-47b6-8656-bd3a68a44925'),('Manage Alerts','Able to add/edit/delete user alerts','5f8a3282-6814-11e8-923f-e9a88dcb533f'),('Manage Concept Attribute Types','Able to add/edit/retire concept attribute types','7550fbcb-cb61-4a9f-94d5-eb376afc727f'),('Manage Concept Classes','Able to add/edit/retire concept classes','5f8a32aa-6814-11e8-923f-e9a88dcb533f'),('Manage Concept Datatypes','Able to add/edit/retire concept datatypes','5f8a32dc-6814-11e8-923f-e9a88dcb533f'),('Manage Concept Map Types','Able to add/edit/retire concept map types','385096c5-6492-41f3-8304-c0144e8fb2e6'),('Manage Concept Name tags','Able to add/edit/delete concept name tags','401cc09a-84c6-4d9e-bf93-4659837edbde'),('Manage Concept Reference Terms','Able to add/edit/retire reference terms','80e45896-d4cd-48a1-b35e-30709bab36b6'),('Manage Concept Sources','Able to add/edit/delete concept sources','5f8a3304-6814-11e8-923f-e9a88dcb533f'),('Manage Concept Stop Words','Able to view/add/remove the concept stop words','47b5b16e-0ff5-4a4a-ae26-947af73c88ca'),('Manage Concepts','Able to add/edit/delete concept entries','5f8a3336-6814-11e8-923f-e9a88dcb533f'),('Manage Encounter Roles','Able to add/edit/retire encounter roles','0fbaddea-b053-4841-a1f1-2ca93fd71d9a'),('Manage Encounter Types','Able to add/edit/delete encounter types','5f8a3368-6814-11e8-923f-e9a88dcb533f'),('Manage Field Types','Able to add/edit/retire field types','5f8a3390-6814-11e8-923f-e9a88dcb533f'),('Manage FormEntry XSN','Allows user to upload and edit the xsns stored on the server','5f8a33b8-6814-11e8-923f-e9a88dcb533f'),('Manage Forms','Able to add/edit/delete forms','5f8a33ea-6814-11e8-923f-e9a88dcb533f'),('Manage Global Properties','Able to add/edit global properties','5f8a341c-6814-11e8-923f-e9a88dcb533f'),('Manage HL7 Messages','Able to add/edit/delete HL7 messages','e43b8830-7c95-42e6-8259-538fec951c66'),('Manage Identifier Types','Able to add/edit/delete patient identifier types','5f8a3444-6814-11e8-923f-e9a88dcb533f'),('Manage Implementation Id','Able to view/add/edit the implementation id for the system','20e102e1-74b4-4198-905e-9b598c8474f1'),('Manage Location Attribute Types','Able to add/edit/retire location attribute types','5c266720-20c2-4fa2-89d3-56886176d63a'),('Manage Location Tags','Able to add/edit/delete location tags','d6d83d7f-9241-42e6-9689-393920a4f733'),('Manage Locations','Able to add/edit/delete locations','5f8a3476-6814-11e8-923f-e9a88dcb533f'),('Manage Modules','Able to add/remove modules to the system','5f8a349e-6814-11e8-923f-e9a88dcb533f'),('Manage Order Frequencies','Able to add/edit/retire Order Frequencies','e3a5205d-ab12-40ca-9160-9ba02198e389'),('Manage Order Set Attribute Types','Able to add/edit/retire order set attribute types','35360a98-eebf-4cc0-812d-80b6025cfea3'),('Manage Order Sets','Able to manage order sets','059955e6-014f-4e50-b198-24e179784025'),('Manage Order Types','Able to add/edit/retire order types','5f8a34c6-6814-11e8-923f-e9a88dcb533f'),('Manage OWA','Allows to configure OWA module, upload modules','2835dd9a-f8ff-4e05-bb07-2c3756df50cd'),('Manage Person Attribute Types','Able to add/edit/delete person attribute types','5f8a34f8-6814-11e8-923f-e9a88dcb533f'),('Manage Privileges','Able to add/edit/delete privileges','5f8a3520-6814-11e8-923f-e9a88dcb533f'),('Manage Programs','Able to add/view/delete patient programs','5f8a3552-6814-11e8-923f-e9a88dcb533f'),('Manage Providers','Able to edit Provider','b0b6fe18-9940-42b4-80fc-b05e6ee546f5'),('Manage Relationship Types','Able to add/edit/retire relationship types','5f8a357a-6814-11e8-923f-e9a88dcb533f'),('Manage Relationships','Able to add/edit/delete relationships','5f8a35ac-6814-11e8-923f-e9a88dcb533f'),('Manage RESTWS','Allows to configure RESTWS module','e2b93a7d-2e3f-4e93-b192-181be532a705'),('Manage Roles','Able to add/edit/delete user roles','5f8a35d4-6814-11e8-923f-e9a88dcb533f'),('Manage Scheduler','Able to add/edit/remove scheduled tasks','5f8a3606-6814-11e8-923f-e9a88dcb533f'),('Manage Search Index','Able to manage the search index','657bfbbb-a008-43f3-85ac-3163d201b389'),('Manage Visit Attribute Types','Able to add/edit/retire visit attribute types','d0e19ed6-a299-4435-ab8f-2ea76e22fcc4'),('Manage Visit Types','Able to add/edit/delete visit types','f9196849-164f-4522-80d8-488d36faeec2'),('Patient Dashboard - View Demographics Section','Able to view the \'Demographics\' tab on the patient dashboard','5f8a362e-6814-11e8-923f-e9a88dcb533f'),('Patient Dashboard - View Encounters Section','Able to view the \'Encounters\' tab on the patient dashboard','5f8a3660-6814-11e8-923f-e9a88dcb533f'),('Patient Dashboard - View Forms Section','Allows user to view the Forms tab on the patient dashboard','5f8a3692-6814-11e8-923f-e9a88dcb533f'),('Patient Dashboard - View Graphs Section','Able to view the \'Graphs\' tab on the patient dashboard','5f8a36ce-6814-11e8-923f-e9a88dcb533f'),('Patient Dashboard - View Overview Section','Able to view the \'Overview\' tab on the patient dashboard','5f8a3700-6814-11e8-923f-e9a88dcb533f'),('Patient Dashboard - View Patient Summary','Able to view the \'Summary\' tab on the patient dashboard','5f8a3732-6814-11e8-923f-e9a88dcb533f'),('Patient Dashboard - View Regimen Section','Able to view the \'Regimen\' tab on the patient dashboard','5f8a375a-6814-11e8-923f-e9a88dcb533f'),('Patient Overview - View Allergies','Able to view the Allergies portlet on the patient overview tab','d05118c6-2490-4d78-a41a-390e3596a261'),('Patient Overview - View Patient Actions','Able to view the Patient Actions portlet on the patient overview tab','d05118c6-2490-4d78-a41a-390e3596a264'),('Patient Overview - View Problem List','Able to view the Problem List portlet on the patient overview tab','d05118c6-2490-4d78-a41a-390e3596a260'),('Patient Overview - View Programs','Able to view the Programs portlet on the patient overview tab','d05118c6-2490-4d78-a41a-390e3596a263'),('Patient Overview - View Relationships','Able to view the Relationships portlet on the patient overview tab','d05118c6-2490-4d78-a41a-390e3596a262'),('Purge Field Types','Able to purge field types','5f8a3796-6814-11e8-923f-e9a88dcb533f'),('Remove Allergies','Remove allergies','dbdea8f5-9fca-4527-9ef6-5fa03eebf2bd'),('Remove Problems','Remove problems','28ea7e84-e21a-4031-9f9f-2d3eda9d1200'),('Task: Modify Allergies','Able to add, edit, delete allergies','eeb9108e-6905-4712-a13c-b9435db4abcb'),('Update HL7 Inbound Archive','Able to update an HL7 archive item','5dd8306f-eeb4-430e-b5da-a6e02bcafb79'),('Update HL7 Inbound Exception','Able to update an HL7 archive item','e2614f6d-a730-4292-9c10-baf6d912500f'),('Update HL7 Inbound Queue','Able to update an HL7 Queue item','f82b7723-110e-47d3-a35b-4552ea1bff9e'),('Update HL7 Source','Able to update an HL7 Source','6e0abfb7-e95c-4efd-82a0-00a02b0e8335'),('Upload XSN','Allows user to upload/overwrite the XSNs defined for forms','5f8a37c8-6814-11e8-923f-e9a88dcb533f'),('View Administration Functions','Able to view the \'Administration\' link in the navigation bar','5f8a37fa-6814-11e8-923f-e9a88dcb533f'),('View Allergies','Able to view allergies in OpenMRS','5f8a382c-6814-11e8-923f-e9a88dcb533f'),('View Concept Classes','Able to view concept classes','5f8a3958-6814-11e8-923f-e9a88dcb533f'),('View Concept Datatypes','Able to view concept datatypes','5f8a398a-6814-11e8-923f-e9a88dcb533f'),('View Concept Proposals','Able to view concept proposals to the system','5f8a39bc-6814-11e8-923f-e9a88dcb533f'),('View Concept Sources','Able to view concept sources','5f8a39ee-6814-11e8-923f-e9a88dcb533f'),('View Concepts','Able to view concept entries','5f8a3a16-6814-11e8-923f-e9a88dcb533f'),('View Data Entry Statistics','Able to view data entry statistics from the admin screen','5f8a3a48-6814-11e8-923f-e9a88dcb533f'),('View Encounter Types','Able to view encounter types','5f8a3a7a-6814-11e8-923f-e9a88dcb533f'),('View Encounters','Able to view patient encounters','5f8a3aa2-6814-11e8-923f-e9a88dcb533f'),('View Field Types','Able to view field types','5f8a3ad4-6814-11e8-923f-e9a88dcb533f'),('View Forms','Able to view forms','5f8a3afc-6814-11e8-923f-e9a88dcb533f'),('View Global Properties','Able to view global properties on the administration screen','5f8a3b2e-6814-11e8-923f-e9a88dcb533f'),('View Identifier Types','Able to view patient identifier types','5f8a3b60-6814-11e8-923f-e9a88dcb533f'),('View Locations','Able to view locations','5f8a3b88-6814-11e8-923f-e9a88dcb533f'),('View Navigation Menu','Ability to see the navigation menu','5f8a3bba-6814-11e8-923f-e9a88dcb533f'),('View Observations','Able to view patient observations','5f8a3be2-6814-11e8-923f-e9a88dcb533f'),('View Order Types','Able to view order types','5f8a3c14-6814-11e8-923f-e9a88dcb533f'),('View Orders','Able to view orders','5f8a3c46-6814-11e8-923f-e9a88dcb533f'),('View Patient Cohorts','Able to view patient cohorts','5f8a3c6e-6814-11e8-923f-e9a88dcb533f'),('View Patient Identifiers','Able to view patient identifiers','5f8a3ca0-6814-11e8-923f-e9a88dcb533f'),('View Patient Programs','Able to see which programs that patients are in','5f8a3cd2-6814-11e8-923f-e9a88dcb533f'),('View Patients','Able to view patients','5f8a3cfa-6814-11e8-923f-e9a88dcb533f'),('View People','Able to view person objects','5f8a3d2c-6814-11e8-923f-e9a88dcb533f'),('View Person Attribute Types','Able to view person attribute types','5f8a3d5e-6814-11e8-923f-e9a88dcb533f'),('View Privileges','Able to view user privileges','5f8a3d86-6814-11e8-923f-e9a88dcb533f'),('View Problems','Able to view problems in OpenMRS','5f8a3db8-6814-11e8-923f-e9a88dcb533f'),('View Programs','Able to view patient programs','5f8a3de0-6814-11e8-923f-e9a88dcb533f'),('View Relationship Types','Able to view relationship types','5f8a3e12-6814-11e8-923f-e9a88dcb533f'),('View Relationships','Able to view relationships','5f8a3e44-6814-11e8-923f-e9a88dcb533f'),('View Report Objects','Able to view report objects','5f8a3e6c-6814-11e8-923f-e9a88dcb533f'),('View Reports','Able to view reports','5f8a3e9e-6814-11e8-923f-e9a88dcb533f'),('View RESTWS','Gives access to RESTWS in administration','80a11b5d-acc8-43e8-897c-a132c268ea98'),('View Roles','Able to view user roles','5f8a3ec6-6814-11e8-923f-e9a88dcb533f'),('View Unpublished Forms','Able to view and fill out unpublished forms','5f8a3ef8-6814-11e8-923f-e9a88dcb533f'),('View Users','Able to view users in OpenMRS','5f8a3f2a-6814-11e8-923f-e9a88dcb533f');
/*!40000 ALTER TABLE `privilege` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program`
--

DROP TABLE IF EXISTS `program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `program` (
  `program_id` int NOT NULL AUTO_INCREMENT,
  `concept_id` int NOT NULL DEFAULT '0',
  `outcomes_concept_id` int DEFAULT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL,
  `description` text,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`program_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `program_concept` (`concept_id`),
  KEY `program_creator` (`creator`),
  KEY `program_outcomes_concept_id_fk` (`outcomes_concept_id`),
  KEY `user_who_changed_program` (`changed_by`),
  CONSTRAINT `program_concept` FOREIGN KEY (`concept_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `program_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `program_outcomes_concept_id_fk` FOREIGN KEY (`outcomes_concept_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_changed_program` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program`
--

LOCK TABLES `program` WRITE;
/*!40000 ALTER TABLE `program` DISABLE KEYS */;
/*!40000 ALTER TABLE `program` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program_attribute_type`
--

DROP TABLE IF EXISTS `program_attribute_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `program_attribute_type` (
  `program_attribute_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `datatype` varchar(255) DEFAULT NULL,
  `datatype_config` text,
  `preferred_handler` varchar(255) DEFAULT NULL,
  `handler_config` text,
  `min_occurs` int NOT NULL,
  `max_occurs` int DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`program_attribute_type_id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `program_attribute_type_changed_by_fk` (`changed_by`),
  KEY `program_attribute_type_creator_fk` (`creator`),
  KEY `program_attribute_type_retired_by_fk` (`retired_by`),
  CONSTRAINT `program_attribute_type_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `program_attribute_type_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `program_attribute_type_retired_by_fk` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program_attribute_type`
--

LOCK TABLES `program_attribute_type` WRITE;
/*!40000 ALTER TABLE `program_attribute_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `program_attribute_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program_workflow`
--

DROP TABLE IF EXISTS `program_workflow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `program_workflow` (
  `program_workflow_id` int NOT NULL AUTO_INCREMENT,
  `program_id` int NOT NULL DEFAULT '0',
  `concept_id` int NOT NULL DEFAULT '0',
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`program_workflow_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `program_for_workflow` (`program_id`),
  KEY `workflow_changed_by` (`changed_by`),
  KEY `workflow_concept` (`concept_id`),
  KEY `workflow_creator` (`creator`),
  CONSTRAINT `program_for_workflow` FOREIGN KEY (`program_id`) REFERENCES `program` (`program_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `workflow_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `workflow_concept` FOREIGN KEY (`concept_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `workflow_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program_workflow`
--

LOCK TABLES `program_workflow` WRITE;
/*!40000 ALTER TABLE `program_workflow` DISABLE KEYS */;
/*!40000 ALTER TABLE `program_workflow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program_workflow_state`
--

DROP TABLE IF EXISTS `program_workflow_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `program_workflow_state` (
  `program_workflow_state_id` int NOT NULL AUTO_INCREMENT,
  `program_workflow_id` int NOT NULL DEFAULT '0',
  `concept_id` int NOT NULL DEFAULT '0',
  `initial` tinyint(1) NOT NULL DEFAULT '0',
  `terminal` tinyint(1) NOT NULL DEFAULT '0',
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`program_workflow_state_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `state_changed_by` (`changed_by`),
  KEY `state_concept` (`concept_id`),
  KEY `state_creator` (`creator`),
  KEY `workflow_for_state` (`program_workflow_id`),
  CONSTRAINT `state_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `state_concept` FOREIGN KEY (`concept_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `state_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `workflow_for_state` FOREIGN KEY (`program_workflow_id`) REFERENCES `program_workflow` (`program_workflow_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program_workflow_state`
--

LOCK TABLES `program_workflow_state` WRITE;
/*!40000 ALTER TABLE `program_workflow_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `program_workflow_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provider`
--

DROP TABLE IF EXISTS `provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `provider` (
  `provider_id` int NOT NULL AUTO_INCREMENT,
  `person_id` int DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  `role_id` int DEFAULT NULL,
  `speciality_id` int DEFAULT NULL,
  PRIMARY KEY (`provider_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `provider_changed_by_fk` (`changed_by`),
  KEY `provider_creator_fk` (`creator`),
  KEY `provider_person_id_fk` (`person_id`),
  KEY `provider_retired_by_fk` (`retired_by`),
  KEY `provider_role_id_fk` (`role_id`),
  KEY `provider_speciality_id_fk` (`speciality_id`),
  CONSTRAINT `provider_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `provider_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `provider_person_id_fk` FOREIGN KEY (`person_id`) REFERENCES `person` (`person_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `provider_retired_by_fk` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `provider_role_id_fk` FOREIGN KEY (`role_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `provider_speciality_id_fk` FOREIGN KEY (`speciality_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provider`
--

LOCK TABLES `provider` WRITE;
/*!40000 ALTER TABLE `provider` DISABLE KEYS */;
/*!40000 ALTER TABLE `provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provider_attribute`
--

DROP TABLE IF EXISTS `provider_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `provider_attribute` (
  `provider_attribute_id` int NOT NULL AUTO_INCREMENT,
  `provider_id` int NOT NULL,
  `attribute_type_id` int NOT NULL,
  `value_reference` text NOT NULL,
  `uuid` char(38) NOT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`provider_attribute_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `provider_attribute_attribute_type_id_fk` (`attribute_type_id`),
  KEY `provider_attribute_changed_by_fk` (`changed_by`),
  KEY `provider_attribute_creator_fk` (`creator`),
  KEY `provider_attribute_provider_fk` (`provider_id`),
  KEY `provider_attribute_voided_by_fk` (`voided_by`),
  CONSTRAINT `provider_attribute_attribute_type_id_fk` FOREIGN KEY (`attribute_type_id`) REFERENCES `provider_attribute_type` (`provider_attribute_type_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `provider_attribute_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `provider_attribute_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `provider_attribute_provider_fk` FOREIGN KEY (`provider_id`) REFERENCES `provider` (`provider_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `provider_attribute_voided_by_fk` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provider_attribute`
--

LOCK TABLES `provider_attribute` WRITE;
/*!40000 ALTER TABLE `provider_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `provider_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provider_attribute_type`
--

DROP TABLE IF EXISTS `provider_attribute_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `provider_attribute_type` (
  `provider_attribute_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `datatype` varchar(255) DEFAULT NULL,
  `datatype_config` text,
  `preferred_handler` varchar(255) DEFAULT NULL,
  `handler_config` text,
  `min_occurs` int NOT NULL,
  `max_occurs` int DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`provider_attribute_type_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `provider_attribute_type_changed_by_fk` (`changed_by`),
  KEY `provider_attribute_type_creator_fk` (`creator`),
  KEY `provider_attribute_type_retired_by_fk` (`retired_by`),
  CONSTRAINT `provider_attribute_type_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `provider_attribute_type_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `provider_attribute_type_retired_by_fk` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provider_attribute_type`
--

LOCK TABLES `provider_attribute_type` WRITE;
/*!40000 ALTER TABLE `provider_attribute_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `provider_attribute_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `referral_order`
--

DROP TABLE IF EXISTS `referral_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `referral_order` (
  `order_id` int NOT NULL AUTO_INCREMENT,
  `specimen_source` int DEFAULT NULL,
  `laterality` varchar(20) DEFAULT NULL,
  `clinical_history` text,
  `frequency` int DEFAULT NULL,
  `number_of_repeats` int DEFAULT NULL,
  `location` int DEFAULT NULL,
  PRIMARY KEY (`order_id`),
  KEY `referral_order_frequency_index` (`frequency`),
  KEY `referral_order_location_fk` (`location`),
  KEY `referral_order_specimen_source_index` (`specimen_source`),
  CONSTRAINT `referral_order_frequency_fk` FOREIGN KEY (`frequency`) REFERENCES `order_frequency` (`order_frequency_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `referral_order_location_fk` FOREIGN KEY (`location`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `referral_order_order_id_fk` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `referral_order_specimen_source_fk` FOREIGN KEY (`specimen_source`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referral_order`
--

LOCK TABLES `referral_order` WRITE;
/*!40000 ALTER TABLE `referral_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `referral_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relationship`
--

DROP TABLE IF EXISTS `relationship`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relationship` (
  `relationship_id` int NOT NULL AUTO_INCREMENT,
  `person_a` int NOT NULL,
  `relationship` int NOT NULL DEFAULT '0',
  `person_b` int NOT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `date_changed` datetime DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`relationship_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `person_a_is_person` (`person_a`),
  KEY `person_b_is_person` (`person_b`),
  KEY `relation_creator` (`creator`),
  KEY `relation_voider` (`voided_by`),
  KEY `relationship_changed_by` (`changed_by`),
  KEY `relationship_type_id` (`relationship`),
  CONSTRAINT `person_a_is_person` FOREIGN KEY (`person_a`) REFERENCES `person` (`person_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `person_b_is_person` FOREIGN KEY (`person_b`) REFERENCES `person` (`person_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `relation_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `relation_voider` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `relationship_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `relationship_type_id` FOREIGN KEY (`relationship`) REFERENCES `relationship_type` (`relationship_type_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relationship`
--

LOCK TABLES `relationship` WRITE;
/*!40000 ALTER TABLE `relationship` DISABLE KEYS */;
/*!40000 ALTER TABLE `relationship` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relationship_type`
--

DROP TABLE IF EXISTS `relationship_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relationship_type` (
  `relationship_type_id` int NOT NULL AUTO_INCREMENT,
  `a_is_to_b` varchar(50) NOT NULL,
  `b_is_to_a` varchar(50) NOT NULL,
  `preferred` tinyint(1) NOT NULL DEFAULT '0',
  `weight` int NOT NULL DEFAULT '0',
  `description` varchar(255) DEFAULT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  `date_changed` datetime DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  PRIMARY KEY (`relationship_type_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `relationship_type_changed_by` (`changed_by`),
  KEY `user_who_created_rel` (`creator`),
  KEY `user_who_retired_relationship_type` (`retired_by`),
  CONSTRAINT `relationship_type_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_created_rel` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_retired_relationship_type` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relationship_type`
--

LOCK TABLES `relationship_type` WRITE;
/*!40000 ALTER TABLE `relationship_type` DISABLE KEYS */;
INSERT INTO `relationship_type` VALUES (1,'Doctor','Patient',0,0,'Relationship from a primary care provider to the patient',1,'2007-05-04 00:00:00',0,NULL,NULL,NULL,'8d919b58-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL),(2,'Sibling','Sibling',0,0,'Relationship between brother/sister, brother/brother, and sister/sister',1,'2007-05-04 00:00:00',0,NULL,NULL,NULL,'8d91a01c-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL),(3,'Parent','Child',0,0,'Relationship from a mother/father to the child',1,'2007-05-04 00:00:00',0,NULL,NULL,NULL,'8d91a210-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL),(4,'Aunt/Uncle','Niece/Nephew',0,0,'Relationship from a parent\'s sibling to a child of that parent',1,'2007-05-04 00:00:00',0,NULL,NULL,NULL,'8d91a3dc-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL);
/*!40000 ALTER TABLE `relationship_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_object`
--

DROP TABLE IF EXISTS `report_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_object` (
  `report_object_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `report_object_type` varchar(255) NOT NULL,
  `report_object_sub_type` varchar(255) NOT NULL,
  `xml_data` text,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`report_object_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `report_object_creator` (`creator`),
  KEY `user_who_changed_report_object` (`changed_by`),
  KEY `user_who_voided_report_object` (`voided_by`),
  CONSTRAINT `report_object_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_changed_report_object` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_voided_report_object` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_object`
--

LOCK TABLES `report_object` WRITE;
/*!40000 ALTER TABLE `report_object` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_schema_xml`
--

DROP TABLE IF EXISTS `report_schema_xml`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_schema_xml` (
  `report_schema_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `xml_data` text NOT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`report_schema_id`),
  UNIQUE KEY `uuid` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_schema_xml`
--

LOCK TABLES `report_schema_xml` WRITE;
/*!40000 ALTER TABLE `report_schema_xml` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_schema_xml` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `role` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`role`),
  UNIQUE KEY `uuid` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES ('Anonymous','Privileges for non-authenticated users.','774b2af3-6437-4e5a-a310-547554c7c65c'),('Authenticated','Privileges gained once authentication has been established.','f7fd42ef-880e-40c5-972d-e4ae7c990de2'),('Provider','All users with the \'Provider\' role will appear as options in the default Infopath ','8d94f280-c2cc-11de-8d13-0010c6dffd0f'),('System Developer','Developers of the OpenMRS .. have additional access to change fundamental structure of the database model.','8d94f852-c2cc-11de-8d13-0010c6dffd0f');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_privilege`
--

DROP TABLE IF EXISTS `role_privilege`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_privilege` (
  `role` varchar(50) NOT NULL DEFAULT '',
  `privilege` varchar(255) NOT NULL,
  PRIMARY KEY (`role`,`privilege`),
  KEY `privilege_definitions` (`privilege`),
  KEY `role_privilege_to_role` (`role`),
  CONSTRAINT `privilege_definitions` FOREIGN KEY (`privilege`) REFERENCES `privilege` (`privilege`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `role_privilege_to_role` FOREIGN KEY (`role`) REFERENCES `role` (`role`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_privilege`
--

LOCK TABLES `role_privilege` WRITE;
/*!40000 ALTER TABLE `role_privilege` DISABLE KEYS */;
INSERT INTO `role_privilege` VALUES ('Authenticated','Get Concept Classes'),('Authenticated','Get Concept Datatypes'),('Authenticated','Get Encounter Types'),('Authenticated','Get Field Types'),('Authenticated','Get Global Properties'),('Authenticated','Get Identifier Types'),('Authenticated','Get Locations'),('Authenticated','Get Order Types'),('Authenticated','Get Person Attribute Types'),('Authenticated','Get Privileges'),('Authenticated','Get Relationship Types'),('Authenticated','Get Relationships'),('Authenticated','Get Roles'),('Authenticated','Patient Overview - View Relationships'),('Authenticated','View Concept Classes'),('Authenticated','View Concept Datatypes'),('Authenticated','View Encounter Types'),('Authenticated','View Field Types'),('Authenticated','View Global Properties'),('Authenticated','View Identifier Types'),('Authenticated','View Locations'),('Authenticated','View Order Types'),('Authenticated','View Person Attribute Types'),('Authenticated','View Privileges'),('Authenticated','View Relationship Types'),('Authenticated','View Relationships'),('Authenticated','View Roles');
/*!40000 ALTER TABLE `role_privilege` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_role`
--

DROP TABLE IF EXISTS `role_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_role` (
  `parent_role` varchar(50) NOT NULL DEFAULT '',
  `child_role` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`parent_role`,`child_role`),
  KEY `inherited_role` (`child_role`),
  CONSTRAINT `inherited_role` FOREIGN KEY (`child_role`) REFERENCES `role` (`role`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `parent_role` FOREIGN KEY (`parent_role`) REFERENCES `role` (`role`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_role`
--

LOCK TABLES `role_role` WRITE;
/*!40000 ALTER TABLE `role_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scheduler_task_config`
--

DROP TABLE IF EXISTS `scheduler_task_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `scheduler_task_config` (
  `task_config_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `schedulable_class` text,
  `start_time` datetime DEFAULT NULL,
  `start_time_pattern` varchar(50) DEFAULT NULL,
  `repeat_interval` int NOT NULL DEFAULT '0',
  `start_on_startup` tinyint(1) NOT NULL DEFAULT '0',
  `started` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` int DEFAULT '0',
  `date_created` datetime DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `last_execution_time` datetime DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`task_config_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `scheduler_changer` (`changed_by`),
  KEY `scheduler_creator` (`created_by`),
  CONSTRAINT `scheduler_changer` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `scheduler_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scheduler_task_config`
--

LOCK TABLES `scheduler_task_config` WRITE;
/*!40000 ALTER TABLE `scheduler_task_config` DISABLE KEYS */;
INSERT INTO `scheduler_task_config` VALUES (2,'Auto Close Visits Task','Stops all active visits that match the visit type(s) specified by the value of the global property \'visits.autoCloseVisitType\'','org.openmrs.scheduler.tasks.AutoCloseVisitsTask','2011-11-28 23:59:59','MM/dd/yyyy HH:mm:ss',86400,0,0,1,'2018-06-04 18:30:16',NULL,NULL,NULL,'8c17b376-1a2b-11e1-a51a-00248140a5eb');
/*!40000 ALTER TABLE `scheduler_task_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scheduler_task_config_property`
--

DROP TABLE IF EXISTS `scheduler_task_config_property`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `scheduler_task_config_property` (
  `task_config_property_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` text,
  `task_config_id` int DEFAULT NULL,
  PRIMARY KEY (`task_config_property_id`),
  KEY `task_config_for_property` (`task_config_id`),
  CONSTRAINT `task_config_for_property` FOREIGN KEY (`task_config_id`) REFERENCES `scheduler_task_config` (`task_config_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scheduler_task_config_property`
--

LOCK TABLES `scheduler_task_config_property` WRITE;
/*!40000 ALTER TABLE `scheduler_task_config_property` DISABLE KEYS */;
/*!40000 ALTER TABLE `scheduler_task_config_property` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `serialized_object`
--

DROP TABLE IF EXISTS `serialized_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `serialized_object` (
  `serialized_object_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(5000) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `subtype` varchar(255) NOT NULL,
  `serialization_class` varchar(255) NOT NULL,
  `serialized_data` mediumtext NOT NULL,
  `date_created` datetime NOT NULL,
  `creator` int NOT NULL,
  `date_changed` datetime DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `date_retired` datetime DEFAULT NULL,
  `retired_by` int DEFAULT NULL,
  `retire_reason` varchar(1000) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`serialized_object_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `serialized_object_changed_by` (`changed_by`),
  KEY `serialized_object_creator` (`creator`),
  KEY `serialized_object_retired_by` (`retired_by`),
  CONSTRAINT `serialized_object_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `serialized_object_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `serialized_object_retired_by` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `serialized_object`
--

LOCK TABLES `serialized_object` WRITE;
/*!40000 ALTER TABLE `serialized_object` DISABLE KEYS */;
/*!40000 ALTER TABLE `serialized_object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test_order`
--

DROP TABLE IF EXISTS `test_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_order` (
  `order_id` int NOT NULL DEFAULT '0',
  `specimen_source` int DEFAULT NULL,
  `laterality` varchar(20) DEFAULT NULL,
  `clinical_history` text,
  `frequency` int DEFAULT NULL,
  `number_of_repeats` int DEFAULT NULL,
  `location` int DEFAULT NULL,
  PRIMARY KEY (`order_id`),
  KEY `test_order_frequency_fk` (`frequency`),
  KEY `test_order_location_fk` (`location`),
  KEY `test_order_specimen_source_fk` (`specimen_source`),
  CONSTRAINT `test_order_frequency_fk` FOREIGN KEY (`frequency`) REFERENCES `order_frequency` (`order_frequency_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `test_order_location_fk` FOREIGN KEY (`location`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `test_order_order_id_fk` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `test_order_specimen_source_fk` FOREIGN KEY (`specimen_source`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_order`
--

LOCK TABLES `test_order` WRITE;
/*!40000 ALTER TABLE `test_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `test_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_property`
--

DROP TABLE IF EXISTS `user_property`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_property` (
  `user_id` int NOT NULL DEFAULT '0',
  `property` varchar(255) NOT NULL,
  `property_value` longtext,
  PRIMARY KEY (`user_id`,`property`),
  CONSTRAINT `user_property_to_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_property`
--

LOCK TABLES `user_property` WRITE;
/*!40000 ALTER TABLE `user_property` DISABLE KEYS */;
INSERT INTO `user_property` VALUES (1,'defaultLocale','en'),(1,'lastLoginTimestamp','1747313234238'),(1,'lockoutTimestamp',''),(1,'loginAttempts','0');
/*!40000 ALTER TABLE `user_property` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_role` (
  `user_id` int NOT NULL DEFAULT '0',
  `role` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`user_id`,`role`),
  KEY `role_definitions` (`role`),
  KEY `user_role_to_users` (`user_id`),
  CONSTRAINT `role_definitions` FOREIGN KEY (`role`) REFERENCES `role` (`role`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_role_to_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_role`
--

LOCK TABLES `user_role` WRITE;
/*!40000 ALTER TABLE `user_role` DISABLE KEYS */;
INSERT INTO `user_role` VALUES (1,'Provider'),(1,'System Developer');
/*!40000 ALTER TABLE `user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `system_id` varchar(50) NOT NULL DEFAULT '',
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(128) DEFAULT NULL,
  `salt` varchar(128) DEFAULT NULL,
  `secret_question` varchar(255) DEFAULT NULL,
  `secret_answer` varchar(255) DEFAULT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `person_id` int NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  `activation_key` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`),
  KEY `person_id_for_user` (`person_id`),
  KEY `user_creator` (`creator`),
  KEY `user_who_changed_user` (`changed_by`),
  KEY `user_who_retired_this_user` (`retired_by`),
  CONSTRAINT `person_id_for_user` FOREIGN KEY (`person_id`) REFERENCES `person` (`person_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_who_changed_user` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `user_who_retired_this_user` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','','6f0be51d599f59dd1269e12e17949f8ecb9ac963e467ac1400cf0a02eb9f8861ce3cca8f6d34d93c0ca34029497542cbadda20c949affb4cb59269ef4912087b','c788c6ad82a157b712392ca695dfcf2eed193d7f',NULL,NULL,1,'2005-01-01 00:00:00',1,'2025-05-15 15:43:43',1,0,NULL,NULL,NULL,'82f18b44-6814-11e8-923f-e9a88dcb533f',NULL,NULL),(2,'daemon','daemon',NULL,NULL,NULL,NULL,1,'2010-04-26 13:25:00',NULL,NULL,1,0,NULL,NULL,NULL,'A4F30A1B-5EB9-11DF-A648-37A07F9C90FB',NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visit`
--

DROP TABLE IF EXISTS `visit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `visit` (
  `visit_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NOT NULL,
  `visit_type_id` int NOT NULL,
  `date_started` datetime NOT NULL,
  `date_stopped` datetime DEFAULT NULL,
  `indication_concept_id` int DEFAULT NULL,
  `location_id` int DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`visit_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `visit_changed_by_fk` (`changed_by`),
  KEY `visit_creator_fk` (`creator`),
  KEY `visit_indication_concept_fk` (`indication_concept_id`),
  KEY `visit_location_fk` (`location_id`),
  KEY `visit_patient_index` (`patient_id`),
  KEY `visit_type_fk` (`visit_type_id`),
  KEY `visit_voided_by_fk` (`voided_by`),
  CONSTRAINT `visit_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `visit_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `visit_indication_concept_fk` FOREIGN KEY (`indication_concept_id`) REFERENCES `concept` (`concept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `visit_location_fk` FOREIGN KEY (`location_id`) REFERENCES `location` (`location_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `visit_patient_fk` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `visit_type_fk` FOREIGN KEY (`visit_type_id`) REFERENCES `visit_type` (`visit_type_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `visit_voided_by_fk` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visit`
--

LOCK TABLES `visit` WRITE;
/*!40000 ALTER TABLE `visit` DISABLE KEYS */;
/*!40000 ALTER TABLE `visit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visit_attribute`
--

DROP TABLE IF EXISTS `visit_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `visit_attribute` (
  `visit_attribute_id` int NOT NULL AUTO_INCREMENT,
  `visit_id` int NOT NULL,
  `attribute_type_id` int NOT NULL,
  `value_reference` text NOT NULL,
  `uuid` char(38) NOT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`visit_attribute_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `visit_attribute_attribute_type_id_fk` (`attribute_type_id`),
  KEY `visit_attribute_changed_by_fk` (`changed_by`),
  KEY `visit_attribute_creator_fk` (`creator`),
  KEY `visit_attribute_visit_fk` (`visit_id`),
  KEY `visit_attribute_voided_by_fk` (`voided_by`),
  CONSTRAINT `visit_attribute_attribute_type_id_fk` FOREIGN KEY (`attribute_type_id`) REFERENCES `visit_attribute_type` (`visit_attribute_type_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `visit_attribute_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `visit_attribute_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `visit_attribute_visit_fk` FOREIGN KEY (`visit_id`) REFERENCES `visit` (`visit_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `visit_attribute_voided_by_fk` FOREIGN KEY (`voided_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visit_attribute`
--

LOCK TABLES `visit_attribute` WRITE;
/*!40000 ALTER TABLE `visit_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `visit_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visit_attribute_type`
--

DROP TABLE IF EXISTS `visit_attribute_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `visit_attribute_type` (
  `visit_attribute_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `datatype` varchar(255) DEFAULT NULL,
  `datatype_config` text,
  `preferred_handler` varchar(255) DEFAULT NULL,
  `handler_config` text,
  `min_occurs` int NOT NULL,
  `max_occurs` int DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`visit_attribute_type_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `visit_attribute_type_changed_by_fk` (`changed_by`),
  KEY `visit_attribute_type_creator_fk` (`creator`),
  KEY `visit_attribute_type_retired_by_fk` (`retired_by`),
  CONSTRAINT `visit_attribute_type_changed_by_fk` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `visit_attribute_type_creator_fk` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `visit_attribute_type_retired_by_fk` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visit_attribute_type`
--

LOCK TABLES `visit_attribute_type` WRITE;
/*!40000 ALTER TABLE `visit_attribute_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `visit_attribute_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visit_type`
--

DROP TABLE IF EXISTS `visit_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `visit_type` (
  `visit_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `creator` int NOT NULL,
  `date_created` datetime NOT NULL,
  `changed_by` int DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`visit_type_id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `visit_type_changed_by` (`changed_by`),
  KEY `visit_type_creator` (`creator`),
  KEY `visit_type_retired_by` (`retired_by`),
  CONSTRAINT `visit_type_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `visit_type_creator` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `visit_type_retired_by` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visit_type`
--

LOCK TABLES `visit_type` WRITE;
/*!40000 ALTER TABLE `visit_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `visit_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-15 15:49:38
